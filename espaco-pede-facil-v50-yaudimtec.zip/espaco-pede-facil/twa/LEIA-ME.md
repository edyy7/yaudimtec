# Um APK por perfil

Cada perfil é um app Android separado, com ID próprio, e abre travado na sua função:

| APK | Pacote | Abre em | Vê |
|---|---|---|---|
| Yaudimtec Cozinha | br.com.pedefacil.cozinha | /app/cozinha/?op=kds | só fila da cozinha |
| Yaudimtec Garçom | br.com.pedefacil.garcom | /app/garcom/?op=garcom | só mesas e balcão |
| Yaudimtec Loja | br.com.pedefacil.loja | /app/loja/?op=ped | pedidos, produtos, estoque, link |
| Yaudimtec ADM | br.com.pedefacil.adm | /app/adm/?op=adm | dados, pagamentos, aparência, módulos, equipe, contábil (sem estoque) |
| Yaudimtec Entregas | br.com.pedefacil.entregas | /app/entregas/?op=ent | só entregas |

## Gerar sem instalar nada (pelo GitHub)
1. No GitHub do projeto: aba **Actions** → **Gerar APKs** → **Run workflow**.
2. Digite o endereço do site na Vercel, sem `https://` (ex.: `meu-app.vercel.app`) e confirme.
3. Quando terminar (alguns minutos), abra a execução e baixe, em **Artifacts**: `apks` (os 5 `.apk` e o `assetlinks.json`) e `chaves` (guarde: sem elas não dá para atualizar os apps).
4. Coloque o `assetlinks.json` em `.well-known/assetlinks.json` na raiz do site e faça o deploy (tira a barra de endereço do app).
5. Envie cada `.apk` ao celular da função e instale (o Android pede para permitir instalar de fontes desconhecidas).
Opcional: crie o segredo `APK_SENHA` (Settings → Secrets → Actions) para trocar a senha das chaves.

## Gerar
1. `npm i -g @bubblewrap/cli` (precisa de Node 18+ e Java 17+).
2. `bash twa/gerar-apks.sh`. Os APKs saem em `twa/saida/`.
3. Instale cada APK no aparelho da função (cozinha no tablet da cozinha etc.).

## Digital Asset Links (tira a barra de endereço do app)
Depois de gerar, o script mostra o SHA-256 de cada chave. Crie `.well-known/assetlinks.json` na raiz do site com um item por pacote (`relation: delegate_permission/common.handle_all_urls`, `namespace: android_app`, `package_name`, `sha256_cert_fingerprints`). Sem isso o app funciona, mas mostra uma barra de endereço.

## Importante
- Guarde `twa/chaves/`: sem as chaves não é possível atualizar os apps.
- Como os apps carregam o site, cada deploy na Vercel atualiza todos os perfis sem gerar APK novo.
- A trava por perfil é da tela. A proteção de verdade dos dados está no `firestore.rules`.

## Se você gera os APKs pelo PWABuilder (ou outra ferramenta)
O domínio é o mesmo nos 5 apps, e isso não é problema. O que **precisa ser diferente em cada APK é o "Package ID"**. O PWABuilder, por padrão, cria o Package ID a partir do domínio, então os 5 saem iguais e um APK substitui o outro no celular.

Gere cada APK separadamente, colando o endereço da função, e **troque o Package ID** (e o nome):

| App | Endereço para colar | Package ID | Nome |
|---|---|---|---|
| ADM | https://SEUSITE/app/adm/?op=adm | br.com.pedefacil.adm | Yaudimtec ADM |
| Loja | https://SEUSITE/app/loja/?op=ped | br.com.pedefacil.loja | Yaudimtec Loja |
| Cozinha | https://SEUSITE/app/cozinha/?op=kds | br.com.pedefacil.cozinha | Yaudimtec Cozinha |
| Garçom | https://SEUSITE/app/garcom/?op=garcom | br.com.pedefacil.garcom | Yaudimtec Garçom |
| Entregas | https://SEUSITE/app/entregas/?op=ent | br.com.pedefacil.entregas | Yaudimtec Entregas |

Regras:
- Um Package ID nunca se repete entre os apps.
- Pode usar a mesma chave de assinatura nos 5, ou uma para cada. Guarde as chaves.
- Para tirar a barra de endereço, o site precisa de **um só** `/.well-known/assetlinks.json` com os 5 pacotes (modelo em `twa/assetlinks.modelo.json`). Cada ferramenta mostra o SHA-256 de cada APK.
