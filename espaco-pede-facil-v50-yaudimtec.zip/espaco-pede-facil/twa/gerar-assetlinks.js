// Lê as chaves em <pasta>/<perfil>/chaves/<perfil>.keystore, pega o SHA-256 de cada uma e escreve assetlinks.json
// (vai em /.well-known/assetlinks.json do site; com ele o app abre sem a barra de endereço).
// Uso: node twa/gerar-assetlinks.js <pasta-build> <saida.json> <senha>
const { execFileSync } = require("child_process");
const fs = require("fs"), path = require("path");
const [, , pasta, saida, senha] = process.argv;
const perfis = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "scripts", "perfis.json"), "utf8"));
const itens = [];
for (const [perfil, d] of Object.entries(perfis)) {
  const ks = path.join(pasta, perfil, "chaves", perfil + ".keystore");
  const out = execFileSync("keytool", ["-list", "-v", "-keystore", ks, "-alias", perfil, "-storepass", senha], { encoding: "utf8", env: Object.assign({}, process.env, { JAVA_TOOL_OPTIONS: "" }) });
  const m = /SHA256:\s*([0-9A-F:]{95})/i.exec(out);
  if (!m) throw new Error("sem SHA-256 para " + perfil);
  itens.push({ relation: ["delegate_permission/common.handle_all_urls"], target: { namespace: "android_app", package_name: d.pacote, sha256_cert_fingerprints: [m[1].toUpperCase()] } });
}
fs.writeFileSync(saida, JSON.stringify(itens, null, 2) + "\n");
console.log("assetlinks.json com " + itens.length + " apps");
