#!/usr/bin/env bash
# Versão sem perguntas, usada pelo GitHub Actions: cria uma chave por perfil, ajusta o endereço do site e compila.
# Uso: bash twa/gerar-apks-nuvem.sh <endereco-do-site> <senha-das-chaves>
set -euo pipefail
HOST="${1:?informe o endereço do site, ex.: meu-app.vercel.app}"; SENHA="${2:?informe a senha das chaves}"
HOST="${HOST#https://}"; HOST="${HOST#http://}"; HOST="${HOST%%/*}"
cd "$(dirname "$0")"
rm -rf build saida; mkdir -p build saida
for p in cozinha garcom loja adm entregas; do
  echo "=== $p ($HOST) ==="
  mkdir -p "build/$p/chaves"
  sed "s/espaco-pede-facil-v27\.vercel\.app/$HOST/g" "$p/twa-manifest.json" > "build/$p/twa-manifest.json"
  keytool -genkeypair -keystore "build/$p/chaves/$p.keystore" -alias "$p" -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$SENHA" -keypass "$SENHA" -dname "CN=Yaudimtec $p, O=Yaudimtec, C=BR" >/dev/null 2>&1
  ( cd "build/$p" && bubblewrap build --skipPwaValidation && cp app-release-signed.apk "../../saida/yaudimtec-$p.apk" )
done
node gerar-assetlinks.js build saida/assetlinks.json "$SENHA"
echo "Pronto: twa/saida/ tem os 5 APKs e o assetlinks.json (publique-o em /.well-known/assetlinks.json no site)."
