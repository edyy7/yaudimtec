#!/usr/bin/env bash
# Gera um APK por perfil (Cozinha, Garçom, Loja, ADM, Entregas).
# Requisitos (no seu computador, com internet): Node 18+, Java 17+ e: npm i -g @bubblewrap/cli
# Na primeira vez o Bubblewrap baixa o Android SDK sozinho e pede a senha da chave.
set -e
cd "$(dirname "$0")"
mkdir -p chaves saida
for p in cozinha garcom loja adm entregas; do
  echo "=== $p ==="
  mkdir -p "build/$p" && cp "$p/twa-manifest.json" "build/$p/"
  ( cd "build/$p" && bubblewrap build --skipPwaValidation && cp app-release-signed.apk "../../saida/yaudimtec-$p.apk" )
  # mostra a impressão digital SHA-256 da chave, para o assetlinks.json
  keytool -list -v -keystore "chaves/$p.keystore" -alias "$p" 2>/dev/null | grep "SHA256:" || true
done
echo "APKs em twa/saida/. Guarde a pasta twa/chaves/ (sem ela não dá para atualizar os apps)."
