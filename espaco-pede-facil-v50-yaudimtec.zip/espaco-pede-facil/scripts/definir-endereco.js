// Troca o endereço do site em TODOS os APKs (twa/ e nativo/) e nos guias, de uma vez.
// Uso: node scripts/definir-endereco.js espaco-pede-facil-v27.vercel.app
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
const novo = (process.argv[2] || "").replace(/^https?:\/\//, "").replace(/\/.*$/, "");
if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(novo)) { console.error("Use: node scripts/definir-endereco.js seu-site.vercel.app"); process.exit(1); }
const atual = JSON.parse(fs.readFileSync(path.join(root, "twa", "adm", "twa-manifest.json"), "utf8")).host;
const arquivos = [];
(function walk(d) { for (const f of fs.readdirSync(d)) { const p = path.join(d, f), s = fs.statSync(p);
  if (s.isDirectory()) { if (["node_modules", "docs", "prompts", "img", "vendor", "tests", "app"].includes(f)) continue; walk(p); }
  else if (/\.(json|md|sh)$/.test(f) && !/package(-lock)?\.json$/.test(f)) arquivos.push(p); } })(root);
let n = 0;
for (const p of arquivos) { const t = fs.readFileSync(p, "utf8"); if (t.includes(atual)) { fs.writeFileSync(p, t.split(atual).join(novo)); n++; } }
console.log(atual + " → " + novo + " em " + n + " arquivos. Agora rode: npm test");
