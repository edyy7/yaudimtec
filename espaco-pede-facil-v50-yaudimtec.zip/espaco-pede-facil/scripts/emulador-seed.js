#!/usr/bin/env node
"use strict";
// Cria no EMULADOR do Firestore uma loja de teste com 1 produto de estoque 1 e zera tudo antes (rodar de novo = recomeçar do zero).
//   FIRESTORE_EMULATOR_HOST=127.0.0.1:8080 node scripts/emulador-seed.js [slug=loja-teste] [produtoId=1794268070711] [preco=89.9]
const host = process.env.FIRESTORE_EMULATOR_HOST;
if (!host) { console.error("Defina FIRESTORE_EMULATOR_HOST (ex.: 127.0.0.1:8080)."); process.exit(2); }
const [slug = "loja-teste", pid = "1794268070711", preco = "89.9"] = process.argv.slice(2);
const proj = process.env.PF_PROJECT_ID || "demo-pedefacil", uid = "uid-teste-corrida";
const raiz = "http://" + host + "/v1/projects/" + proj + "/databases/(default)/documents/";
const H = { "Content-Type": "application/json", Authorization: "Bearer owner" };
const loja = { nome: "Loja Teste Corrida", modo: "cardapio", services: [{ id: +pid, name: "Produto Teste", price: +preco, estoque_atual: 1 }] };
async function grava(path, fields) {
  const r = await fetch(raiz + path, { method: "PATCH", headers: H, body: JSON.stringify({ fields }) });
  if (!r.ok) throw new Error(path + " -> HTTP " + r.status + " " + (await r.text()).slice(0, 200));
}
(async () => {
  // limpa TUDO do emulador (endpoint só dele): pedidos de testes anteriores fariam o contador começar acima de 0
  const lim = await fetch("http://" + host + "/emulator/v1/projects/" + proj + "/databases/(default)/documents", { method: "DELETE" });
  if (!lim.ok) throw new Error("não consegui limpar o emulador: HTTP " + lim.status);
  await grava("pf_slugs/" + slug, { uid: { stringValue: uid } });
  await grava("pf_lojas_publicas/" + uid, { data: { stringValue: JSON.stringify(loja) } });
  await fetch(raiz + "pf_lojas/" + uid + "/reservado/" + pid, { method: "DELETE", headers: H }); // contador zerado (não existe)
  console.log("Loja de teste criada no emulador: slug " + slug + ", produto " + pid + ", preço " + preco + ", estoque 1.");
  console.log("Agora rode:\n  node scripts/corrida.js http://localhost:3000 " + slug + " " + pid + " " + preco + " 5");
})().catch((e) => { console.error("Falhou (o emulador está rodando?):", e.message); process.exit(1); });
