// Gera, a partir do index.html, uma página FIXA por perfil (app/<perfil>/index.html)
// com o manifest escrito no próprio HTML (não por JavaScript), cor, título e ícone do perfil.
// Uso: node scripts/gerar-perfis.js
const fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
const PERFIS = require("./perfis.json");
const src = fs.readFileSync(path.join(root, "index.html"), "utf8");
for (const [dir, p] of Object.entries(PERFIS)) {
  let h = src;
  const head = `<meta charset="utf-8">\n<link rel="manifest" href="/${p.manifest}">\n<link rel="apple-touch-icon" href="/icons/${dir}-192.png">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-title" content="${p.nome}">\n<script>/* ${p.nome}: trava a função pelo endereço, mesmo se abrirem /app/${dir}/ sem ?op= */(function(){try{var q=new URLSearchParams(location.search);if(!q.get("op")){q.set("op","${p.op}");history.replaceState(null,"",location.pathname+"?"+q.toString()+location.hash)}}catch(e){}})();</script>`;
  h = h.replace('<meta charset="utf-8">', head);
  h = h.replace(/<meta name="theme-color" content="#[0-9a-fA-F]{6}">/g, "");
  h = h.replace('<meta name="viewport"', `<meta name="theme-color" content="${p.cor}">\n<meta name="viewport"`);
  h = h.replace(/<title>[^<]*<\/title>/, `<title>${p.nome}</title>`);
  // o script do index só cria o manifest se a página ainda não tiver um (aqui já tem)
  if (!h.includes('if(!document.querySelector(\'link[rel="manifest"]\')){var l=')) throw new Error("index.html sem a guarda do manifest");
  fs.mkdirSync(path.join(root, "app", dir), { recursive: true });
  fs.writeFileSync(path.join(root, "app", dir, "index.html"), h);
  console.log("app/" + dir + "/index.html", h.length);
}
