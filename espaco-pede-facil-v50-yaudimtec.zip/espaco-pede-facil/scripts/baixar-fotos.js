#!/usr/bin/env node
"use strict";
/*
 * Baixa FOTOS REAIS do Pexels (licença gratuita, uso comercial permitido) para o app:
 *   img/<nicho>/<NN>.webp   (1024x1024, até ~150 KB)
 *
 * Uso (dentro da pasta do projeto):
 *   cd scripts && npm install && cd ..
 *   PEXELS_KEY=sua_chave node scripts/baixar-fotos.js            (lote padrão: 180 buscas)
 *   PEXELS_KEY=sua_chave node scripts/baixar-fotos.js --nicho pizza,lanche
 *   PEXELS_KEY=sua_chave node scripts/baixar-fotos.js --lote 100 --forcar
 *
 * A chave é grátis: pexels.com/api. O limite gratuito é de 200 buscas por hora; o script para sozinho
 * no fim do lote e continua de onde parou na próxima execução (não refaz o que já existe).
 * Ao terminar, abra img/revisao.html para conferir as fotos e trocar as que não combinarem.
 */
const fs = require("fs");
const path = require("path");

const CTX = {
  pizza: "pizza", lanche: "lanche hambúrguer", marmita: "marmita comida caseira", acai: "açaí", padaria: "padaria pão",
  rest: "prato restaurante", pastel: "pastel salgado", roupas: "roupa moda", calcados: "calçado", acess: "acessório bijuteria",
  eletro: "eletrônico", perfum: "cosmético perfume", agua: "água garrafa", pet: "pet cachorro", farm: "farmácia saúde",
  bebidas: "bebida", nat: "produto natural", barb: "barbearia", salao: "salão de beleza", est: "unhas manicure", tattoo: "tatuagem",
};

function parseCsv(txt) {
  txt = txt.replace(/^\uFEFF/, "");
  const rows = []; let row = [], f = "", q = false;
  for (let i = 0; i < txt.length; i++) {
    const c = txt[i];
    if (q) { if (c === '"') { if (txt[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true;
    else if (c === ",") { row.push(f); f = ""; }
    else if (c === "\n") { row.push(f); rows.push(row); row = []; f = ""; }
    else if (c !== "\r") f += c;
  }
  if (f.length || row.length) { row.push(f); rows.push(row); }
  const head = rows.shift();
  return rows.filter((r) => r.length >= head.length).map((r) => Object.fromEntries(head.map((h, i) => [h, r[i]])));
}

function consulta(r) {
  const base = String(r.item || "").replace(/\(.*?\)/g, "").trim();
  const ctx = CTX[r.nicho_chave] || "";
  return (ctx.split(" ")[0] === base.toLowerCase().split(" ")[0] ? base : (ctx + " " + base)).trim();
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const esc = (x) => String(x == null ? "" : x).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function main({ root, key, args = [], fetchFn = fetch, sharp = require("sharp"), pausa = 400, log = console.log }) {
  const arg = (n) => { const i = args.indexOf("--" + n); return i > -1 ? args[i + 1] : null; };
  const lote = parseInt(arg("lote") || "180", 10);
  const only = (arg("nicho") || "").split(",").filter(Boolean);
  const forcar = args.includes("--forcar");
  if (!key) throw new Error("Defina a chave: PEXELS_KEY=... (grátis em pexels.com/api)");

  const rows = parseCsv(fs.readFileSync(path.join(root, "prompts", "prompts_imagens_nichos.csv"), "utf8"))
    .filter((r) => !only.length || only.includes(r.nicho_chave));
  const credFile = path.join(root, "img", "creditos.json");
  const cred = fs.existsSync(credFile) ? JSON.parse(fs.readFileSync(credFile, "utf8")) : {};
  let calls = 0, baixadas = 0, puladas = 0, semResultado = 0, parou = null;

  for (const r of rows) {
    const dest = path.join(root, r.arquivo);
    if (!forcar && fs.existsSync(dest)) { puladas++; continue; }
    if (calls >= lote) { parou = "lote"; break; }
    const q = consulta(r);
    const busca = async (extra) => {
      calls++;
      const url = "https://api.pexels.com/v1/search?" + new URLSearchParams({ query: q, per_page: "8", locale: "pt-BR", ...extra });
      const res = await fetchFn(url, { headers: { Authorization: key } });
      if (res.status === 429) { parou = "limite"; return null; }
      if (res.status === 401) throw new Error("Chave do Pexels recusada (401). Confira a PEXELS_KEY.");
      if (!res.ok) return [];
      return (await res.json()).photos || [];
    };
    let photos = await busca({ orientation: "square" });
    if (parou) break;
    if (!photos.length && calls < lote) { photos = await busca({}); if (parou) break; }
    const p = (photos || []).find((x) => x.width >= 900 && x.height >= 900) || (photos || [])[0];
    if (!p) { semResultado++; log("sem resultado:", r.arquivo, "|", q); await sleep(pausa); continue; }
    const img = await fetchFn(p.src.original + "?auto=compress&cs=tinysrgb&w=1400&h=1400&fit=crop");
    if (!img.ok) { semResultado++; continue; }
    const buf = Buffer.from(await img.arrayBuffer());
    let out = null;
    for (const qlt of [80, 72, 64, 56, 48]) {
      out = await sharp(buf).resize(1024, 1024, { fit: "cover", position: "attention" }).webp({ quality: qlt }).toBuffer();
      if (out.length <= 150 * 1024) break;
    }
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, out);
    cred[r.arquivo] = { consulta: q, fotografo: p.photographer, fotografo_url: p.photographer_url, foto_url: p.url, item: r.item };
    baixadas++;
    log("ok:", r.arquivo, "|", r.item, "<-", q, "(" + Math.round(out.length / 1024) + " KB)");
    fs.mkdirSync(path.dirname(credFile), { recursive: true });
    fs.writeFileSync(credFile, JSON.stringify(cred, null, 2));
    await sleep(pausa);
  }

  // página de revisão + créditos
  const todos = parseCsv(fs.readFileSync(path.join(root, "prompts", "prompts_imagens_nichos.csv"), "utf8"));
  const cards = todos.filter((r) => fs.existsSync(path.join(root, r.arquivo))).map((r) => {
    const c = cred[r.arquivo];
    return '<figure><img loading="lazy" src="../' + esc(r.arquivo) + '" alt=""><figcaption><b>' + esc(r.nicho) + " · " + esc(r.numero) + "</b><br>" + esc(r.item) + "<br><code>" + esc(r.arquivo) + "</code>" +
      (c ? '<br><small>Busca: ' + esc(c.consulta) + ' · Foto de <a href="' + esc(c.fotografo_url) + '">' + esc(c.fotografo) + '</a> no <a href="' + esc(c.foto_url) + '">Pexels</a></small>' : "<br><small>(foto própria)</small>") + "</figcaption></figure>";
  });
  fs.mkdirSync(path.join(root, "img"), { recursive: true });
  fs.writeFileSync(path.join(root, "img", "revisao.html"), '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Revisão das fotos</title><style>body{font:15px system-ui;margin:12px;background:#0a0e17;color:#e6e9ef}a{color:#34d399}code{font-size:12px}figure{margin:0;background:#111827;border-radius:12px;overflow:hidden}img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block}figcaption{padding:8px 10px;font-size:13px}.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}</style><h1>Revisão das fotos (' + cards.length + ' de ' + todos.length + ')</h1><p>Para trocar uma foto, substitua o arquivo indicado por outro .webp com o mesmo nome (ou apague para voltar ao ícone) e faça o deploy.</p><div class="g">' + cards.join("") + "</div></html>");
  fs.writeFileSync(path.join(root, "img", "CREDITOS-FOTOS.md"), "# Créditos das fotos (Pexels)\n\n" + Object.entries(cred).map(([f, c]) => "- `" + f + "`: " + c.fotografo + " (" + c.foto_url + ")").join("\n") + "\n");

  const falta = todos.filter((r) => !fs.existsSync(path.join(root, r.arquivo))).length;
  log("\nBaixadas agora: " + baixadas + " | já existiam: " + puladas + " | sem resultado: " + semResultado + " | faltam: " + falta);
  if (parou === "lote" || parou === "limite") log("Parei por causa do limite de buscas por hora. Rode o mesmo comando daqui a 1 hora: ele continua de onde parou.");
  log("Revise em img/revisao.html");
  return { baixadas, puladas, semResultado, falta, parou, calls };
}

module.exports = { main, parseCsv, consulta };

if (require.main === module) {
  main({ root: path.join(__dirname, ".."), key: process.env.PEXELS_KEY, args: process.argv.slice(2) }).catch((e) => { console.error("Erro:", e.message); process.exit(1); });
}
