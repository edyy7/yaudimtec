# Teste REAL no Chromium (precisa de: pip install playwright && playwright install chromium; e servir a pasta: python3 -m http.server 8765)
# Simula um Android, dispara o evento beforeinstallprompt e confere o toque de instalar nos 5 perfis.
from playwright.sync_api import sync_playwright
import sys
R=[]
def ok(c,m): R.append((bool(c),m)); print(('OK  ' if c else 'FALHA ')+m)
with sync_playwright() as p:
    b=p.chromium.launch()
    for perfil,url in [('ADM','/app/adm/index.html?op=adm'),('Loja','/app/loja/index.html?op=ped'),('Cozinha','/app/cozinha/index.html?op=kds'),('Entregas','/app/entregas/index.html?op=ent'),('Garçom','/app/garcom/index.html?op=garcom')]:
        ctx=b.new_context(viewport={'width':390,'height':800},is_mobile=True,has_touch=True,user_agent='Mozilla/5.0 (Linux; Android 13; SM-A135M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36'); pg=ctx.new_page(); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
        pg.goto('http://localhost:8765'+url,wait_until='load'); pg.wait_for_timeout(1500)
        pg.evaluate("""()=>{window.__calls=0;const e=new Event('beforeinstallprompt',{cancelable:true});e.prompt=()=>{window.__calls++;if(window.__calls>1)throw new Error('InvalidStateError');return Promise.resolve()};e.userChoice=new Promise(r=>{window.__res=r});window.dispatchEvent(e)}""")
        pg.click('#pfinst-go'); pg.wait_for_timeout(300)
        ok(pg.evaluate('window.__calls')==1, perfil+': toque chama o aviso de instalação do Chrome (1 vez)')
        pg.evaluate("window.__res({outcome:'dismissed'})"); pg.wait_for_timeout(300)
        t=pg.inner_text('#pfinst-t')
        ok('Instalar app' in t or 'menu' in t, perfil+': se o aviso é dispensado, aparece o passo a passo ('+t[:60]+'…)')
        pg.click('#pfinst-go'); pg.wait_for_timeout(300)
        ok(pg.evaluate('window.__calls')==1 and not errs, perfil+': novo toque não quebra nem repete o aviso')
        ok('não liberou' in pg.inner_text('#pfinst-t'), perfil+': sem evento do Chrome, a mensagem diz o motivo')
        pg.evaluate("window.dispatchEvent(Object.assign(new Event('appinstalled'),{}))"); pg.wait_for_timeout(300)
        ok(pg.evaluate("getComputedStyle(document.getElementById('pfinst')).display")=='none', perfil+': depois de instalado, a barra some')
        ctx.close()
    b.close()
sys.exit(0 if all(c for c,_ in R) else 1)
