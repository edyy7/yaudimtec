#!/usr/bin/env node
"use strict";
// Sobe api/pedido.js e api/baixa.js em http://localhost:3000 SEM Vercel CLI e sem login (só para testes locais).
// Use junto do emulador do Firestore:
//   FIRESTORE_EMULATOR_HOST=127.0.0.1:8080 PF_PROJECT_ID=demo-pedefacil node scripts/servidor-local.js
const http = require("http"), path = require("path");
if (!process.env.FIRESTORE_EMULATOR_HOST) { console.error("Defina FIRESTORE_EMULATOR_HOST (ex.: 127.0.0.1:8080). Sem isso o servidor falaria com o banco de verdade, e este script é só para o emulador."); process.exit(2); }
const rotas = { "/api/pedido": require(path.join(__dirname, "..", "api", "pedido.js")), "/api/baixa": require(path.join(__dirname, "..", "api", "baixa.js")) };
const porta = +process.env.PORT || 3000;
http.createServer((req, res) => {
  const h = rotas[req.url.split("?")[0]];
  if (!h) { res.statusCode = 404; return res.end("{}"); }
  let raw = "";
  req.on("data", (c) => { raw += c; });
  req.on("end", async () => {
    try { req.body = raw ? JSON.parse(raw) : {}; } catch (e) { req.body = null; }
    res.status = (c) => { res.statusCode = c; return res; };
    res.json = (o) => { res.setHeader("Content-Type", "application/json"); res.end(JSON.stringify(o)); };
    try { await h(req, res); } catch (e) { console.error(e); if (!res.writableEnded) { res.statusCode = 500; res.end("{}"); } }
  });
}).listen(porta, () => console.log("API local em http://localhost:" + porta + "  (emulador: " + process.env.FIRESTORE_EMULATOR_HOST + ")"));
