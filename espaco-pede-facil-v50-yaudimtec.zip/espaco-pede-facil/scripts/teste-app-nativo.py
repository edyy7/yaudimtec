# Teste REAL no Chromium com um "Capacitor" de mentira que grava as chamadas ao plugin PfAlert (a camada Android em nativo/android-extra).
# pip install playwright && playwright install chromium; servir a pasta: python3 -m http.server 8765
from playwright.sync_api import sync_playwright
import json, sys
R=[]
def ok(c,m): R.append(bool(c)); print(('OK  ' if c else 'FALHA ')+m)
MOCK="""
window.__calls=[];window.__perm={notificacoes:false,telaCheia:false,sobrepor:false,bateria:false,alarmeExato:true};
window.Capacitor={isNativePlatform:()=>true,isPluginAvailable:n=>n==='PfAlert',Plugins:{PfAlert:new Proxy({},{get:(t,m)=>(a)=>{window.__calls.push([m,a||{}]);if(m==='status')return Promise.resolve(Object.assign({},window.__perm));return Promise.resolve({})}})}};
"""
def calls(pg,m): return [a for (n,a) in pg.evaluate('window.__calls') if n==m]
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':800}); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
    pg.add_init_script(MOCK)
    pg.goto('http://localhost:8765/index.html',wait_until='load')
    pg.evaluate("localStorage.setItem('pf-sess',JSON.stringify({uid:'o1',email:'a@b.com'}))")
    pg.goto('http://localhost:8765/app/loja/index.html?op=ped',wait_until='load'); pg.wait_for_timeout(2500)
    pg.evaluate("ONB=false;S.nicho='Lanchonete';render()"); pg.wait_for_timeout(500)
    ok(len(calls(pg,'start'))==1 and calls(pg,'start')[0].get('title')=='Yaudimtec ativo','login: liga o serviço fixo "Yaudimtec ativo" (tela apagada)')
    ok(pg.evaluate("getComputedStyle(document.getElementById('pfinst')).display")=='none','dentro do app nativo, a barra "Baixar e instalar" não aparece')
    # permissões: a barra pede uma de cada vez
    pg.wait_for_timeout(600)
    ok(pg.evaluate("!!document.getElementById('pfperm')&&getComputedStyle(document.getElementById('pfperm')).display!=='none'"),'faltam permissões: barra "Ativar" aparece')
    t=pg.inner_text('#pfperm-t'); ok('notificações' in t and '4 restantes' in t,'primeiro pede notificações ('+t[-48:]+')')
    pg.click('#pfperm-go'); pg.wait_for_timeout(200)
    ok(calls(pg,'pedir')==[{'which':'notificacoes'}],'toque abre o pedido de notificações')
    for k,txt in [('notificacoes','tela cheia'),('telaCheia','sobrepor'),('sobrepor','bateria')]:
        pg.evaluate("window.__perm['%s']=true"%k); pg.evaluate("pfNatPerm()"); pg.wait_for_timeout(300)
        ok(txt in pg.inner_text('#pfperm-t'),'depois de '+k+': próximo passo é '+txt)
    pg.evaluate("window.__perm.bateria=true"); pg.evaluate("pfNatPerm()"); pg.wait_for_timeout(300)
    ok(pg.evaluate("getComputedStyle(document.getElementById('pfperm')).display")=='none','tudo liberado: a barra some')
    # pedido novo: alarme nativo (e não o bip da página)
    pg.evaluate("window.__calls=[];checkNew()"); pg.evaluate("S.orders=S.orders||[];S.orders.push({id:Date.now(),st:'ok',fase:'novo',name:'Cliente',items:'1x X',total:10});S.nome='Lanche do Zé'"); 
    n=pg.evaluate("checkNew()")
    al=calls(pg,'alarm'); ok(n==1 and len(al)==1,'pedido novo dispara o alarme nativo (1 vez)')
    ok(al and 'Novo pedido' in al[0]['title'] and '1 pedido novo' in al[0]['body'] and 'Lanche do Zé' in al[0]['body'],'alarme com título e texto certos: '+(al[0]['body'] if al else ''))
    # silenciar ao toque
    pg.evaluate("window.__calls=[]"); pg.mouse.click(200,400); pg.wait_for_timeout(200)
    ok(len(calls(pg,'silence'))>=1,'tocar na tela silencia o alarme')
    # lembrete agendado (agenda)
    pg.evaluate("window.__calls=[];S.modo='agenda';S.bookings=[{id:'987654',date:'2099-01-01',time:'10:00',name:'Ana'}];PFT=0;pfNatTick()"); pg.wait_for_timeout(300)
    sc=calls(pg,'schedule'); ok(len(sc)==1 and sc[0]['body']=='Ana às 10:00' and sc[0]['id']==987654,'reserva confirmada vira lembrete 15 min antes')
    import datetime
    esp=int(datetime.datetime(2099,1,1,10,0).timestamp()*1000)-15*60000
    ok(sc and abs(sc[0]['at']-esp)<=24*3600*1000,'horário do lembrete = 15 min antes da reserva')
    pg.evaluate("window.__calls=[];PFT=0;pfNatTick()"); pg.wait_for_timeout(200)
    ok(len(calls(pg,'schedule'))==0,'não agenda a mesma reserva duas vezes')
    # sair: desliga o serviço
    pg.evaluate("window.__calls=[];pfNatStop()"); pg.wait_for_timeout(200)
    ok(len(calls(pg,'stop'))==1,'sair desliga o serviço')
    ok(not errs,'sem erro na página '+str(errs[:2]))
    # fora do app nativo (navegador comum) nada muda: bip da página e barra de instalar
    ctx2=b.new_context(viewport={'width':390,'height':800}); q=ctx2.new_page(); q.goto('http://localhost:8765/app/adm/index.html?op=adm',wait_until='load'); q.wait_for_timeout(1500)
    ok(q.evaluate("typeof PFA!=='undefined'&&PFA.ok()")==False and q.evaluate("!document.getElementById('pfperm')"),'navegador comum: sem camada nativa e sem barra de permissões')
    b.close()
sys.exit(0 if all(R) else 1)
