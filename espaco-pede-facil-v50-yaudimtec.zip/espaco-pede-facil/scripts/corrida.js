#!/usr/bin/env node
"use strict";
// Teste de corrida do estoque: dispara N pedidos AO MESMO TEMPO para o mesmo produto (que deve ter 1 unidade) e confere
// que só um passa. Node 18+, sem dependências.
//
// uso:   node corrida.js <url> <slug> <produtoId> <preco> [paralelos=5]
// ex.:   node corrida.js https://espacopedefacil.vercel.app minha-loja 1794268070711 89.9 5
//
// ANTES de rodar (senão o resultado não prova nada):
//   - a loja está ABERTA e o produto tem estoque_atual = 1 (painel do lojista, salvo na nuvem);
//   - o contador reservado/<produtoId> não existe ou está em 0 (apague os pedidos de testes anteriores pelo painel:
//     "Excluir pedido" devolve o reservado; ou dê baixa neles);
//   - <preco> é o preço do produto (o servidor recusa total menor que o dele). Produto sem adicionais, para a conta ficar simples.
// Os pedidos de teste ficam na loja (um deles vale). Apague depois pelo painel.
const crypto = require("crypto");

const [url, slug, pid, preco, nArg] = process.argv.slice(2);
const N = Math.max(2, parseInt(nArg || "5", 10) || 5);
if (!url || !/^https?:\/\//.test(url) || !/^[a-z0-9-]{1,40}$/.test(slug || "") || !Number.isFinite(+pid) || !(+preco >= 0) || preco === undefined) {
  console.error("uso: node corrida.js <url> <slug> <produtoId> <preco> [paralelos=5]");
  process.exit(2);
}

function pedido(i) {
  return {
    slug,
    pedido: {
      id: Date.now() + i, // id = hora em ms (único por pedido)
      tt: crypto.randomBytes(16).toString("hex"),
      name: "Teste Corrida " + (i + 1), phone: "", total: +preco, pag: "local", ent: "retirada",
      addr: "", obs: "teste de corrida (apagar)", lin: [{ id: +pid, q: 1, opt: "" }], st: "ok",
    },
  };
}

async function um(i) {
  const t = Date.now();
  try {
    const r = await fetch(url.replace(/\/$/, "") + "/api/pedido", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(pedido(i)), signal: AbortSignal.timeout(15000),
    });
    let j = {}; try { j = await r.json(); } catch (e) { /* sem corpo */ }
    return { i, status: r.status, erro: j.erro || "", id: j.id, ms: Date.now() - t };
  } catch (e) {
    return { i, status: 0, erro: String(e && e.name === "TimeoutError" ? "timeout" : e && e.message), ms: Date.now() - t };
  }
}

(async () => {
  console.log("Disparando " + N + " pedidos ao mesmo tempo em " + url + " (loja " + slug + ", produto " + pid + ")...");
  const t0 = Date.now();
  const rs = await Promise.all(Array.from({ length: N }, (_, i) => um(i)));
  const total = Date.now() - t0;
  rs.forEach((r) => console.log("  pedido " + (r.i + 1) + ": HTTP " + r.status + (r.erro ? " (" + r.erro + ")" : "") + (r.id ? " id " + r.id : "") + " em " + r.ms + " ms"));

  const ok = rs.filter((r) => r.status === 200);
  const esgot = rs.filter((r) => r.status === 409 && r.erro === "estoque_insuficiente");
  const outros = rs.filter((r) => !ok.includes(r) && !esgot.includes(r));
  console.log("\nResumo: " + ok.length + " aceito(s), " + esgot.length + " recusado(s) por estoque, " + outros.length + " outro(s). Tempo total: " + total + " ms.");

  const falhas = [];
  if (ok.length > 1) falhas.push("PASSOU MAIS DE UM PEDIDO (" + ok.length + "): overselling. Guarde o valor do contador e o log da Vercel (api/pedido).");
  if (ok.length === 0) falhas.push("NENHUM pedido passou: confira se o estoque é 1, se a loja está aberta e se o contador estava em 0 antes do teste.");
  if (outros.length) falhas.push("Respostas inesperadas: " + outros.map((r) => r.status + (r.erro ? "/" + r.erro : "")).join(", ") + " (409 loja_fechada, 422 preço/produto, 502 gravacao/falha: veja o log da Vercel).");
  if (total >= 5000) falhas.push("Demorou " + total + " ms (esperado menos de 5 s).");

  if (falhas.length) { console.log("\nFALHOU:\n- " + falhas.join("\n- ")); } else { console.log("\nPASSOU: exatamente 1 pedido aceito, " + (N - 1) + " recusados por estoque, dentro do tempo."); }
  console.log("\nAgora confira no console do Firebase: pf_lojas/<uid>/reservado/" + pid + " deve estar com q = 1 (nem 0, nem " + N + ").");
  console.log("Depois apague os pedidos de teste pelo painel do lojista.");
  process.exit(falhas.length ? 1 : 0);
})();
