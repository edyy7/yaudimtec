# Teste REAL no Chromium (pip install playwright && playwright install chromium; servir a pasta: python3 -m http.server 8765):
# dono logado → aba Apps → cada app tem botão "Enviar pelo WhatsApp" com mensagem e link certos.
from playwright.sync_api import sync_playwright
from urllib.parse import unquote
import json, sys
R=[]
def ok(c,m): R.append(bool(c)); print(('OK  ' if c else 'FALHA ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={'width':390,'height':800}); pg=ctx.new_page(); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
    pg.goto('http://localhost:8765/index.html',wait_until='load')
    pg.evaluate("localStorage.setItem('pf-sess',JSON.stringify({uid:'o1',email:'a@b.com'}))")
    pg.goto('http://localhost:8765/app/adm/index.html?op=adm',wait_until='load'); pg.wait_for_timeout(2000)
    pg.evaluate("ONB=false;S.nicho='Lanchonete';tab='apps';render()"); pg.wait_for_timeout(500)
    links={a.get_attribute('data-pfwa'):unquote(a.get_attribute('href')) for a in pg.query_selector_all('a[data-pfwa]')}
    ok(sorted(links)==['adm','cozinha','entregas','garcom','loja'],'5 botões de WhatsApp, um por app')
    ok(all(h.startswith('https://wa.me/?text=') for h in links.values()),'todos abrem o WhatsApp (wa.me)')
    ok('/app/cozinha/?op=kds&install=1' in links['cozinha'] and 'Yaudimtec Cozinha' in links['cozinha'],'sem link da equipe: manda o endereço do app com install=1')
    # com os links da equipe gerados: a mensagem leva o link de acesso e o passo a passo
    pg.evaluate("S.equipeToken='abc123';S.equipeSlug='minha-loja';tab='apps';render()"); pg.wait_for_timeout(500)
    links={a.get_attribute('data-pfwa'):unquote(a.get_attribute('href')) for a in pg.query_selector_all('a[data-pfwa]')}
    for k,op in [('cozinha','kds'),('entregas','ent'),('garcom','mesas'),('loja','ped')]:
        ok('/equipe/minha-loja' in links[k] and 'op='+op in links[k] and 'Peça acesso' in links[k] and 'Baixar e instalar' in links[k], k+': link da equipe (op='+op+') + passo a passo')
    ok('/app/adm/?op=adm&install=1' in links['adm'],'ADM (do dono): link direto do app, sem pedir acesso')
    ok(not errs,'sem erro na página '+str(errs[:2]))
    b.close()
sys.exit(0 if all(R) else 1)
