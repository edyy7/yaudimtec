#!/usr/bin/env bash
# APK NATIVO por perfil, com login pelas contas Google do próprio Android (não do Chrome).
# Requisitos (no seu computador, com internet): Node 18+, Java 17+, Android SDK (Android Studio).
set -e
cd "$(dirname "$0")"; mkdir -p saida
for p in cozinha garcom loja adm entregas; do
  echo "=== $p ==="
  rm -rf "build/$p"; mkdir -p "build/$p/www"; cd "build/$p"
  cp "../../$p/capacitor.config.json" .
  echo '<!doctype html><title>Yaudimtec</title>' > www/index.html
  npm init -y >/dev/null
  npm i @capacitor/core @capacitor/cli @capacitor/android @capgo/capacitor-social-login >/dev/null
  npx cap add android >/dev/null
  # camada de alertas do Yaudimtec: serviço fixo, alarme, lembrete, permissões, tela acesa e sobrepor apps (nativo/android-extra)
  node ../../patch-android.js android
  # ícone próprio de cada perfil (ADM roxo, Loja vermelho, Cozinha laranja, Garçom verde, Entregas azul)
  mkdir -p resources && cp "../../../icons/$p-512.png" resources/icon-only.png && cp resources/icon-only.png resources/icon.png
  npm i -D @capacitor/assets >/dev/null && npx capacitor-assets generate --android --iconBackgroundColor '#ffffff' >/dev/null || echo "AVISO: ícone do $p não aplicado (veja nativo/LEIA-ME.md)"
  npx cap sync android >/dev/null
  ( cd android && ./gradlew assembleDebug )
  cp android/app/build/outputs/apk/debug/app-debug.apk "../../saida/yaudimtec-$p.apk"
  cd ../..
done
echo "APKs em nativo/saida/"
