// Acrescenta ao projeto Android gerado pelo Capacitor a camada de alertas do Yaudimtec:
// serviço fixo, alarme, lembrete agendado, permissões e MainActivity com o plugin registrado.
// Uso: node patch-android.js <pasta android> [pacote]   (idempotente)
const fs = require("fs"), path = require("path");
const [, , androidDir] = process.argv;
if (!androidDir) { console.error("uso: node patch-android.js <pasta android>"); process.exit(1); }
const extra = path.join(__dirname, "android-extra");
const src = path.join(androidDir, "app", "src", "main");

// 1) classes do plugin
const dst = path.join(src, "java", "br", "com", "pedefacil", "alert");
fs.mkdirSync(dst, { recursive: true });
["PfAlertPlugin.java", "PfAlertService.java", "PfAlarmReceiver.java"].forEach((f) => fs.copyFileSync(path.join(extra, "java", f), path.join(dst, f)));

// 2) MainActivity do app (mantém o pacote que o Capacitor gerou)
function acha(dir) {
  for (const n of fs.readdirSync(dir)) {
    const p = path.join(dir, n);
    if (fs.statSync(p).isDirectory()) { const r = acha(p); if (r) return r; } else if (n === "MainActivity.java") return p;
  }
  return null;
}
const ma = acha(path.join(src, "java"));
if (!ma) { console.error("MainActivity.java não encontrada"); process.exit(1); }
const pkg = /package\s+([\w.]+)\s*;/.exec(fs.readFileSync(ma, "utf8"))[1];
fs.writeFileSync(ma, fs.readFileSync(path.join(extra, "MainActivity.java.tpl"), "utf8").replace(/__PKG__/g, pkg));

// 3) manifest: permissões, serviço e receptor
const mf = path.join(src, "AndroidManifest.xml");
let x = fs.readFileSync(mf, "utf8");
if (!x.includes("br.com.pedefacil.alert.PfAlertService")) {
  const perms = ["POST_NOTIFICATIONS", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_SPECIAL_USE", "USE_FULL_SCREEN_INTENT", "WAKE_LOCK", "VIBRATE", "SYSTEM_ALERT_WINDOW", "SCHEDULE_EXACT_ALARM", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"]
    .filter((p) => !x.includes("android.permission." + p + '"'))
    .map((p) => '    <uses-permission android:name="android.permission.' + p + '" />').join("\n");
  x = x.replace("<application", perms + "\n\n    <application");
  const comps = `
        <service android:name="br.com.pedefacil.alert.PfAlertService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="Recebe pedidos e toca o alarme com a tela apagada" />
        </service>
        <receiver android:name="br.com.pedefacil.alert.PfAlarmReceiver" android:exported="false" />
    `;
  x = x.replace("</application>", comps + "</application>");
  fs.writeFileSync(mf, x);
}
console.log("Camada de alertas aplicada em " + androidDir + " (pacote " + pkg + ")");
