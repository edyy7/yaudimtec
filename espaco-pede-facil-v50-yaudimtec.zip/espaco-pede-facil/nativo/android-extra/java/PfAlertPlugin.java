package br.com.pedefacil.alert;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Ponte entre o site (JavaScript) e os recursos do Android: serviço, alarme, lembrete agendado, permissões e tela sempre acesa. */
@CapacitorPlugin(name = "PfAlert")
public class PfAlertPlugin extends Plugin {

    private Context ctx() { return getContext(); }

    private void svc(String action, String title, String body) {
        Intent i = new Intent(ctx(), PfAlertService.class).setAction(action);
        if (title != null) i.putExtra("title", title);
        if (body != null) i.putExtra("body", body);
        if (Build.VERSION.SDK_INT >= 26) ctx().startForegroundService(i); else ctx().startService(i);
    }

    private void open(Intent i) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx().startActivity(i); } catch (Exception e) {
            try { ctx().startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx().getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e2) { /* sem tela de ajustes */ }
        }
    }

    /** Liga o serviço fixo ("Yaudimtec ativo") que mantém o app vivo com a tela apagada. */
    @PluginMethod public void start(PluginCall c) { svc(PfAlertService.A_START, c.getString("title", "Yaudimtec ativo"), null); c.resolve(); }
    @PluginMethod public void stop(PluginCall c) { svc(PfAlertService.A_STOP, null, null); c.resolve(); }
    /** Toca o alarme agora: som em loop, vibração, tela acesa, notificação em tela cheia. */
    @PluginMethod public void alarm(PluginCall c) { svc(PfAlertService.A_ALARM, c.getString("title", "Novo pedido!"), c.getString("body", "")); c.resolve(); }
    @PluginMethod public void silence(PluginCall c) { svc(PfAlertService.A_SILENCE, null, null); c.resolve(); }

    /** Lembrete agendado (hora exata, funciona com o app fechado). */
    @PluginMethod public void schedule(PluginCall c) {
        final long at = c.getData().optLong("at", -1L); // optLong é do JSONObject (sempre existe); evita depender de PluginCall.getLong
        Integer id = c.getInt("id", 1);
        if (at < 0) { c.reject("faltou o horário (at, em milissegundos)"); return; }
        AlarmManager am = (AlarmManager) ctx().getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(ctx(), PfAlarmReceiver.class).putExtra("title", c.getString("title", "Lembrete")).putExtra("body", c.getString("body", ""));
        PendingIntent pi = PendingIntent.getBroadcast(ctx(), 9000 + id, i, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        boolean exato = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
        if (Build.VERSION.SDK_INT >= 23) { if (exato) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
        else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        JSObject r = new JSObject(); r.put("exato", exato); c.resolve(r);
    }

    @PluginMethod public void cancel(PluginCall c) {
        Integer id = c.getInt("id", 1);
        AlarmManager am = (AlarmManager) ctx().getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx(), 9000 + id, new Intent(ctx(), PfAlarmReceiver.class), PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        am.cancel(pi);
        c.resolve();
    }

    /** Tela sempre acesa enquanto o app está aberto (cozinha). */
    @PluginMethod public void keepAwake(final PluginCall c) {
        final boolean on = c.getBoolean("on", true);
        getActivity().runOnUiThread(new Runnable() { @Override public void run() {
            if (on) getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            c.resolve();
        } });
    }

    /** Situação de cada permissão que o alerta precisa. */
    @PluginMethod public void status(PluginCall c) {
        JSObject r = new JSObject();
        r.put("notificacoes", NotificationManagerCompat.from(ctx()).areNotificationsEnabled());
        r.put("telaCheia", Build.VERSION.SDK_INT < 34 || ((NotificationManager) ctx().getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent());
        r.put("sobrepor", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx()));
        PowerManager pm = (PowerManager) ctx().getSystemService(Context.POWER_SERVICE);
        r.put("bateria", Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(ctx().getPackageName()));
        AlarmManager am = (AlarmManager) ctx().getSystemService(Context.ALARM_SERVICE);
        r.put("alarmeExato", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
        c.resolve(r);
    }

    /** Pede/abre a tela de cada permissão. which: notificacoes | telaCheia | sobrepor | bateria | alarmeExato */
    @PluginMethod public void pedir(PluginCall c) {
        String w = c.getString("which", "");
        String pkg = "package:" + ctx().getPackageName();
        if ("notificacoes".equals(w)) {
            if (Build.VERSION.SDK_INT >= 33 && getActivity() != null) ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9101);
            else open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx().getPackageName()));
        } else if ("telaCheia".equals(w)) {
            if (Build.VERSION.SDK_INT >= 34) open(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse(pkg)));
        } else if ("sobrepor".equals(w)) {
            open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse(pkg)));
        } else if ("bateria".equals(w)) {
            open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse(pkg)));
        } else if ("alarmeExato".equals(w)) {
            if (Build.VERSION.SDK_INT >= 31) open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse(pkg)));
        }
        c.resolve();
    }
}
