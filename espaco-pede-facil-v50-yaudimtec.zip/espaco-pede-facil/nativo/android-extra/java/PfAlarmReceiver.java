package br.com.pedefacil.alert;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Disparado pelo AlarmManager na hora do lembrete: acorda o serviço e toca o alarme, mesmo com o app fechado. */
public class PfAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent in) {
        Intent s = new Intent(ctx, PfAlertService.class).setAction(PfAlertService.A_ALARM);
        s.putExtra("title", in.getStringExtra("title"));
        s.putExtra("body", in.getStringExtra("body"));
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(s); else ctx.startService(s);
    }
}
