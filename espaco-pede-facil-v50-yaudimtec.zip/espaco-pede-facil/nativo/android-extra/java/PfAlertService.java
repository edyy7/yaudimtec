package br.com.pedefacil.alert;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;

/**
 * Serviço em primeiro plano do Yaudimtec: mantém o app vivo com a tela apagada (aviso fixo "ativo"),
 * e quando chega pedido novo ou lembrete toca alarme em loop, vibra, acende a tela, mostra notificação em tela cheia
 * e (com a permissão "sobrepor outros apps") traz o app para a frente.
 */
public class PfAlertService extends Service {
    public static final String A_START = "pf.start", A_STOP = "pf.stop", A_ALARM = "pf.alarm", A_SILENCE = "pf.silence";
    public static final String CH_LISTEN = "pf_ativo", CH_ALARM = "pf_alarme";
    static final int ID_LISTEN = 7001, ID_ALARM = 7002;
    static final long ALARM_MAX_MS = 90_000L;

    private MediaPlayer player;
    private PowerManager.WakeLock wake;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = new Runnable() { @Override public void run() { silence(); } };
    private String listenTitle = "Yaudimtec ativo";

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? A_START : String.valueOf(intent.getAction());
        channels();
        if (intent != null && intent.getStringExtra("title") != null && A_START.equals(action)) listenTitle = intent.getStringExtra("title");
        goForeground();
        if (A_STOP.equals(action)) { silence(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        if (A_SILENCE.equals(action)) { silence(); return START_STICKY; }
        if (A_ALARM.equals(action)) alarm(intent.getStringExtra("title"), intent.getStringExtra("body"));
        return START_STICKY;
    }

    @Override public void onDestroy() { silence(); super.onDestroy(); }

    private void channels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel a = new NotificationChannel(CH_LISTEN, "Yaudimtec ativo", NotificationManager.IMPORTANCE_LOW);
        a.setShowBadge(false);
        nm.createNotificationChannel(a);
        NotificationChannel b = new NotificationChannel(CH_ALARM, "Alarme de pedido novo", NotificationManager.IMPORTANCE_HIGH);
        b.setSound(null, null); // o som é tocado pelo serviço (stream de ALARME), não pelo canal
        b.enableVibration(false);
        b.setBypassDnd(true);
        b.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(b);
    }

    private PendingIntent openApp(boolean alarm) {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i == null) i = new Intent();
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        i.putExtra("pf_alarm", alarm);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getActivity(this, alarm ? 1 : 0, i, fl);
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    private void goForeground() {
        Notification n = builder(CH_LISTEN).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(listenTitle)
            .setContentText("Recebendo pedidos. Toque para abrir.").setOngoing(true).setContentIntent(openApp(false)).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID_LISTEN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(ID_LISTEN, n);
    }

    private void alarm(String title, String body) {
        if (title == null || title.length() == 0) title = "Novo pedido!";
        if (body == null) body = "";
        wakeScreen();
        startSound();
        PendingIntent full = openApp(true);
        Intent sil = new Intent(this, PfAlertService.class).setAction(A_SILENCE);
        PendingIntent silPi = PendingIntent.getService(this, 2, sil, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = builder(CH_ALARM).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(body)
            .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(full).setFullScreenIntent(full, true)
            .addAction(new Notification.Action.Builder(null, "Silenciar", silPi).build());
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(ID_ALARM, b.build());
        // "sobrepor outros apps": com essa permissão o Android deixa o app abrir sozinho por cima do que estiver na tela
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            try { full.send(); } catch (Exception e) { /* sem permissão: fica a notificação em tela cheia */ }
        }
        h.removeCallbacks(autoStop);
        h.postDelayed(autoStop, ALARM_MAX_MS);
    }

    @SuppressWarnings("deprecation")
    private void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (wake != null && wake.isHeld()) wake.release();
            wake = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "bemdi:alarme");
            wake.acquire(15_000L);
        } catch (Exception e) { /* sem wake lock: segue só com som e notificação */ }
    }

    private void startSound() {
        stopSound();
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            player.setDataSource(this, u);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) { stopSound(); }
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(new long[]{0, 700, 400}, 0));
                else v.vibrate(new long[]{0, 700, 400}, 0);
            }
        } catch (Exception e) { /* sem vibração */ }
    }

    private void stopSound() {
        try { if (player != null) { player.stop(); player.release(); } } catch (Exception e) { /* já parado */ }
        player = null;
    }

    private void silence() {
        h.removeCallbacks(autoStop);
        stopSound();
        try { ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).cancel(); } catch (Exception e) { /* sem vibração */ }
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Exception e) { /* já solto */ }
        try { ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID_ALARM); } catch (Exception e) { /* nada a cancelar */ }
    }
}
