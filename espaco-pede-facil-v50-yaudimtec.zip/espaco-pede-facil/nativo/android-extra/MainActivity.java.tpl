package __PKG__;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

import br.com.pedefacil.alert.PfAlertPlugin;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(PfAlertPlugin.class);
        super.onCreate(savedInstanceState);
        sobreLockscreen(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        sobreLockscreen(intent);
    }

    /** Aberto pelo alarme: aparece por cima da tela de bloqueio e acende a tela. */
    private void sobreLockscreen(Intent i) {
        if (i == null || !i.getBooleanExtra("pf_alarm", false)) return;
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    }

    /** Mantém os temporizadores do site rodando com o app em segundo plano (o serviço fixo segura o processo vivo). */
    @Override public void onPause() {
        super.onPause();
        try { getBridge().getWebView().resumeTimers(); } catch (Exception e) { /* sem WebView */ }
    }
}
