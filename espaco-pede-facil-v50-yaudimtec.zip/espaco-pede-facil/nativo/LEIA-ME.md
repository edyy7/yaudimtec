# APK nativo: alertas de pedido (alarme, tela acesa, sobrepor apps)

Estes são os APKs que têm a camada de alertas do Android (pasta `android-extra/`, aplicada por `patch-android.js` em cada build):
- **Serviço "Yaudimtec ativo"**: aviso fixo que mantém o app vivo com a tela apagada.
- **Pedido novo = alarme**: som em loop no volume de ALARME, vibração, tela acende, notificação em tela cheia e, com a permissão "sobrepor outros apps", o app abre sozinho por cima do que estiver na tela. Para sozinho em 90 s, ao tocar na tela ou no botão "Silenciar" da notificação.
- **Lembretes**: reservas da agenda viram alarme 15 min antes (hora exata, funciona com o app fechado).
- **Tela sempre acesa** nas telas de Cozinha, Loja e Garçom.
- **Permissões guiadas**: uma barra vermelha no topo pede uma por vez (notificações, tela cheia, sobrepor outros apps, bateria sem restrição) e some quando tudo está liberado.

## Gerar sem instalar nada (pelo GitHub)
GitHub → **Actions** → **Gerar APKs nativos** → **Run workflow** → endereço do site na Vercel (sem `https://`). Os 5 `.apk` saem em **Artifacts → apks-nativos** (versão de teste, instala direto).

## Limites que o Android impõe
- Cada permissão precisa ser liberada por você numa tela do Android (o app abre a tela certa).
- Em alguns celulares (Xiaomi, Samsung, Motorola) é preciso também liberar "início automático" e "sem restrição de bateria" nos ajustes do aparelho.
- Se o app for **fechado à força**, o Android para o serviço. Para alertar mesmo assim é preciso notificação push (Firebase Cloud Messaging), que exige cadastrar os apps Android no Firebase.
- O login "Entrar com Google" no app nativo só funciona depois da configuração descrita abaixo. O login por ID e senha funciona.

# APK nativo (login pelas contas Google do Android)

Diferente da pasta `twa/` (que usa o Chrome), estes APKs usam o seletor de contas do próprio Android.

## Antes de gerar
1. No Firebase (projeto `delivery-67d14`), em **Configurações → Seus apps**, adicione um app Android para **cada pacote** (br.com.pedefacil.cozinha, .garcom, .loja, .adm, .entregas) com o **SHA-1** da chave de cada um (`cd android && ./gradlew signingReport`).
2. Em **Authentication → Método de login → Google**, copie o **ID do cliente da Web** e cole em `PF_GOOGLE_WEB_CLIENT_ID` no `index.html` (hoje está vazio, e então o app usa o login pelo navegador).
3. Faça o deploy na Vercel.

## Gerar
`bash nativo/gerar-apks-nativos.sh` (Node 18+, Java 17+ e Android SDK). Os APKs saem em `nativo/saida/` (versão de teste; para publicar na Play Store é preciso assinar a versão release).

Se o login nativo falhar, confira o passo do plugin `@capgo/capacitor-social-login` para Android (ajuste na MainActivity, se a versão pedir).
