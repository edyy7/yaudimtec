// Prova extra: cliente declara st="ok" com pag="pix" (Pix exigido pela loja) — o servidor aceita?
process.env.FIRESTORE_EMULATOR_HOST = "localhost:8080"; delete process.env.VERCEL_ENV;
const h = require(require("path").join(__dirname, "..", "..", "..", "api", "pedido.js"));
const B = "http://localhost:8080/v1/projects/demo-pedefacil/databases/(default)/documents", R = (ok, s, b) => ({ ok, status: s, json: async () => b || {} });
const L = { nome: "Loja", modo: "cardapio", mods: { kds: true, entrega: true }, pix: "11999999999", sinal: true, pct: 30, services: [{ id: 2, name: "Suco", price: 7.5, opts: [] }] };
let saved = null;
global.fetch = async (url, o = {}) => { const u = String(url).replace(B, "");
  if (/^\/pf_slugs/.test(u)) return R(true, 200, { fields: { uid: { stringValue: "u1" } } });
  if (/^\/pf_lojas_publicas/.test(u)) return R(true, 200, { fields: { data: { stringValue: JSON.stringify(L) } } });
  if (/pedidos\?documentId/.test(u)) { saved = JSON.parse(o.body).fields; return R(true, 200); }
  return R(true, 200); };
const res = { setHeader() {}, status(c) { this.c = c; return this; }, json(j) { console.log("HTTP", this.c, JSON.stringify(j)); const f = k => saved && Object.values(saved[k] || {})[0]; console.log("gravado: st=" + f("st") + " pag=" + f("pag") + " sinal=" + f("sinal") + " fase=" + f("fase")); } };
h({ method: "POST", headers: {}, body: { slug: "loja-teste", pedido: { id: 1800000000001, tt: "b".repeat(32), name: "Cliente Teste", phone: "27999990000", total: 7.5, pag: "pix", ent: "retirada", addr: "", obs: "", lin: [{ id: 2, q: 1, opt: "" }], st: "ok" } } }, res);
