// Prova de conceito (NÃO faz parte do projeto): chama api/pedido.js com Firestore simulado.
process.env.FIRESTORE_EMULATOR_HOST = "localhost:8080"; delete process.env.VERCEL_ENV;
const path = require("path");
const API = path.join(__dirname, "..", "..", "..", "api", "pedido.js");
const handler = require(API);
let LOJA, commits, docs;
const B = "http://localhost:8080/v1/projects/demo-pedefacil/databases/(default)/documents";
const R = (ok, st, body) => ({ ok, status: st, json: async () => body || {} });
global.fetch = async (url, o = {}) => {
  const u = String(url).replace(B, "");
  if (/^\/pf_slugs\/loja-teste/.test(u)) return R(true, 200, { fields: { uid: { stringValue: "u1" } } });
  if (/^\/pf_lojas_publicas\/u1/.test(u)) return R(true, 200, { fields: { data: { stringValue: JSON.stringify(LOJA) } } });
  if (/^\/pf_lojas\/u1\/reservado\//.test(u)) return R(false, 404);
  if (/:beginTransaction$/.test(u)) return R(true, 200, { transaction: "tx" });
  if (/:rollback$/.test(u)) return R(true, 200);
  if (/^\/pf_lojas\/u1:runQuery/.test(u)) return R(true, 200, [{}]);
  if (/:commit$/.test(u)) { commits.push(JSON.parse(o.body)); return R(true, 200); }
  const m = /^\/(pf_lojas\/u1\/pedidos|pf_rastreio)\?documentId=(.+)$/.exec(u);
  if (m) { const k = m[1] + "/" + decodeURIComponent(m[2]); if (docs[k]) return R(false, 409); docs[k] = JSON.parse(o.body); return R(true, 200); }
  return R(false, 404);
};
const call = (body) => new Promise((resolve) => {
  const res = { setHeader() {}, status(c) { this.c = c; return this; }, json(j) { resolve({ code: this.c, body: j }); } };
  handler({ method: "POST", body, headers: {} }, res);
});
const base = () => ({ nome: "Loja", modo: "cardapio", mods: { kds: true, entrega: true }, pix: "11999999999", sinal: true, pct: 30,
  services: [{ id: 1, name: "Pastel", price: 10, opts: ["Queijo:2,5"], estoque_atual: 2 }, { id: 2, name: "Suco", price: 7.5, opts: [] }] });
let n = 0;
const ped = (x) => Object.assign({ id: 1800000000000 + (++n), tt: String(n).padStart(32, "a"), name: "Cliente Teste", phone: "27999990000", total: 10, pag: "local", ent: "retirada", addr: "", obs: "", lin: [{ id: 2, q: 1, opt: "" }], st: "ok" }, x);
const out = [];
async function t(nome, cfg, p) { LOJA = Object.assign(base(), cfg); commits = []; docs = {}; const r = await call({ slug: "loja-teste", pedido: p }); out.push(nome + " -> HTTP " + r.code + " " + JSON.stringify(r.body)); return r; }
(async () => {
  const fechada = { horarioOk: true, days: [], start: 8, end: 18 };
  await t("A1 loja fechada, st=ok      ", fechada, ped({ st: "ok" }));
  await t("A2 loja fechada, st=pend    ", fechada, ped({ st: "pend" }));
  const ls = { lin: [{ id: 1, q: 5, opt: "" }], total: 50 };
  await t("B1 estoque 2, pede 5, st=ok  ", {}, ped(Object.assign({ st: "ok" }, ls)));
  const rb = await t("B2 estoque 2, pede 5, st=pend", {}, ped(Object.assign({ st: "pend" }, ls)));
  out.push("   reservado gravado: " + JSON.stringify(commits.map(c => c.writes.filter(w => w.update && /reservado/.test(w.update.name)).map(w => w.update.fields || w.updateTransforms))));
  const en = { mods: { kds: true, entrega: false } };
  await t("C1 entrega desligada, st=ok  ", en, ped({ st: "ok", ent: "entrega", addr: "Rua X" }));
  await t("C2 entrega desligada, st=pend", en, ped({ st: "pend", ent: "entrega", addr: "Rua X" }));
  await t("D  st=pend SEM pag pix (nenhum Pix pago)", {}, ped({ st: "pend", pag: "local" }));
  // repetição: mesmo tt, ids diferentes
  LOJA = base(); commits = []; docs = {};
  const p1 = ped({}), p2 = Object.assign({}, p1, { id: p1.id + 777 });
  const r1 = await call({ slug: "loja-teste", pedido: p1 }), r2 = await call({ slug: "loja-teste", pedido: p2 });
  out.push("E  mesmo tt, 2 ids -> " + r1.code + "/" + r2.code + " pedidos gravados: " + Object.keys(docs).filter(k => /pedidos/.test(k)).length);
  // repetição em massa: 30 pedidos distintos, sem limite
  LOJA = base(); docs = {}; let ok = 0; for (let i = 0; i < 30; i++) { const r = await call({ slug: "loja-teste", pedido: ped({}) }); if (r.code === 200) ok++; }
  out.push("F  30 pedidos seguidos do mesmo cliente -> aceitos: " + ok + "/30 (sem limite de frequência)");
  await t("G  id gigante 9e15 (futuro)  ", {}, ped({ id: 9e15 }));
  await t("H  texto livre em opt (modo != cardapio)", { modo: "loja" }, ped({ lin: [{ id: 2, q: 1, opt: "<img src=x onerror=alert(1)>" }] }));
  console.log(out.join("\n"));
  const k = Object.keys(docs).filter(x => /pedidos/.test(x))[0];
  if (k) console.log("   items gravado:", JSON.stringify(docs[k].fields.items));
})();
