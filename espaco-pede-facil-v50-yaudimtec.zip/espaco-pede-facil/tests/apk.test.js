// APKs na nuvem: o fluxo do GitHub, o script e os 5 manifests precisam estar coerentes (o build em si roda no GitHub, com Android SDK).
const assert = require("assert"), fs = require("fs"), path = require("path");
const root = path.join(__dirname, ".."), rd = (...p) => fs.readFileSync(path.join(root, ...p), "utf8");
const perfis = JSON.parse(rd("scripts", "perfis.json"));
const wf = rd(".github", "workflows", "apk.yml"), sh = rd("twa", "gerar-apks-nuvem.sh");
assert.ok(/workflow_dispatch:/.test(wf) && /host:/.test(wf) && wf.includes("bash twa/gerar-apks-nuvem.sh"), "fluxo manual com o endereço do site");
assert.ok(wf.includes("BUBBLEWRAP_KEYSTORE_PASSWORD") && wf.includes("upload-artifact@v4") && wf.includes("name: apks") && wf.includes("name: chaves"), "fluxo: senhas sem perguntas e os arquivos saem em Artifacts");
assert.ok(sh.includes("for p in cozinha garcom loja adm entregas") && sh.includes("keytool -genkeypair") && sh.includes("bubblewrap build") && sh.includes("gerar-assetlinks.js"), "script: 5 perfis, chave, build e assetlinks");
const pacotes = new Set(), hosts = new Set();
Object.keys(perfis).forEach((d) => {
  const m = JSON.parse(rd("twa", d, "twa-manifest.json"));
  assert.strictEqual(m.packageId, perfis[d].pacote, d + ": pacote igual ao perfis.json");
  assert.ok(!pacotes.has(m.packageId), "pacote único"); pacotes.add(m.packageId);
  assert.ok(m.signingKey.path === "./chaves/" + d + ".keystore" && m.signingKey.alias === d, d + ": chave no caminho que o script cria");
  (JSON.stringify(m).match(/[a-z0-9.-]+\.vercel\.app/g) || []).forEach((h) => hosts.add(h));
});
assert.deepStrictEqual([...hosts], ["espaco-pede-facil-v27.vercel.app"], "um único endereço-modelo nos manifests (é ele que o script troca)");
assert.ok(sh.includes("espaco-pede-facil-v27"), "script troca exatamente o endereço-modelo");
console.log("apk.test.js: fluxo do GitHub, script e 5 manifests coerentes ok");
