// Executa o código REAL do botão "Baixar e instalar" (extraído do index.html) num navegador simulado.
// Regra: o botão existe SÓ no perfil ADM; em todos os outros perfis, no Criador e no Index não existe.
const fs = require("fs"), path = require("path"), vm = require("vm");
const html = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
const i = html.indexOf("/* ===== Instalar no celular (PWA)"), j = html.indexOf('if("serviceWorker" in navigator');
if (i < 0 || j < 0) throw new Error("bloco de instalar não encontrado");
const src = html.slice(i, j);

function run({pathname="/",search="",standalone=false,store={},ev=false,ua="Android Chrome",CRIROTA=false,home=false,EQS="",STAFF=null,ACCT=null,SUPER=false}){
  const els={};const mk=()=>({style:{},set innerHTML(v){this._h=v;const m=/id="(pfinst-[a-z]+)"/g;let x;while(x=m.exec(v))els[x[1]]=els[x[1]]||{style:{},set onclick(f){this._c=f}}},parentNode:{insertBefore(n){els.bar=n}},setAttribute(){},id:""});
  const app=mk();const ls={getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}};
  const listeners={};
  const ctx={EQS,STAFF,ACCT,SUPER,CRIROTA,homeOn:()=>home,TENANT:"",SLUG:"",DEMO:false,VC:false,location:{search,pathname,hash:"",protocol:"https:",origin:"https://x"},localStorage:ls,navigator:{userAgent:ua,standalone:standalone},MSStream:undefined,
   matchMedia:()=>({matches:standalone}),URLSearchParams,Date,
   document:{getElementById:id=>id==="app"?app:(id==="pfinst"?els.bar:els[id]||null),createElement:()=>{const b=mk();els.bar=b;return b},querySelector:()=>null,head:{appendChild(){}}},
   addEventListener:(n,f)=>{listeners[n]=f}};
  ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);
  if(ev)listeners.beforeinstallprompt({preventDefault(){},prompt(){},userChoice:Promise.resolve()});else ctx.pfInstSync();
  return {bar:els.bar,els,listeners,store,ctx};
}
const A = require("assert");
const shown=r=>!!r.bar&&r.bar.style.display==="flex";
// Todos os 5 perfis (já logados): botão aparece com o nome do próprio perfil (igual ao do manifest), por ?op= ou pelo caminho /app/<perfil>/
const P=JSON.parse(fs.readFileSync(path.join(__dirname,"..","scripts","perfis.json"),"utf8"));
let r;
for(const [d,p] of Object.entries(P)){
  const nome=JSON.parse(fs.readFileSync(path.join(__dirname,"..",p.manifest),"utf8")).name, k=({adm:"adm",ped:"loja",kds:"cozinha",ent:"entregas",garcom:"garcom"})[p.op], q="?op="+p.op;
  r=run({search:q});A.ok(shown(r),d+": botão aparece");A.ok(r.els["pfinst-go"].textContent.endsWith("Baixar e instalar "+nome),d+": botão com o nome "+nome);A.ok(/Instala só este perfil: /.test(r.els["pfinst-n"].textContent)&&r.els["pfinst-n"].textContent.includes(nome),d+": aviso com o nome do perfil");
  r=run({search:q,ev:true});A.ok(shown(r),d+": com o prompt do navegador");
  r=run({pathname:"/app/"+d+"/"});A.ok(shown(r),d+": pelo caminho /app/"+d+"/");
  r=run({search:q,home:true,ev:true});A.ok(shown(r),d+": aparece já na tela de entrada (antes do login), como no exemplo");
  r=run({search:q,home:true,ev:true});r.listeners.appinstalled();A.ok(!shown(r),d+": some na hora ao instalar (tela de entrada)");
  r=run({search:q,ua:"iPhone Safari"});A.ok(shown(r),d+": iPhone");
  r=run({search:q,standalone:true});A.ok(!shown(r),d+": instalado (app aberto): some");A.strictEqual(r.store["pf-inst-ok:"+k],"1");
  r=run({search:q,store:{["pf-inst-ok:"+k]:"1"}});A.ok(!shown(r),d+": já instalado: some");
  r=run({search:q,ev:true});r.listeners.appinstalled();A.ok(!shown(r),d+": some ao instalar");
  r=run({search:q+"&install=1",store:{["pf-inst-ok:"+k]:"1"}});A.ok(shown(r),d+": ?install=1: instalar de novo");
}
// instalar um perfil não esconde o botão dos outros (marca por perfil)
r=run({search:"?op=ped",store:{"pf-inst-ok:adm":"1"}});A.ok(shown(r),"Loja aparece mesmo com o ADM já instalado");
// fora dos perfis: sem botão
for(const q of ["?op=xyz",""]){for(const ev of [false,true]){r=run({search:q,ev});A.ok(!shown(r),"sem botão em "+(q||"/")+(ev?" (com prompt)":""))}}
r=run({CRIROTA:true,ev:true});A.ok(!shown(r),"Criador: sem botão");
r=run({home:true,ev:true});A.ok(!shown(r),"Index/home: sem botão");

// equipe que entra pelo link /equipe/<loja>: o perfil vem do login; o botão leva ao /app/<perfil>/ (manifest certo) e mantém a sessão
r=run({pathname:"/equipe/loja-teste",EQS:"loja-teste",STAFF:{papel:"ped",uid:"u1"}});
A.ok(shown(r),"equipe (Loja) em /equipe/...: botão aparece"); A.ok(r.els["pfinst-go"].textContent.endsWith("Baixar e instalar Yaudimtec Loja"),"botão com o nome do perfil da equipe");
r.ctx.location.href=""; r.els["pfinst-go"]._c&&r.els["pfinst-go"]._c(); A.strictEqual(r.ctx.location.href,"https://x/app/loja/?op=ped&install=1","botão leva ao endereço do perfil");
for(const [papel,nm] of [["kds","Yaudimtec Cozinha"],["ent","Yaudimtec Entregas"],["mesas","Yaudimtec Garçom"]]){r=run({pathname:"/equipe/loja-teste",EQS:"loja-teste",STAFF:{papel}});A.ok(shown(r)&&r.els["pfinst-go"].textContent.endsWith(nm),"equipe "+papel+": "+nm)}
r=run({pathname:"/equipe/loja-teste",EQS:"loja-teste",STAFF:{st:"load"}});A.ok(!shown(r),"equipe ainda sem login aprovado: sem botão");
r=run({pathname:"/equipe/loja-teste",EQS:"loja-teste",STAFF:{papel:"ped"},standalone:true});A.ok(!shown(r),"já instalado: sem botão");

// ADM (dono logado) no endereço raiz: o botão aparece e leva ao /app/adm/ (manifest do ADM), mantendo o login
r=run({pathname:"/",ACCT:{uid:"o1"}});A.ok(shown(r),"dono logado na raiz: botão aparece");A.ok(r.els["pfinst-go"].textContent.endsWith("Baixar e instalar Yaudimtec ADM"),"botão com o nome Yaudimtec ADM");
r.ctx.location.href="";r.els["pfinst-go"]._c&&r.els["pfinst-go"]._c();A.strictEqual(r.ctx.location.href,"https://x/app/adm/?op=adm&install=1","botão do ADM leva ao /app/adm/");
r=run({pathname:"/",ACCT:{uid:"o1"},SUPER:true});A.ok(!shown(r),"criador (super) não recebe o botão do ADM");
r=run({pathname:"/",ACCT:{uid:"o1"},standalone:true});A.ok(!shown(r),"ADM já instalado: sem botão");
r=run({pathname:"/"});A.ok(!shown(r),"visitante sem login: sem botão");
console.log("instalar.test.js: botão de instalar em cada um dos 5 perfis ok");
