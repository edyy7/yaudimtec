// Garante que /gestao não é capturado pela rota de loja (/:slug)
const assert = require("assert"), fs = require("fs"), path = require("path");
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "vercel.json"), "utf8"));
const rules = cfg.rewrites;
const match = (p) => {
  for (const r of rules) {
    const names = [];
    const src = r.source.replace(/:(\w+)\*/g, (_, n) => { names.push(n); return "(.*)"; })
      .replace(/:(\w+)\(([^)]+)\)/g, (_, n) => { names.push(n); return "([^/]+)"; })
      .replace(/:(\w+)/g, (_, n) => { names.push(n); return "([^/]+)"; });
    const m = new RegExp("^" + src + "$").exec(p);
    if (m) return r.destination.replace(/:(\w+)\*?/g, (_, n) => { const i = names.indexOf(n); return i > -1 ? m[i + 1] : ":" + n; });
  }
  return null;
};
assert.ok(match("/gestao").startsWith("/gestao/index.html"), "/gestao abre a Operação");
assert.strictEqual(match("/gestao/cozinha.html"), "/gestao/cozinha.html", "/gestao/cozinha.html é servido como arquivo");
assert.ok(match("/nome-da-loja").startsWith("/api/loja?slug="), "/loja vai para a função");
assert.ok(!match("/gestao/cozinha.html").startsWith("/api/"), "/gestao nunca cai na função da loja");
for (const f of ["manifest-cozinha.json","manifest-motoboy.json","manifest-lojista.json","manifest-garcom.json","manifest-adm.json"]) assert.ok(fs.existsSync(path.join(__dirname,"..",f)), f);
for (const f of ["index.html","lojista.html","cozinha.html","motoboy.html","adm.html"]) assert.ok(fs.existsSync(path.join(__dirname,"..","gestao",f)), f);
assert.strictEqual(match("/equipe/loja-do-edinaldo"), "/index.html", "/equipe/<loja> abre o app (modo equipe)");
assert.ok(!match("/equipe/loja-do-edinaldo").startsWith("/api/"), "/equipe nunca cai na função da loja");
assert.strictEqual(match("/criador"), "/index.html", "/criador abre o app (painel do Criador)");
console.log("rotas.test.js: todos os testes passaram");
