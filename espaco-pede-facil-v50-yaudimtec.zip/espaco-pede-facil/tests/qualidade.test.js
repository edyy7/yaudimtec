// Trava de qualidade: sintaxe, JSON, regras, letras mínimas e marca. Roda em `npm test` e no CI.
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(root, f), "utf8");
const SKIP = new Set(["node_modules", ".git", "docs", "vendor", "img"]);
function walk(d, out = []) {
  for (const n of fs.readdirSync(d)) {
    if (SKIP.has(n)) continue;
    const p = path.join(d, n);
    fs.statSync(p).isDirectory() ? walk(p, out) : out.push(p);
  }
  return out;
}
const files = walk(root);
const rel = (p) => path.relative(root, p);

// 1) todo JSON e manifesto é válido
for (const f of files.filter((p) => /\.(json|webmanifest)$/.test(p))) {
  assert.doesNotThrow(() => JSON.parse(fs.readFileSync(f, "utf8")), "JSON inválido: " + rel(f));
}
// 2) todo script inline das páginas compila; todo .js do servidor compila
const pages = files.filter((p) => /\.html$/.test(p) && !/prompts/.test(p));
for (const f of pages) {
  for (const m of fs.readFileSync(f, "utf8").matchAll(/<script(?![^>]*(?:type="application\/json"|src=))[^>]*>([\s\S]*?)<\/script>/g)) {
    assert.doesNotThrow(() => new vm.Script(m[1]), "script inline com erro de sintaxe: " + rel(f));
  }
}
for (const f of files.filter((p) => /\.js$/.test(p) && !/tests/.test(p) && !/scripts/.test(p))) {
  assert.doesNotThrow(() => new vm.Script(fs.readFileSync(f, "utf8").replace(/^#!.*\n/, "")), "erro de sintaxe: " + rel(f));
}
// 3) regras do Firestore balanceadas
{
  const r = read("firestore.rules");
  assert.strictEqual(r.split("{").length, r.split("}").length, "firestore.rules: chaves desbalanceadas");
  assert.strictEqual(r.split("(").length, r.split(")").length, "firestore.rules: parênteses desbalanceados");
}
// 4) acessibilidade: nenhuma letra abaixo de 14 px nas telas do app
for (const f of ["index.html", "afiliado.html", ...fs.readdirSync(path.join(root, "gestao")).map((n) => "gestao/" + n)]) {
  const pequenas = [...read(f).matchAll(/font-size:\s*(\d+(?:\.\d+)?)px/g)].filter((m) => +m[1] < 14).map((m) => m[0]);
  assert.deepStrictEqual(pequenas, [], f + ": letra menor que 14px " + pequenas.slice(0, 3));
}
// 5) marca: o nome público é Yaudimtec (domínio e pacotes Android não contam)
for (const f of files.filter((p) => /\.(html|js|json|webmanifest|md|rules)$/.test(p) && !/tests/.test(p))) {
  const t = fs.readFileSync(f, "utf8").replace(/espacopedefacil|br\.com\.pedefacil[\w.]*/gi, "");
  assert.ok(!/Espaço Pede Fácil|PedeFácil/.test(t), "marca antiga em " + rel(f));
}
console.log("qualidade.test.js: sintaxe, JSON, regras, letras e marca ok");
