// Atalho por arquivo (.url, .webloc, .desktop): executa o código REAL do botão (extraído do index.html) e confere o arquivo gerado.
const fs = require("fs"), path = require("path"), vm = require("vm"), A = require("assert");
const raiz = path.join(__dirname, "..");
const P = JSON.parse(fs.readFileSync(path.join(raiz, "scripts", "perfis.json"), "utf8"));
const MAN = { adm: "manifest-adm.json", ped: "manifest-lojista.json", kds: "manifest-cozinha.json", ent: "manifest-motoboy.json", garcom: "manifest-garcom.json" };
function roda(htmlFile, { search, ua }) {
  const html = fs.readFileSync(path.join(raiz, htmlFile), "utf8");
  const i = html.indexOf("/* ===== Instalar no celular (PWA)"), j = html.indexOf('if("serviceWorker" in navigator');
  const els = {}, baixados = [], ls = {}, timers = [];
  const mk = () => ({ style: {}, set innerHTML(v) { const m = /id="(pfinst-[a-z]+)"/g; let x; while ((x = m.exec(v))) els[x[1]] = els[x[1]] || { style: {}, set onclick(f) { this._c = f; } }; }, parentNode: { insertBefore(n) { els.bar = n; } }, setAttribute() {}, click() { baixados.push({ nome: this.download, href: this.href }); } });
  const app = mk();
  const ctx = { CRIROTA: false, homeOn: () => false, TENANT: "", SLUG: "", DEMO: false, VC: false, location: { search, pathname: "/", hash: "", protocol: "https:", origin: "https://exemplo.app" },
    localStorage: { getItem: (k) => (k in ls ? ls[k] : null), setItem: (k, v) => { ls[k] = String(v); }, removeItem: (k) => { delete ls[k]; } },
    navigator: { userAgent: ua, standalone: false }, MSStream: undefined, matchMedia: () => ({ matches: false }), URLSearchParams, Date,
    Blob: class { constructor(p) { this.txt = p.join(""); } }, URL: { createObjectURL: (b) => { ctx.__txt = b.txt; return "blob:x"; }, revokeObjectURL() {} },
    setTimeout: (f) => { timers.push(f); }, addEventListener() {},
    document: { getElementById: (id) => (id === "app" ? app : id === "pfinst" ? els.bar : els[id] || null), createElement: () => { const b = mk(); if (!els.bar) els.bar = b; return b; }, body: { appendChild() {}, removeChild() {} }, querySelector: () => null, head: { appendChild() {} } } };
  ctx.window = ctx; vm.createContext(ctx); vm.runInContext(html.slice(i, j), ctx); ctx.pfInstSync();
  return { els, baixados, ls, ctx, timers };
}
const UA = { win: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120", mac: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15) Safari/605", lin: "Mozilla/5.0 (X11; Linux x86_64) Chrome/120", and: "Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile", ios: "Mozilla/5.0 (iPhone; CPU iPhone OS 17) Safari/604" };
for (const file of ["index.html", "app/adm/index.html", "app/loja/index.html", "app/cozinha/index.html", "app/entregas/index.html", "app/garcom/index.html"]) {
  for (const [d, p] of Object.entries(P)) {
    const man = JSON.parse(fs.readFileSync(path.join(raiz, MAN[p.op]), "utf8")), q = "?op=" + p.op;
    const esperada = "https://exemplo.app" + man.start_url;
    for (const [so, ext, ini] of [["win", "url", "[InternetShortcut]\r\nURL=" + esperada], ["mac", "webloc", null], ["lin", "desktop", null]]) {
      const r = roda(file, { search: q, ua: UA[so] }); r.els["pfinst-go"]._c();
      A.strictEqual(r.baixados.length, 1, file + " " + d + " " + so + ": baixou 1 arquivo");
      A.strictEqual(r.baixados[0].nome, man.name + "." + ext, file + " " + d + " " + so + ": nome do arquivo");
      A.ok(r.ctx.__txt.includes(esperada), file + " " + d + " " + so + ": aponta para " + man.start_url);
      if (ini) A.ok(r.ctx.__txt.startsWith(ini), "formato .url");
      if (so === "mac") A.ok(/<plist[\s\S]*<key>URL<\/key>\s*<string>/.test(r.ctx.__txt), "formato .webloc");
      if (so === "lin") A.ok(/^\[Desktop Entry\]\nVersion=1.0\nType=Link\nName=/.test(r.ctx.__txt), "formato .desktop");
      A.ok(!r.ls["pf-inst-ok:" + ({ adm: "adm", ped: "loja", kds: "cozinha", ent: "entregas", garcom: "garcom" })[p.op]], "botão ainda não some antes do aviso");
      r.timers.forEach((f) => f()); A.ok(Object.keys(r.ls).some((k) => k.startsWith("pf-inst-ok:")), d + ": depois do aviso o perfil fica marcado como instalado (botão some)");
    }
    for (const so of ["and", "ios"]) { const r = roda(file, { search: q, ua: UA[so] }); r.els["pfinst-go"]._c(); A.strictEqual(r.baixados.length, 0, d + " " + so + ": celular não baixa arquivo (segue o fluxo antigo)"); }
  }
}
console.log("atalho.test.js: arquivo de atalho (.url/.webloc/.desktop) em cada perfil, 6 telas, ok");
// Android: sem arquivo; passo a passo por navegador (com o nome do perfil)
const AND = { "Chrome": ["Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile Safari/537", /Chrome: toque no menu[\s\S]*Instalar app[\s\S]*Yaudimtec Loja/], "Samsung Internet": ["Mozilla/5.0 (Linux; Android 13) SamsungBrowser/23.0 Chrome/115 Mobile", /Samsung Internet[\s\S]*Tela inicial/], "Firefox": ["Mozilla/5.0 (Android 13; Mobile; rv:120.0) Gecko/120.0 Firefox/120.0", /Firefox[\s\S]*Instalar/], "Edge": ["Mozilla/5.0 (Linux; Android 13) Chrome/120 Mobile EdgA/120", /Edge[\s\S]*Adicionar ao telefone/] };
for (const [nome, [ua, re]] of Object.entries(AND)) for (const file of ["index.html", "app/loja/index.html"]) {
  const r = roda(file, { search: "?op=ped", ua }); r.els["pfinst-go"]._c();
  A.strictEqual(r.baixados.length, 0, nome + ": Android não baixa arquivo");
  A.ok(re.test(r.els["pfinst-t"].textContent), nome + ": passo a passo certo -> " + r.els["pfinst-t"].textContent);
}
console.log("atalho.test.js: Android com passo a passo por navegador ok");
