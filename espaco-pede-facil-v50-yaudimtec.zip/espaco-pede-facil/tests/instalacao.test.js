// Conferência de INSTALAÇÃO por perfil (PWA, APK TWA e APK nativo): cada perfil precisa ser um app separado.
const assert = require("assert"), fs = require("fs"), path = require("path"), vm = require("vm"), crypto = require("crypto");
const root = path.join(__dirname, ".."), rd = (...p) => fs.readFileSync(path.join(root, ...p), "utf8"), ex = (...p) => fs.existsSync(path.join(root, ...p));
const PERFIS = JSON.parse(rd("scripts", "perfis.json"));
const dirs = Object.keys(PERFIS);
assert.strictEqual(dirs.length, 5, "5 perfis");
const ok = (m) => console.log("instalacao.test.js: " + m + " ok");

// 1) Páginas fixas: manifest no HTML, cor/título do perfil, ?op= travado, scripts compilam
const idx = rd("index.html"), pngInfo = (f) => { const b = fs.readFileSync(path.join(root, f)); assert.strictEqual(b.toString("latin1", 1, 4), "PNG", f + ": é PNG"); return { w: b.readUInt32BE(16), h: b.readUInt32BE(20), hash: crypto.createHash("sha1").update(b).digest("hex") }; };
const hashes = new Set(), ids = new Set(), scopes = [], pk = new Set();
for (const d of dirs) {
  const p = PERFIS[d], m = JSON.parse(rd(p.manifest)), page = rd("app", d, "index.html");
  const links = page.match(/<link rel="manifest"[^>]*>/g) || [];
  assert.deepStrictEqual(links, ['<link rel="manifest" href="/' + p.manifest + '">'], d + ": um único manifest, o do perfil, escrito no HTML");
  assert.strictEqual((page.match(/<meta name="theme-color"/g) || []).length, 1, d + ": uma só theme-color");
  assert.ok(page.includes('<meta name="theme-color" content="' + p.cor + '">') && m.theme_color === p.cor, d + ": cor igual à do manifest");
  assert.ok(page.includes("<title>" + p.nome + "</title>") && m.name === p.nome && m.short_name === p.nome, d + ": nome");
  assert.ok(page.includes('q.set("op","' + p.op + '")'), d + ": trava ?op=" + p.op + " se faltar");
  assert.ok(m.start_url === "/app/" + d + "/?op=" + p.op && m.scope === "/app/" + d + "/", d + ": start_url/scope");
  assert.ok(ex("app", d, "index.html"), d + ": a página do start_url existe");
  const sc = [...page.matchAll(/<script(?![^>]*\bsrc\b)(?![^>]*json)[^>]*>([\s\S]*?)<\/script>/g)].map((x) => x[1]); sc.forEach((s, i) => { if (!s.trim().startsWith("{")) new vm.Script(s, { filename: d + i }); });
  assert.ok(!ids.has(m.id), d + ": id único"); ids.add(m.id); scopes.push(m.scope);
  // ícones: existem, tamanho certo, 'any' e 'maskable', diferentes de todos os outros perfis
  const purp = new Set(m.icons.map((i) => i.purpose)); assert.ok(purp.has("any") && purp.has("maskable") && !m.icons.some((i) => /\s/.test(i.purpose)), d + ": ícones any e maskable separados");
  for (const i of m.icons) { assert.ok(i.src.startsWith("/icons/" + d + "-"), d + ": ícone próprio"); const n = pngInfo(i.src.slice(1)); assert.strictEqual(n.w + "x" + n.h, i.sizes, d + ": tamanho " + i.sizes); }
  const h = pngInfo("icons/" + d + "-512.png").hash; assert.ok(!hashes.has(h), d + ": ícone diferente dos outros"); hashes.add(h);
  assert.ok(page.includes('href="/icons/' + d + '-192.png"'), d + ": apple-touch-icon próprio");
  // o resto da página é o MESMO app do index.html (nada perdido)
  assert.strictEqual(page.length - idx.length < 1200 && page.length - idx.length > -2500, true, d + ": mesmo app do index.html");
}
assert.ok(!scopes.some((a) => scopes.some((b) => a !== b && b.startsWith(a))), "áreas (scope) não se sobrepõem");
ok("páginas fixas, manifests e ícones de cada perfil");

// 2) As páginas fixas estão em dia com o index.html (rode: node scripts/gerar-perfis.js)
{
  const bak = {}; for (const d of dirs) bak[d] = rd("app", d, "index.html");
  const cp = require("child_process"); cp.execFileSync(process.execPath, [path.join(root, "scripts", "gerar-perfis.js")], { stdio: "ignore" });
  for (const d of dirs) assert.strictEqual(rd("app", d, "index.html"), bak[d], d + ": página desatualizada (rode node scripts/gerar-perfis.js)");
  ok("páginas fixas atualizadas em relação ao index.html");
}

// 3) Comportamento do script do topo (executado de verdade): raiz com ?op= vai para a área; área sem ?op= é travada
{
  const first = idx.match(/<script>\s*\/\* PWA Multi-App[\s\S]*?<\/script>/)[0].replace(/^<script>|<\/script>$/g, "");
  const run = (pathname, search, doc) => { const c = { location: { pathname, search, replace(u) { c.went = u; }, hash: "" }, URLSearchParams, localStorage: { setItem() {}, getItem() { return null; } }, Date, JSON, document: doc || { querySelector: () => null, createElement: () => ({}), head: { appendChild(l) { c.link = l.href; } } }, window: {} }; c.window = c; vm.createContext(c); vm.runInContext(first, c); return c; };
  for (const d of dirs) { const p = PERFIS[d];
    assert.strictEqual(run("/", "?op=" + p.op).went, "/app/" + d + "/?op=" + p.op, d + ": raiz com ?op= vai para a sua área");
    assert.strictEqual(run("/app/" + d + "/", "").link, "/" + p.manifest, d + ": sem página fixa, o manifest certo mesmo sem ?op=");
    assert.strictEqual(run("/app/" + d + "/", "?op=" + p.op, { querySelector: () => ({}), createElement: () => ({}), head: { appendChild() { throw new Error("manifest duplicado"); } } }).link, undefined, d + ": com manifest fixo, não cria outro");
  }
  assert.strictEqual(run("/", "").link, "/manifest.webmanifest", "home: manifest genérico");
  ok("script de abertura (raiz → área, manifest sem duplicar)");
}

// 4) Vercel: /app/<perfil> e /app/<perfil>/ entregam a página do perfil; /sw.js sem cache; nunca cai na rota de loja
{
  const v = JSON.parse(rd("vercel.json")), tw = (r) => r.source;
  for (const d of dirs) for (const pth of ["/app/" + d, "/app/" + d + "/"]) {
    const r = v.rewrites.find((x) => new RegExp("^" + x.source.replace(/:role\(([^)]+)\)/, "($1)").replace(/\//g, "\\/") + "$").test(pth));
    assert.ok(r && r.destination === "/app/:role/index.html", pth + " → página do perfil");
    assert.ok(v.rewrites.indexOf(r) < v.rewrites.findIndex((x) => x.source.startsWith("/:slug")), pth + ": vem antes da rota /:slug");
  }
  const hd = (s) => v.headers.find((h) => h.source === s);
  assert.ok(hd("/sw.js").headers.some((h) => h.key === "Cache-Control" && h.value === "no-cache"), "sw.js sem cache (atualiza sempre)");
  for (const d of dirs) assert.ok(hd("/" + PERFIS[d].manifest).headers.some((h) => h.value === "application/manifest+json"), d + ": manifest com o tipo certo");
  const ign = rd(".vercelignore").split("\n"); assert.ok(!ign.some((l) => /^(app|icons)\/?$/.test(l.trim()) || /manifest|sw\.js/.test(l)), "app/, icons/ e manifests vão no deploy");
  ok("rotas e cabeçalhos da Vercel");
}

(async () => {
// 5) Service worker (executado com cache simulado): offline abre o PRÓPRIO perfil, nunca a home
{
  const sw = rd("sw.js"), L = {}, store = new Map();
  const caches = { open: async () => ({ addAll: async () => {}, put: async (r, res) => { store.set(r.url || r, res); } }), keys: async () => [], delete: async () => {},
    match: async (r, o) => { const u = typeof r === "string" ? new URL(r, "https://x").href : r.url; if (store.has(u)) return store.get(u); if (o && o.ignoreSearch) for (const [k, v] of store) if (k.split("?")[0] === u.split("?")[0]) return v; } };
  const ctx = { self: { addEventListener: (n, f) => { L[n] = f; }, skipWaiting() {}, clients: { claim() {} } }, caches, location: { origin: "https://x" }, URL, fetch: async () => { throw new Error("offline"); }, Promise };
  vm.createContext(ctx); vm.runInContext(sw, ctx);
  assert.ok(/const V = "pf-v([7-9]|\d\d)"/.test(sw), "cache renovado (v7+)");
  for (const d of dirs) { const p = PERFIS[d]; store.clear(); store.set("https://x/app/" + d + "/?op=" + p.op, "SHELL-" + d); store.set("https://x/", "HOME");
    for (const u of ["https://x/app/" + d + "/", "https://x/app/" + d + "/?op=" + p.op]) { let out; L.fetch({ request: { method: "GET", url: u, mode: "navigate" }, respondWith(pr) { out = pr; } }); assert.strictEqual(await out, "SHELL-" + d, d + ": offline em " + u + " abre o próprio perfil"); } }
  ok("offline por perfil (service worker)");
}

// 6) APK TWA e APK nativo: pacote único, mesmo endereço do manifest, mesmo domínio, ícone próprio
{
  const host = new Set(), al = JSON.parse(rd("twa", "assetlinks.modelo.json")).map((x) => x.target.package_name);
  for (const d of dirs) { const p = PERFIS[d], t = JSON.parse(rd("twa", d, "twa-manifest.json")), m = JSON.parse(rd(p.manifest)), c = JSON.parse(rd("nativo", d, "capacitor.config.json"));
    assert.strictEqual(t.packageId, p.pacote, d + ": pacote TWA"); assert.strictEqual(c.appId, p.pacote, d + ": pacote nativo igual ao TWA");
    assert.ok(!pk.has(p.pacote)); pk.add(p.pacote); assert.ok(/^br\.com\.pedefacil\.[a-z]+$/.test(p.pacote));
    assert.strictEqual(t.startUrl, m.start_url, d + ": startUrl"); assert.strictEqual(new URL(t.fullScopeUrl).pathname, m.scope, d + ": escopo");
    assert.strictEqual(new URL(t.webManifestUrl).pathname, "/" + p.manifest, d + ": manifest do APK"); assert.ok(ex(p.manifest));
    assert.strictEqual(new URL(t.iconUrl).pathname, "/icons/" + d + "-512.png", d + ": ícone do APK"); assert.ok(ex("icons", d + "-512.png"));
    assert.strictEqual(new URL(c.server.url).pathname + new URL(c.server.url).search, m.start_url, d + ": app nativo abre no start_url");
    assert.ok(c.server.allowNavigation.includes(t.host), d + ": domínio permitido"); assert.strictEqual(new URL(c.server.url).host, t.host, d + ": mesmo domínio");
    host.add(t.host); assert.ok(al.includes(p.pacote), d + ": no assetlinks");
  }
  assert.strictEqual(host.size, 1, "um só domínio nos 5 APKs");
  assert.ok(new RegExp(idx.match(/\/\^espaco-\?pede-\?facil\[a-z0-9-\]\*[^/]*\//)[0].slice(1, -1)).test([...host][0]), "domínio dos APKs é aceito pelo login/banco do app");
  for (const h of ["espaco-pede-facil.vercel.app", "espacopedefacil-v9.vercel.app", "espaco-pede-facil-vercel.vercel.app"]) assert.ok(new RegExp(idx.match(/\/\^espaco-\?pede-\?facil\[a-z0-9-\]\*[^/]*\//)[0].slice(1, -1)).test(h), h + ": login/banco ligam");
  ok("APKs (TWA e nativo): pacote, domínio, endereço e ícone");
}
console.log("instalacao.test.js: tudo certo");
})().catch((e) => { console.error(e); process.exit(1); });

// equipe que entra por /equipe/<loja> também vê o botão: o perfil vem do login e o botão leva ao /app/<perfil>/ (manifest certo), mantendo a sessão
{
  const hh = require("fs").readFileSync(require("path").join(__dirname, "..", "index.html"), "utf8");
  assert.ok(hh.includes('function staffOp()') && hh.includes(':(staffOp()||ownerOp())}catch(e){return ""}}'), "perfil vem do login da equipe");
  assert.ok(hh.includes('if(eqs()&&staffOp())pub=false;'), "equipe logada não é tratada como página pública");
  assert.ok(hh.includes('if(!urlOp()&&atalhoUrl()&&!standalone()){location.href=atalhoUrl()+"&install=1";return}'), "botão leva ao endereço do perfil");
}

// aba Apps do ADM: um cartão por perfil, com botão de instalar apontando para /app/<perfil>/?op=<op>&install=1 e o ícone do perfil
{
  const fsx = require("fs"), px = require("path");
  const hh = fsx.readFileSync(px.join(__dirname, "..", "index.html"), "utf8");
  const PF = JSON.parse(fsx.readFileSync(px.join(__dirname, "..", "scripts", "perfis.json"), "utf8"));
  assert.ok(hh.includes('["apps","Apps"]') && hh.includes('"contab","apps"];') && hh.includes('if(tab==="apps")return appsTab();'), "aba Apps no menu do ADM");
  const a = hh.indexOf("function appsTab()"), z = hh.indexOf("</p>'}", a) + 6, fn = hh.slice(a, z);
  Object.keys(PF).forEach((d) => {
    assert.ok(fn.includes('["' + d + '","' + PF[d].nome + '","' + PF[d].op + '"'), "Apps: cartão do perfil " + d + " com nome e op certos");
    assert.ok(fsx.existsSync(px.join(__dirname, "..", "icons", d + "-192.png")), "Apps: ícone de " + d);
    assert.ok(fsx.existsSync(px.join(__dirname, "..", "app", d, "index.html")), "Apps: a página /app/" + d + "/ existe");
  });
  assert.ok(fn.includes('"/app/"+p[0]+"/?op="+p[2]+"&install=1"'), "Apps: botão abre o endereço do perfil já com install=1");
}

// botão de instalar (correções após teste real): evento capturado já no <head>, aviso do Chrome usado uma vez, passo a passo quando o Chrome não libera
{
  const hh = require("fs").readFileSync(require("path").join(__dirname, "..", "index.html"), "utf8");
  assert.ok(/<head><script>window\.addEventListener\("beforeinstallprompt"/.test(hh) && hh.includes("var EV=window.__pfEV||null"), "evento do Chrome capturado no <head> e reaproveitado");
  assert.ok(hh.includes("if(!EV&&desk()&&baixaAtalho())"), "no computador o aviso do Chrome vale mais que baixar atalho");
  assert.ok(hh.includes("msgOn=true;sync()}}") && !hh.includes("else EV=e;sync()"), "aviso dispensado: mostra o passo a passo e não reutiliza o evento");
  assert.ok(hh.includes("O Chrome não liberou a instalação automática agora."), "mensagem diz o motivo quando o Chrome não liberou");
}

// aba Apps: botão "Enviar pelo WhatsApp" em cada app (equipe recebe o link de acesso + passo a passo; ADM recebe o endereço do app)
{
  const hh = require("fs").readFileSync(require("path").join(__dirname, "..", "index.html"), "utf8");
  assert.ok(hh.includes('data-pfwa="') && hh.includes("https://wa.me/?text=") && hh.includes("Enviar pelo WhatsApp"), "Apps: botão do WhatsApp");
  assert.ok(hh.includes('{loja:"ped",cozinha:"kds",entregas:"ent",garcom:"mesas"}[p[0]]') && hh.includes("tem?teamUrlRole(role)"), "Apps: equipe recebe o link de acesso da loja");
  assert.ok(hh.includes("Peça acesso (o dono da loja aprova)") && hh.includes("toque em “Baixar e instalar”"), "Apps: mensagem com o passo a passo");
}
