// api/baixa.js: baixa idempotente, exclusão, devolução do reservado, autenticação do dono e reconciliação; e checagem estática do app e das regras.
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const root = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(root, f), "utf8");

const { privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
process.env.PF_SA_JSON = JSON.stringify({ client_email: "pf@delivery-67d14.iam.gserviceaccount.com", private_key: privateKey, project_id: "delivery-67d14", token_uri: "https://oauth2.googleapis.com/token" });

const fsx = require("../api/_fs");
const PEDIDOS = {}, COUNTERS = {}; // id -> campos simples
let abortar = 0, aoAbortar = null, lookups = 0, semTx = false;
const TOKENS = { "tok-dono": "u1", "tok-equipe": "anon9" }; // idToken -> uid
const resp = (ok, status, body) => ({ ok, status, json: async () => body || {} });
const cam = (w) => String((w.update && w.update.name) || w.delete).replace(/^.*\/documents\//, "");

global.fetch = async (url, opts = {}) => {
  if (url === "https://oauth2.googleapis.com/token") return resp(true, 200, { access_token: "tk-servidor", expires_in: 3600 });
  if (/identitytoolkit\.googleapis\.com\/v1\/accounts:lookup\?key=/.test(url)) {
    lookups++;
    const uid = TOKENS[JSON.parse(opts.body).idToken];
    return uid ? resp(true, 200, { users: [{ localId: uid }] }) : resp(false, 400, { error: { message: "INVALID_ID_TOKEN" } });
  }
  assert.strictEqual((opts.headers || {}).Authorization, "Bearer tk-servidor", "o Firestore só é acessado com a credencial do servidor");
  if (/documents:beginTransaction$/.test(url)) return semTx ? resp(false, 500) : resp(true, 200, { transaction: "tx" });
  if (/documents:rollback$/.test(url)) return resp(true, 200);
  if (/documents:commit$/.test(url)) {
    const body = JSON.parse(opts.body);
    if (abortar > 0) { abortar--; if (aoAbortar) { const f = aoAbortar; aoAbortar = null; f(); } return resp(false, 409, { error: { status: "ABORTED" } }); }
    for (const w of body.writes) { // precondições
      const c = cam(w), mp = /^pf_lojas\/u1\/pedidos\/(\d+)$/.exec(c);
      if (w.currentDocument && w.currentDocument.exists === true && mp && !PEDIDOS[mp[1]]) return resp(false, 404, { error: { status: "NOT_FOUND" } });
    }
    for (const w of body.writes) {
      const c = cam(w), mp = /^pf_lojas\/u1\/pedidos\/(\d+)$/.exec(c), mc = /^pf_lojas\/u1\/reservado\/(\d+)$/.exec(c);
      if (mp && w.delete) delete PEDIDOS[mp[1]];
      else if (mp && w.update) Object.keys(w.update.fields).forEach((k) => { PEDIDOS[mp[1]][k] = fsx.fromFs(w.update.fields[k]); });
      else if (mc && w.updateTransforms) COUNTERS[mc[1]] += +w.updateTransforms[0].increment.integerValue;
      else if (mc && w.update) COUNTERS[mc[1]] = +fsx.fromFs(w.update.fields.q);
    }
    return resp(true, 200);
  }
  const m = /documents\/(.+?)(\?|$)/.exec(url), doc = decodeURIComponent(m[1]);
  if (opts.method === "POST" && /:runQuery$/.test(doc)) {
    if (doc !== "pf_lojas/u1:runQuery") return resp(true, 200, [{ readTime: "t" }]); // outra loja: sem pedidos
    const rows = Object.keys(PEDIDOS).map((k) => ({ document: { name: "x", fields: fsx.fields(PEDIDOS[k]), createTime: "2026-11-18T10:00:00.000000Z" } }));
    return resp(true, 200, rows.length ? rows : [{ readTime: "t" }]);
  }
  const mpd = /^pf_lojas\/u1\/pedidos\/(\d+)$/.exec(doc);
  if (mpd) return PEDIDOS[mpd[1]] ? resp(true, 200, { fields: fsx.fields(PEDIDOS[mpd[1]]) }) : resp(false, 404);
  const mcr = /^pf_lojas\/u1\/reservado\/(\d+)$/.exec(doc);
  if (mcr) return COUNTERS[mcr[1]] === undefined ? resp(false, 404) : resp(true, 200, { fields: { q: { integerValue: String(COUNTERS[mcr[1]]) } } });
  if (doc === "pf_lojas/anon9/reservado") return resp(true, 200, {});
  if (doc === "pf_lojas/u1/reservado") return resp(true, 200, { documents: Object.keys(COUNTERS).map((k) => ({ name: "projects/p/databases/(default)/documents/pf_lojas/u1/reservado/" + k, fields: { q: { integerValue: String(COUNTERS[k]) } } })) });
  return resp(false, 404);
};

const handler = require("../api/baixa");
function call(method, body, tok) {
  return new Promise((resolve) => {
    const res = { code: 200, h: {}, setHeader(k, v) { this.h[k] = v; }, status(c) { this.code = c; return this; }, json(b) { resolve({ code: this.code, body: b }); } };
    handler({ method, body, headers: tok ? { authorization: "Bearer " + tok.padEnd(20, "x") } : {} }, res);
  });
}
const T = (n) => (n + "").padEnd(20, "x");
TOKENS[T("tok-dono")] = "u1"; TOKENS[T("tok-equipe")] = "anon9";
const call2 = (body, tok) => call("POST", body, tok);
const reset = () => { Object.keys(PEDIDOS).forEach((k) => delete PEDIDOS[k]); Object.keys(COUNTERS).forEach((k) => delete COUNTERS[k]); abortar = 0; aoAbortar = null; semTx = false; };
const lin = (id, q) => [{ id, q, opt: "" }];

(async () => {
  assert.strictEqual((await call("GET")).code, 405);
  // sem login, token inválido ou de equipe (outro uid): não passa
  reset(); PEDIDOS[1001] = { id: 1001, rv: true, lin: lin(1, 2) }; COUNTERS[1] = 2;
  assert.strictEqual((await call2({ acao: "baixa", ids: [1001] })).code, 401);
  assert.strictEqual((await call2({ acao: "baixa", ids: [1001] }, "invalido")).code, 401);
  let r = await call2({ acao: "baixa", ids: [1001] }, "tok-equipe");
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.resultado[1001], "ausente", "equipe tem outro uid: não enxerga o pedido da loja u1");
  assert.strictEqual(COUNTERS[1], 2); assert.strictEqual(PEDIDOS[1001].baixa, undefined);
  // validação de entrada
  assert.strictEqual((await call2({ acao: "x", ids: [1] }, "tok-dono")).code, 400);
  assert.strictEqual((await call2({ acao: "baixa", ids: [] }, "tok-dono")).code, 400);
  assert.strictEqual((await call2({ acao: "baixa", ids: ["1001"] }, "tok-dono")).code, 400);
  assert.strictEqual((await call2({ acao: "baixa", ids: Array.from({ length: 51 }, (_, i) => i + 1) }, "tok-dono")).code, 400);

  // baixa: marca baixa:true e devolve o reservado; a 2ª chamada não faz nada (idempotente)
  r = await call2({ acao: "baixa", ids: [1001] }, "tok-dono");
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.resultado[1001], "ok");
  assert.strictEqual(PEDIDOS[1001].baixa, true); assert.strictEqual(COUNTERS[1], 0, "reservado devolvido");
  r = await call2({ acao: "baixa", ids: [1001] }, "tok-dono");
  assert.strictEqual(r.body.resultado[1001], "ja"); assert.strictEqual(COUNTERS[1], 0, "baixa duas vezes não desconta duas vezes");
  // vários pedidos e vários produtos numa chamada
  reset(); COUNTERS[1] = 5; COUNTERS[2] = 3;
  PEDIDOS[2001] = { id: 2001, rv: true, lin: [{ id: 1, q: 2, opt: "" }, { id: 2, q: 1, opt: "" }] }; PEDIDOS[2002] = { id: 2002, rv: true, lin: lin(1, 3) };
  r = await call2({ acao: "baixa", ids: [2001, 2002] }, "tok-dono");
  assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 0); assert.strictEqual(COUNTERS[2], 2);
  // pedido sem reserva (rv:false) e produto sem contador: baixa marca o pedido mas não mexe em contador
  reset(); COUNTERS[1] = 4; PEDIDOS[3001] = { id: 3001, rv: false, lin: lin(1, 2) }; PEDIDOS[3002] = { id: 3002, lin: lin(7, 2) };
  r = await call2({ acao: "baixa", ids: [3001, 3002] }, "tok-dono");
  assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 4, "rv:false nunca reservou"); assert.strictEqual(COUNTERS[7], undefined, "não cria contador"); assert.strictEqual(PEDIDOS[3002].baixa, true);
  // auditoria (seção 3): pedido SEM o campo rv (ex.: pedido que nunca passou pela reserva) não pode liberar reserva de outros pedidos
  reset(); COUNTERS[1] = 4; PEDIDOS[3101] = { id: 3101, lin: lin(1, 2) };
  r = await call2({ acao: "baixa", ids: [3101] }, "tok-dono");
  assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 4, "rv ausente não devolve reserva"); assert.strictEqual(PEDIDOS[3101].baixa, true);
  reset(); COUNTERS[1] = 4; PEDIDOS[3102] = { id: 3102, lin: lin(1, 2) };
  r = await call2({ acao: "excluir", ids: [3102] }, "tok-dono");
  assert.strictEqual(COUNTERS[1], 4, "excluir pedido sem rv também não devolve");
  // pedido que não existe
  r = await call2({ acao: "baixa", ids: [9999] }, "tok-dono"); assert.strictEqual(r.code, 200); assert.strictEqual(r.body.resultado[9999], "ausente");

  // excluir pedido SEM baixa: apaga e devolve o reservado; COM baixa: só apaga
  reset(); COUNTERS[1] = 5; PEDIDOS[4001] = { id: 4001, rv: true, lin: lin(1, 2) }; PEDIDOS[4002] = { id: 4002, baixa: true, lin: lin(1, 3) };
  r = await call2({ acao: "excluir", ids: [4001, 4002] }, "tok-dono");
  assert.strictEqual(r.code, 200); assert.strictEqual(PEDIDOS[4001], undefined); assert.strictEqual(PEDIDOS[4002], undefined);
  assert.strictEqual(COUNTERS[1], 3, "só o pedido sem baixa devolveu (2 de 5)");
  r = await call2({ acao: "excluir", ids: [4001] }, "tok-dono"); assert.strictEqual(r.body.resultado[4001], "ja", "excluir de novo é inofensivo"); assert.strictEqual(COUNTERS[1], 3);

  // conflito de transação: tenta de novo e conclui uma vez só
  reset(); COUNTERS[1] = 4; PEDIDOS[5001] = { id: 5001, rv: true, lin: lin(1, 2) }; abortar = 2; aoAbortar = () => { COUNTERS[1] = 6; /* entrou outro pedido */ };
  r = await call2({ acao: "baixa", ids: [5001] }, "tok-dono"); assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 4, "refez a conta em cima do valor novo: 6 - 2");
  // transação fora do ar: 502, nada mudou (o app tenta de novo depois)
  reset(); COUNTERS[1] = 2; PEDIDOS[6001] = { id: 6001, rv: true, lin: lin(1, 2) }; semTx = true;
  r = await call2({ acao: "baixa", ids: [6001] }, "tok-dono"); assert.strictEqual(r.code, 502); assert.strictEqual(PEDIDOS[6001].baixa, undefined); assert.strictEqual(COUNTERS[1], 2); semTx = false;

  // reconciliar: refaz o contador a partir dos pedidos sem baixa (conserta divergência)
  reset(); COUNTERS[1] = 9; COUNTERS[2] = 4;
  PEDIDOS[7001] = { id: 7001, rv: true, lin: lin(1, 2) }; PEDIDOS[7002] = { id: 7002, baixa: true, lin: lin(1, 5) }; PEDIDOS[7003] = { id: 7003, rv: false, lin: lin(1, 5) };
  r = await call2({ acao: "reconciliar" }, "tok-dono");
  assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 2); assert.strictEqual(COUNTERS[2], 0, "sem pedido sem baixa: zera");
  assert.deepStrictEqual(r.body.ajustados, { 1: { de: 9, para: 2 }, 2: { de: 4, para: 0 } });
  assert.strictEqual((await call2({ acao: "reconciliar" }, "tok-equipe")).code, 200, "equipe só reconcilia a PRÓPRIA (vazia) loja");
  assert.strictEqual(COUNTERS[1], 2);

  // reconciliação atômica (auditoria 5.3): reserva que entra no meio derruba o commit → recusa, e o contador NÃO é sobrescrito com soma velha
  reset(); COUNTERS[1] = 9; PEDIDOS[7101] = { id: 7101, rv: true, lin: lin(1, 2) }; abortar = 1; aoAbortar = () => { COUNTERS[1] = 11; /* entrou outro pedido */ };
  r = await call2({ acao: "reconciliar" }, "tok-dono");
  assert.strictEqual(r.code, 502, "conflito na reconciliação: recusa"); assert.strictEqual(COUNTERS[1], 11, "contador não foi sobrescrito");
  // consulta cortada pelo limite (mais de 1000 pedidos na janela): soma incompleta → recusa, nada gravado
  reset(); COUNTERS[1] = 9; for (let i = 0; i < 1001; i++) PEDIDOS[8000 + i] = { id: 8000 + i, rv: true, lin: lin(1, 1) };
  r = await call2({ acao: "reconciliar" }, "tok-dono");
  assert.strictEqual(r.code, 502, "limite estourado: recusa"); assert.strictEqual(COUNTERS[1], 9, "nada gravado com soma incompleta");
  reset();

  // ---- estático: app, regras, deploy ----
  const h = read("index.html");
  assert(h.includes("function pfBaixaApi(acao,ids,cb)") && h.includes('"/api/baixa"') && h.includes("Authorization:\"Bearer \"+t"), "app chama /api/baixa com o idToken");
  assert(h.includes("function pfBaixaPend(ids)") && h.includes("cloudSave(function(r){if(r===\"ok\")pfBaixaPend(pend)})"), "só pede a baixa DEPOIS de publicar o estoque novo");
  assert(!/DB\.merge\("lojas\/"\+ACCT\.uid\+"\/pedidos\/"\+o\.id,\{baixa:true\}\)/.test(h), "o app não marca baixa direto no Firestore: quem marca é o servidor");
  assert(h.includes('pfBaixaApi("excluir"'), "excluir pedido passa pelo servidor (devolve o reservado)");
  const rl = read("firestore.rules");
  const rs = rl.slice(rl.indexOf("match /reservado/{pid}"));
  assert(/allow read: if isOwner\(uid\);\s*allow write: if false;/.test(rs.slice(0, 200)), "contador: só o dono lê, ninguém grava pelo cliente");
  const vj = JSON.parse(read("vercel.json"));
  assert(vj.functions["api/baixa.js"] && vj.functions["api/pedido.js"]);
  console.log("baixa.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
