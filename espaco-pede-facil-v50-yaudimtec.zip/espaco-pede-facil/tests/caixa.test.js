// api/caixa.js (auditoria M-05): operações do caixa em transação no servidor; ninguém apaga o trabalho do outro.
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
const SA = { client_email: "pf@delivery-67d14.iam.gserviceaccount.com", private_key: privateKey, project_id: "delivery-67d14", token_uri: "https://oauth2.googleapis.com/token" };
process.env.PF_SA_JSON = JSON.stringify(SA);
const fsx = require("../api/_fs");
fsx._reset();
const handler = require("../api/caixa");

const OWNER = "owner1", LOJA1 = "loja0001", KDS = "cozinha1", PEND = "loja0002", NADA = "estranho1";
const DB = {}, VER = {}, TXR = {};
let ORDERS = [], txN = 0, abortos = 0;
const put = (p, o) => { DB[p] = fsx.fields(o); VER[p] = (VER[p] || 0) + 1; };
const get = (p) => { if (!DB[p]) return null; const d = {}; Object.keys(DB[p]).forEach((k) => { d[k] = fsx.fromFs(DB[p][k]); }); return d; };
const estado = () => JSON.parse(get("pf_lojas/" + OWNER + "/caixa/estado").data);
const resp = (ok, status, body) => ({ ok, status, json: async () => body || {} });
global.fetch = async (url, opts = {}) => {
  if (url === SA.token_uri) return resp(true, 200, { access_token: "tk", expires_in: 3600 });
  if (/identitytoolkit\.googleapis\.com/.test(url)) {
    const m = /^tokenTESTE000000-(\w+)$/.exec(JSON.parse(opts.body).idToken);
    return m ? resp(true, 200, { users: [{ localId: m[1] }] }) : resp(false, 400);
  }
  if (/documents:beginTransaction$/.test(url)) { const id = "tx" + (++txN); TXR[id] = {}; return resp(true, 200, { transaction: id }); }
  if (/documents:rollback$/.test(url)) return resp(true, 200);
  if (/documents:commit$/.test(url)) {
    const body = JSON.parse(opts.body), cam = (w) => String(w.update.name).replace(/^.*\/documents\//, "");
    const reads = TXR[body.transaction] || {};
    for (const p of Object.keys(reads)) if ((VER[p] || 0) !== reads[p]) { abortos++; return resp(false, 409, { error: { status: "ABORTED" } }); } // alguém passou na frente
    for (const w of body.writes) if (w.currentDocument && w.currentDocument.exists === false && DB[cam(w)]) return resp(false, 409, { error: { status: "ALREADY_EXISTS" } });
    for (const w of body.writes) { DB[cam(w)] = w.update.fields; VER[cam(w)] = (VER[cam(w)] || 0) + 1; }
    return resp(true, 200);
  }
  const m = /documents\/(.+?)(\?|$)/.exec(url), doc = decodeURIComponent(m[1]);
  if (opts.method === "POST" && /:runQuery$/.test(doc)) {
    const min = Number(JSON.parse(opts.body).structuredQuery.where.fieldFilter.value.integerValue);
    return resp(true, 200, ORDERS.filter((o) => o.id >= min).sort((a, b) => b.id - a.id).map((o) => ({ document: { name: "x", fields: fsx.fields(o), createTime: "2026-01-01T00:00:00Z" } })));
  }
  const tx = /[?&]transaction=([^&]+)/.exec(url);
  if (tx && TXR[decodeURIComponent(tx[1])]) TXR[decodeURIComponent(tx[1])][doc] = VER[doc] || 0;
  return DB[doc] ? resp(true, 200, { fields: DB[doc] }) : resp(false, 404);
};
const tok = (u) => "Bearer tokenTESTE000000-" + u;
const call = (body, uid) => new Promise((resolve) => {
  const res = { code: 200, setHeader() {}, status(c) { this.code = c; return this; }, json(b) { resolve({ code: this.code, body: b }); } };
  handler({ method: "POST", body, headers: uid ? { authorization: tok(uid) } : {} }, res);
});
const op = (acao, uid, extra) => call(Object.assign({ acao, oid: OWNER }, extra), uid);
function semear() {
  [DB, VER, TXR].forEach((o) => Object.keys(o).forEach((k) => delete o[k])); ORDERS = [];
  const eq = (u, papel, status) => put("pf_lojas/" + OWNER + "/equipe/" + u, { uid: u, nome: "Func " + u, papel, status: status || "aprovado" });
  eq(LOJA1, "ped"); eq(KDS, "kds"); eq(PEND, "ped", "pendente");
}

(async () => {
  semear();
  // ---- autenticação e papel ----
  assert.strictEqual((await op("abrir", null, { abertura: 100 })).code, 401);
  for (const u of [KDS, PEND, NADA]) assert.strictEqual((await op("abrir", u, { abertura: 100 })).code, 403, u + " não opera o caixa");
  assert.strictEqual((await op("abrir", OWNER, { abertura: -1 })).code, 400);
  assert.strictEqual((await op("xx", OWNER, {})).code, 400);
  assert.strictEqual((await call({ acao: "abrir", oid: "../x", abertura: 1 }, OWNER)).code, 400);
  assert.ok(!DB["pf_lojas/" + OWNER + "/caixa/estado"], "nada gravado pelas tentativas inválidas");

  // ---- abrir: id, horário e autor são do servidor ----
  const t0 = Date.now();
  let r = await op("abrir", LOJA1, { abertura: 100, id: 1, aberturaEm: 1, por: { uid: "falso", nome: "Falso" } });
  assert.strictEqual(r.code, 200, JSON.stringify(r.body));
  let c = estado(); const a = c.atual;
  assert.ok(a.id >= t0 && a.aberturaEm === a.id, "id e horário de abertura do servidor");
  assert.strictEqual(a.por.uid, LOJA1); assert.strictEqual(a.por.nome, "Func " + LOJA1, "autor vem do token e da equipe, não do corpo");
  assert.strictEqual(a.abertura, 100);
  r = await op("abrir", OWNER, { abertura: 5 }); assert.strictEqual(r.code, 409); assert.strictEqual(r.body.erro, "caixa_ja_aberto"); assert.strictEqual(r.body.caixa.atual.id, a.id, "devolve o estado real");
  assert.strictEqual(estado().atual.abertura, 100, "segunda abertura não sobrescreve");

  // ---- M-05: duas pessoas movimentando AO MESMO TEMPO: nada se perde ----
  const [m1, m2] = await Promise.all([
    op("mov", LOJA1, { atualId: a.id, t: "sangria", v: 10, obs: "troco para o motoboy" }),
    op("mov", OWNER, { atualId: a.id, t: "suprimento", v: 50, obs: "reforço de troco" }),
  ]);
  assert.strictEqual(m1.code, 200, JSON.stringify(m1.body)); assert.strictEqual(m2.code, 200, JSON.stringify(m2.body));
  assert.ok(abortos > 0, "o teste provoca conflito de verdade (a 2ª transação foi barrada e refeita)");
  c = estado(); assert.strictEqual(c.atual.movs.length, 2, "as duas movimentações estão no caixa (antes uma apagava a outra)");
  assert.deepStrictEqual(c.atual.movs.map((x) => x.t).sort(), ["sangria", "suprimento"]);
  assert.ok(c.atual.movs.every((x) => x.em >= a.id && x.por.uid), "horário e autor gravados pelo servidor");
  // muitas ao mesmo tempo
  await Promise.all([1, 2, 3, 4, 5].map((i) => op("mov", i % 2 ? LOJA1 : OWNER, { atualId: a.id, t: "suprimento", v: 1, obs: "teste " + i })));
  assert.strictEqual(estado().atual.movs.length, 7, "5 simultâneas + 2 anteriores");
  const upd = get("pf_lojas/" + OWNER + "/caixa/estado").updated; assert.ok(upd > a.id);

  // ---- entradas inválidas ----
  const mov = (o) => op("mov", LOJA1, Object.assign({ atualId: a.id, t: "sangria", v: 5, obs: "motivo válido" }, o));
  for (const o of [{ v: 0 }, { v: -5 }, { v: 2e6 }, { v: "x" }, { t: "retirada" }, { obs: "ab" }, { atualId: "x" }]) assert.strictEqual((await mov(o)).code, 400, JSON.stringify(o));
  r = await mov({ atualId: a.id + 1 }); assert.strictEqual(r.code, 409); assert.strictEqual(r.body.erro, "caixa_mudou", "movimento para um caixa que não é o aberto");
  assert.strictEqual(estado().atual.movs.length, 7);

  // ---- fechar: o servidor recalcula as vendas em dinheiro ----
  const agora = Date.now();
  const ped = (id, o) => ORDERS.push(Object.assign({ id, st: "ok", pag: "local", fm: "dinheiro", total: 30, sinal: 0 }, o));
  ped(agora - 1, {});                                                    // dinheiro 30 → conta
  ped(agora - 2, { st: "pend", pag: "pix", sinal: 10 });                  // Pix pendente → não conta
  ped(agora - 3, { pag: "pix", sinal: 30, fm: "" });                      // pago no Pix → não é dinheiro
  ped(agora - 4, { origem: "mesa", fechada: false });                     // conta aberta → não conta
  ped(a.id - 1000, {});                                                   // antes da abertura → não conta
  ped(agora - 5, { origem: "mesa", fechada: true, pg: [{ v: 20, fm: "dinheiro", em: agora }, { v: 15, fm: "cartao", em: agora }] }); // dinheiro 20 → conta
  const fecharExtra = { vendasDin: 999999, sistema: 1, quebra: 0, id: 1 };
  r = await op("fechar", LOJA1, Object.assign({ atualId: a.id, contado: 180 }, fecharExtra));
  assert.strictEqual(r.code, 200, JSON.stringify(r.body));
  const e = r.body.entrada;
  assert.strictEqual(e.vendasDin, 50, "30 + 20 em dinheiro; o valor mandado pelo aparelho é ignorado");
  // abertura 100 + vendas 50 + suprimentos (50 + 5×1... = 55) - sangria 10
  assert.strictEqual(e.sistema, 100 + 50 + 55 - 10); assert.strictEqual(e.contado, 180); assert.strictEqual(e.quebra, 180 - 195);
  assert.strictEqual(e.fechadoPor.uid, LOJA1); assert.strictEqual(e.movs.length, 7);
  c = estado(); assert.strictEqual(c.atual, null); assert.strictEqual(c.hist.length, 1); assert.strictEqual(c.hist[0].id, a.id);
  const arq = get("pf_lojas/" + OWNER + "/caixa/h-" + a.id); assert.ok(arq && arq.sistema === e.sistema, "fechamento arquivado em documento próprio");
  r = await op("fechar", OWNER, { atualId: a.id, contado: 1 }); assert.strictEqual(r.code, 409); assert.strictEqual(r.body.erro, "caixa_fechado", "fechar duas vezes não duplica");
  assert.strictEqual(estado().hist.length, 1);
  r = await op("mov", OWNER, { atualId: a.id, t: "sangria", v: 5, obs: "depois de fechar" }); assert.strictEqual(r.code, 409, "movimento em caixa fechado");

  // ---- histórico só cresce: o estado guarda os 30 últimos, o arquivo guarda todos ----
  for (let i = 0; i < 32; i++) {
    const o = await op("abrir", OWNER, { abertura: i }); assert.strictEqual(o.code, 200);
    const f = await op("fechar", OWNER, { atualId: o.body.caixa.atual.id, contado: i }); assert.strictEqual(f.code, 200, JSON.stringify(f.body));
  }
  assert.strictEqual(estado().hist.length, 30, "estado com os 30 mais recentes");
  assert.strictEqual(Object.keys(DB).filter((k) => k.indexOf("/caixa/h-") > -1).length, 33, "33 fechamentos arquivados, nenhum apagado");

  // ---- regras e app ----
  const rules = fs.readFileSync(path.join(__dirname, "..", "firestore.rules"), "utf8");
  const cx = rules.slice(rules.indexOf("match /caixa/{cid}"), rules.indexOf("match /comissoes/{cid}"));
  assert.ok(/allow update, delete: if false;/.test(cx) && /allow create: if isOwner\(uid\) && cid == 'estado';/.test(cx), "regras: caixa só é gravado pelo servidor");
  assert.ok(JSON.parse(fs.readFileSync(path.join(__dirname, "..", "vercel.json"), "utf8")).functions["api/caixa.js"], "vercel: função api/caixa.js");
  console.log("caixa.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
