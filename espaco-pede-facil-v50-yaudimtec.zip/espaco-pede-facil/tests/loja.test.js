// Testa api/loja.js com o Firestore (API REST) simulado, sem rede.
const assert = require("assert");
const png = "data:image/png;base64," + Buffer.alloc(500, 7).toString("base64");
const DOCS = {
  "pf_slugs/farmacia-teste": { uid: { stringValue: "u1" } },
  "pf_lojas_publicas/u1": { data: { stringValue: JSON.stringify({ nome: "Farmácia Teste", cover: png }) }, nome: { stringValue: "Farmácia Teste" } },
  "pf_slugs/semdados": { uid: { stringValue: "u2" } },
  "pf_slugs/quebrada": { uid: { stringValue: "u3" } },
  "pf_lojas_publicas/u3": { data: { stringValue: "{nao-e-json" } },
};
const calls = [];
global.fetch = async (url, opts) => {
  const m = /documents\/(.+?)\?key=(.+)$/.exec(url);
  calls.push({ doc: decodeURIComponent(m[1]), key: m[2], ref: opts.headers.Referer });
  const d = DOCS[decodeURIComponent(m[1])];
  return { ok: !!d, json: async () => ({ fields: d }) };
};
const handler = require("../api/loja");
function call(query, host = "espacopedefacil.vercel.app") {
  return new Promise((resolve) => {
    const res = { statusCode: 200, h: {}, setHeader(k, v) { this.h[k] = v; }, status(c) { this.statusCode = c; return this; }, send(b) { resolve({ code: this.statusCode, h: this.h, body: b }); return this; }, end() { resolve({ code: this.statusCode, h: this.h, body: "" }); } };
    handler({ query, headers: { host, "x-forwarded-host": host } }, res);
  });
}
(async () => {
  let r = await call({});
  assert.strictEqual(r.code, 200); assert(r.body.includes("<!--OG-->"));
  r = await call({ slug: "farmacia-teste" });
  assert.strictEqual(r.code, 200);
  assert(r.body.includes("<title>Farmácia Teste | Yaudimtec</title>"));
  assert(r.body.includes('content="https://espacopedefacil.vercel.app/_og/farmacia-teste"'));
  assert(r.body.includes('property="og:url" content="https://espacopedefacil.vercel.app/farmacia-teste"'));
  assert(calls.every((c) => c.ref === "https://espacopedefacil.vercel.app/"), "Referer enviado");
  assert(calls.some((c) => c.doc === "pf_slugs/farmacia-teste") && calls.some((c) => c.doc === "pf_lojas_publicas/u1"));
  r = await call({ og: "farmacia-teste" });
  assert.strictEqual(r.code, 200); assert.strictEqual(r.h["Content-Type"], "image/png"); assert.strictEqual(r.body.length, 500);
  r = await call({ og: "semdados" }); assert.strictEqual(r.code, 302); assert.strictEqual(r.h.Location, "/og-default.png");
  r = await call({ slug: "naoexiste" }); assert.strictEqual(r.code, 404); assert(r.body.includes("<!--OG-->"));
  r = await call({ slug: "semdados" }); assert.strictEqual(r.code, 404);
  r = await call({ slug: "quebrada" }); assert.strictEqual(r.code, 404);
  r = await call({ slug: "admin" }); assert.strictEqual(r.code, 200); // reservado: entrega o app normal
  r = await call({ slug: ["farmacia-teste", "x"] }); assert.strictEqual(r.code, 200);
  global.fetch = async () => { throw new Error("sem rede"); };
  r = await call({ slug: "farmacia-teste" }); assert.strictEqual(r.code, 200); assert(r.body.includes("<!--OG-->")); // falha de rede não derruba o link
  console.log("api/loja.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
