// api/mesa.js: pedido de mesa/balcão e comissão do garçom são calculados no SERVIDOR (auditoria A-03 e A-04).
// Testes NEGATIVOS: o aparelho tenta forjar total, dono do pedido, comissão, papel, estoque e reenvio.
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const root = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(root, f), "utf8");

const { privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
const SA = { client_email: "pf@delivery-67d14.iam.gserviceaccount.com", private_key: privateKey, project_id: "delivery-67d14", token_uri: "https://oauth2.googleapis.com/token" };
process.env.PF_SA_JSON = JSON.stringify(SA);
const fsx = require("../api/_fs");
fsx._reset();
const handler = require("../api/mesa");

const OWNER = "owner1", G1 = "garcom1", G2 = "garcom2", KDS = "cozinha1", PEND = "garcom3", LOJA_U = "gerente1", NADA = "estranho1";
let LOJA;
const nova = () => ({
  nome: "Loja Teste", modo: "cardapio", mods: { kds: true, entrega: true }, comGarcom: 10,
  services: [{ id: 1, name: "Pastel", price: 10 }, { id: 2, name: "Suco", price: 7.5 }],
});
const DB = {};
const put = (p, o) => { DB[p] = fsx.fields(o); };
const get = (p) => { if (!DB[p]) return null; const d = {}; Object.keys(DB[p]).forEach((k) => { d[k] = fsx.fromFs(DB[p][k]); }); return d; };
const cols = (prefix) => Object.keys(DB).filter((k) => k.startsWith(prefix));
function semear() {
  Object.keys(DB).forEach((k) => delete DB[k]);
  put("pf_lojas/" + OWNER + "/equipe/" + G1, { status: "aprovado", papel: "mesas", nome: "Ana" });
  put("pf_lojas/" + OWNER + "/equipe/" + G2, { status: "aprovado", papel: "mesas", nome: "Bia" });
  put("pf_lojas/" + OWNER + "/equipe/" + KDS, { status: "aprovado", papel: "kds", nome: "Cozinha" });
  put("pf_lojas/" + OWNER + "/equipe/" + PEND, { status: "pendente", papel: "mesas", nome: "Carla" });
  put("pf_lojas/" + OWNER + "/equipe/" + LOJA_U, { status: "aprovado", papel: "ped", nome: "Gerente" });
}
const resp = (ok, status, body) => ({ ok, status, json: async () => body || {} });
global.fetch = async (url, opts = {}) => {
  if (url === SA.token_uri) return resp(true, 200, { access_token: "tk-servidor", expires_in: 3600 });
  if (/identitytoolkit\.googleapis\.com/.test(url)) {
    const t = JSON.parse(opts.body).idToken, m = /^tokenTESTE000000-(\w+)$/.exec(t);
    return m ? resp(true, 200, { users: [{ localId: m[1] }] }) : resp(false, 400);
  }
  if (/documents:beginTransaction$/.test(url)) return resp(true, 200, { transaction: "tx" });
  if (/documents:rollback$/.test(url)) return resp(true, 200);
  if (/documents:commit$/.test(url)) {
    const body = JSON.parse(opts.body), cam = (w) => String(w.update.name).replace(/^.*\/documents\//, "");
    for (const w of body.writes) if (w.currentDocument && w.currentDocument.exists === false && DB[cam(w)]) return resp(false, 409, { error: { status: "ALREADY_EXISTS" } });
    for (const w of body.writes) {
      const c = cam(w);
      if (w.updateTransforms) { const d = get(c); put(c, { q: d.q + +w.updateTransforms[0].increment.integerValue }); } else DB[c] = w.update.fields;
    }
    return resp(true, 200);
  }
  const m = /documents\/(.+?)(\?|$)/.exec(url), doc = decodeURIComponent(m[1]);
  if (opts.method === "POST" && /:runQuery$/.test(doc)) return resp(true, 200, [{ readTime: "t" }]);
  if (opts.method === "POST") {
    const id = /documentId=([^&]+)/.exec(url)[1], c = doc + "/" + id;
    if (DB[c]) return resp(false, 409);
    DB[c] = JSON.parse(opts.body).fields; return resp(true, 200);
  }
  if (doc === "pf_lojas_publicas/" + OWNER) return resp(true, 200, { fields: { data: { stringValue: JSON.stringify(LOJA) } } });
  return DB[doc] ? resp(true, 200, { fields: DB[doc] }) : resp(false, 404);
};

const tok = (uid) => "Bearer tokenTESTE000000-" + uid;
function call(body, uid, auth) {
  return new Promise((resolve) => {
    const res = { code: 200, setHeader() {}, status(c) { this.code = c; return this; }, json(b) { resolve({ code: this.code, body: b }); } };
    handler({ method: "POST", body, headers: uid === undefined && auth === undefined ? {} : { authorization: auth || tok(uid) } }, res);
  });
}
const T = (n) => String(n).padStart(32, "a");
const mesa = (o = {}) => Object.assign({ id: Date.now(), tt: T(1), mesa: "Mesa 4", obs: "", pess: [{ nome: "João", lin: [{ id: 1, q: 2 }] }, { nome: "Maria", lin: [{ id: 2, q: 1 }] }] }, o);
const reqPedido = (pedido, uid = G1, extra = {}) => call(Object.assign({ acao: "pedido", oid: OWNER, pedido }, extra), uid);

(async () => {
  LOJA = nova(); semear();
  // ---- autenticação e papel ----
  assert.strictEqual((await call({ acao: "pedido", oid: OWNER, pedido: mesa() })).code, 401, "sem token");
  assert.strictEqual((await call({ acao: "pedido", oid: OWNER, pedido: mesa() }, null, "Bearer tokenINVALIDO000000000000")).code, 401, "token inválido");
  for (const u of [KDS, PEND, NADA, LOJA_U]) {
    const r = await reqPedido(mesa(), u); assert.strictEqual(r.code, 403, u + " não lança pedido de mesa");
  }
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/pedidos").length, 0, "nada gravado por quem não pode");
  assert.strictEqual((await call({ acao: "x", oid: OWNER }, G1)).code, 400);
  assert.strictEqual((await call({ acao: "pedido", oid: "../x", pedido: mesa() }, G1)).code, 400, "oid inválido");

  // ---- A-03: o aparelho tenta forjar total, dono, estado, pagamento ----
  let r = await reqPedido(Object.assign(mesa(), { total: 0.01, st: "pend", pag: "pix", sinal: 99, garcom_uid: "outro", fase: "entregue", origem: "balcao", rv: false, baixa: true, items: "1x Lagosta", pess: [{ nome: "João", total: 0, lin: [{ id: 1, q: 2, price: 0.01 }] }, { nome: "Maria", lin: [{ id: 2, q: 1 }] }] }));
  assert.strictEqual(r.code, 200, JSON.stringify(r.body));
  let d = get("pf_lojas/" + OWNER + "/pedidos/" + r.body.id);
  assert.strictEqual(d.total, 27.5, "total é do servidor: 2×10 + 1×7,50");
  assert.strictEqual(d.garcom_uid, G1, "o dono do pedido é quem tem o token, não o que veio no corpo");
  assert.strictEqual(d.garcom_nome, "Ana", "nome vem da equipe");
  assert.strictEqual(d.st, "ok"); assert.strictEqual(d.pag, "local"); assert.strictEqual(d.sinal, 0);
  assert.strictEqual(d.fase, "novo", "com Cozinha: nasce novo (fase do cliente ignorada)");
  assert.strictEqual(d.origem, "mesa"); assert.notStrictEqual(d.rv, false); assert.ok(!d.baixa);
  assert.strictEqual(d.items, "(João) 2x Pastel; (Maria) 1x Suco");
  assert.deepStrictEqual(d.pess.map((p) => p.total), [20, 7.5], "total por pessoa também recalculado");
  assert.strictEqual(r.body.pedido.total, 27.5);

  // ---- entradas inválidas ----
  const r400 = async (p) => assert.strictEqual((await reqPedido(p)).code, 400, JSON.stringify(p).slice(0, 80));
  await r400(mesa({ tt: "curto" })); await r400(mesa({ mesa: "  " })); await r400(mesa({ pess: [] }));
  await r400(mesa({ pess: [{ nome: "A", lin: [{ id: 1, q: 0 }] }] })); await r400(mesa({ pess: [{ nome: "A", lin: [{ id: 1, q: 100 }] }] }));
  await r400(mesa({ pess: [{ nome: "A", lin: [{ id: 1, q: 1.5 }] }] })); await r400(mesa({ pess: [{ nome: "A", lin: [] }] }));
  r = await reqPedido(mesa({ tt: T(2), pess: [{ nome: "A", lin: [{ id: 999, q: 1 }] }] })); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "produto_invalido");

  // ---- sem Cozinha: nasce pronto; balcão ----
  LOJA = nova(); LOJA.mods = { kds: false, entrega: true };
  r = await reqPedido(mesa({ tt: T(3), mesa: "Balcão" })); d = get("pf_lojas/" + OWNER + "/pedidos/" + r.body.id);
  assert.strictEqual(d.fase, "pronto"); assert.ok(d.prontoEm > 0); assert.strictEqual(d.origem, "balcao");
  LOJA = nova();

  // ---- M-03: id do cliente fora da janela é trocado pelo relógio do servidor ----
  const antes = Date.now();
  r = await reqPedido(mesa({ tt: T(4), id: 9e15 }));
  assert.strictEqual(r.code, 200); assert.ok(r.body.id >= antes && r.body.id <= Date.now() + 5, "id futuro forjado não vale");

  // ---- reenvio do mesmo pedido (mesmo id + tt) não duplica ----
  const n0 = cols("pf_lojas/" + OWNER + "/pedidos/").length, idc = Date.now();
  const a = await reqPedido(mesa({ tt: T(5), id: idc })), b = await reqPedido(mesa({ tt: T(5), id: idc }));
  assert.strictEqual(a.code, 200); assert.strictEqual(b.code, 200); assert.strictEqual(a.body.id, b.body.id);
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/pedidos/").length, n0 + 1, "reenvio não cria segundo pedido");

  // ---- estoque: confere e reserva na mesma transação, também para o garçom ----
  LOJA = nova(); LOJA.services[0].estoque_atual = 3;
  r = await reqPedido(mesa({ tt: T(6), pess: [{ nome: "A", lin: [{ id: 1, q: 5 }] }] }));
  assert.strictEqual(r.code, 409); assert.strictEqual(r.body.erro, "estoque_insuficiente"); assert.strictEqual(r.body.disponivel, 3);
  assert.ok(!DB["pf_lojas/" + OWNER + "/reservado/1"], "recusado não reserva");
  r = await reqPedido(mesa({ tt: T(7), pess: [{ nome: "A", lin: [{ id: 1, q: 3 }] }] })); assert.strictEqual(r.code, 200);
  assert.strictEqual(get("pf_lojas/" + OWNER + "/reservado/1").q, 3, "reservou 3");
  r = await reqPedido(mesa({ tt: T(8), pess: [{ nome: "A", lin: [{ id: 1, q: 1 }] }] })); assert.strictEqual(r.code, 409, "o reservado conta: nada sobra");
  LOJA = nova();

  // ---- A-04: comissão calculada no servidor ----
  const ped = (id, o) => put("pf_lojas/" + OWNER + "/pedidos/" + id, Object.assign({ id, origem: "mesa", mesa: "Mesa 4", total: 50, garcom_uid: G1, garcom_nome: "Ana", fechada: true }, o));
  ped(1001, { total: 60 }); ped(1002, { total: 40 }); ped(1003, { fechada: false }); ped(1004, { garcom_uid: G2, garcom_nome: "Bia", total: 80 });
  put("pf_lojas/" + OWNER + "/pedidos/1005", { id: 1005, total: 30, fechada: true }); // pedido do cliente (sem origem de mesa)
  const com = (ids, uid, extra = {}) => call(Object.assign({ acao: "comissao", oid: OWNER, ids }, extra), uid);

  assert.strictEqual((await com([1001], KDS)).code, 403, "cozinha não gera comissão");
  assert.strictEqual((await com([1001], PEND)).code, 403);
  assert.strictEqual((await com([1004], G1)).code, 403, "garçom não pede comissão de pedido de outro garçom");
  r = await com([1003], G1); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "conta_aberta", "só conta fechada");
  r = await com([1005], G1); assert.strictEqual(r.code, 422, "pedido do cliente não gera comissão");
  assert.strictEqual((await com([4040], G1)).code, 404);
  assert.strictEqual((await com([], G1)).code, 400);
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/comissoes/").length, 0, "nenhuma comissão criada pelas tentativas inválidas");

  // o aparelho manda base/pct/valor inflados: ignorados
  r = await com([1001, 1002], G1, { base: 100000, pct: 100, valor: 100000, garcom_uid: G2 });
  assert.strictEqual(r.code, 200, JSON.stringify(r.body)); assert.strictEqual(r.body.minha, 10, "10% de R$ 100,00, não de R$ 100.000");
  const cs = cols("pf_lojas/" + OWNER + "/comissoes/"); assert.strictEqual(cs.length, 1);
  const c1 = get(cs[0]);
  assert.strictEqual(c1.base, 100); assert.strictEqual(c1.pct, 10); assert.strictEqual(c1.valor, 10); assert.strictEqual(c1.garcom_uid, G1);
  assert.deepStrictEqual(c1.pedidos, [1001, 1002]);
  // duplicar: o mesmo pedido nunca gera outra comissão
  r = await com([1001], G1); assert.strictEqual(r.code, 200); assert.strictEqual(r.body.criadas, 0);
  r = await com([1001, 1002], G1); assert.strictEqual(r.body.criadas, 0);
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/comissoes/").length, 1, "continua uma só comissão");
  // Loja da equipe encerra a conta de outro garçom: comissão vai para o garçom do pedido, com o % da loja
  LOJA = nova(); LOJA.comGarcom = 5;
  r = await com([1004], LOJA_U); assert.strictEqual(r.code, 200, JSON.stringify(r.body));
  const novas = cols("pf_lojas/" + OWNER + "/comissoes/").map(get).filter((x) => x.garcom_uid === G2);
  assert.strictEqual(novas.length, 1); assert.strictEqual(novas[0].valor, 4, "5% de R$ 80,00"); assert.strictEqual(novas[0].pct, 5); assert.strictEqual(novas[0].fechadaPor, "Gerente");
  assert.strictEqual(r.body.minha, 0, "a Loja não recebe comissão de garçom");
  // % zero: nada a pagar
  LOJA = nova(); LOJA.comGarcom = 0; ped(1006, { total: 90 });
  r = await com([1006], G1); assert.strictEqual(r.code, 200); assert.strictEqual(r.body.criadas, 0);
  LOJA = nova();

  // ---- regras e app: o garçom não grava mais direto ----
  const rules = read("firestore.rules");
  const ped_ = rules.slice(rules.indexOf("match /pedidos/{pid}"), rules.indexOf("allow read: if isOwner(uid)\n          || isLoja(uid)"));
  assert.ok(/allow create: if isOwner\(uid\);/.test(ped_) && !/isGarcom\(uid\)/.test(ped_), "regras: só o dono cria pedido direto; garçom não");
  const cm_ = rules.slice(rules.indexOf("match /comissoes/{cid}"), rules.indexOf("match /equipe/{mid}"));
  assert.ok(/allow create: if isOwner\(uid\);/.test(cm_) && !/math\.abs|isGarcom\(uid\)\s*\n\s*&&\s*request/.test(cm_), "regras: só o dono cria comissão");
  assert.ok(!/comissoes_pedidos/.test(rules.replace(/^\s*\/\/.*$/gm, "")), "a coleção de marcas fica sem regra: só o servidor acessa");
  const h = read("index.html");
  const sm = h.slice(h.indexOf("function sendMesa("), h.indexOf("/* ----- Fechamento de conta"));
  assert.ok(sm.includes('pfMesaApi("pedido"') && !/DB\.set\("lojas\/"\+ACCT\.uid\+"\/pedidos\//.test(sm), "app: pedido de mesa vai pelo servidor");
  assert.ok(!/total:/.test(sm.slice(sm.indexOf('pfMesaApi("pedido"'), sm.indexOf("function(ok,j,st)"))), "app: não envia total nem preço ao servidor");
  assert.ok(JSON.parse(read("vercel.json")).functions["api/mesa.js"], "vercel: função api/mesa.js");
  console.log("mesa.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
