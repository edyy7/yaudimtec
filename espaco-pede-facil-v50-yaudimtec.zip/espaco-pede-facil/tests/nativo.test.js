// App Android nativo: a camada de alertas (nativo/android-extra) e a ligação do site com ela.
// A compilação roda no GitHub (Android SDK); aqui confere o que dá sem ele: aplicação no projeto, manifest, nomes dos métodos e o fluxo.
const assert = require("assert"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
const root = path.join(__dirname, ".."), rd = (...p) => fs.readFileSync(path.join(root, ...p), "utf8");
const plugin = rd("nativo", "android-extra", "java", "PfAlertPlugin.java"), svc = rd("nativo", "android-extra", "java", "PfAlertService.java");
const html = rd("index.html"), tpl = rd("nativo", "android-extra", "MainActivity.java.tpl");

// 1) tudo que o site chama no plugin existe no Java (@PluginMethod)
const metodos = [...plugin.matchAll(/@PluginMethod\s+public\s+void\s+(\w+)\(/g)].map((m) => m[1]);
const chamados = [...new Set([...html.matchAll(/PFA\.call\("(\w+)"/g)].map((m) => m[1]))];
assert.ok(chamados.length >= 8, "o site usa o plugin");
chamados.forEach((c) => assert.ok(metodos.includes(c), "site chama PfAlert." + c + " e o Java tem esse método"));
assert.ok(/@CapacitorPlugin\(name = "PfAlert"\)/.test(plugin), "nome do plugin = PfAlert (o que o site procura)");
assert.ok(html.includes('isPluginAvailable("PfAlert")'), "site só liga a camada se o plugin existir");

// 2) o serviço faz o que prometemos: alarme em stream de alarme, loop, vibração, tela acesa, tela cheia, sobrepor apps, parar sozinho
["USAGE_ALARM", "setLooping(true)", "VibrationEffect.createWaveform", "SCREEN_BRIGHT_WAKE_LOCK", "ACQUIRE_CAUSES_WAKEUP", "setFullScreenIntent", "Settings.canDrawOverlays", "FOREGROUND_SERVICE_TYPE_SPECIAL_USE", "CATEGORY_ALARM", "ALARM_MAX_MS"].forEach((t) => assert.ok(svc.includes(t), "serviço: " + t));
assert.ok(plugin.includes("setExactAndAllowWhileIdle") && plugin.includes("canScheduleExactAlarms"), "lembrete em hora exata, com o app fechado");
["ACTION_MANAGE_OVERLAY_PERMISSION", "ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", "ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT", "POST_NOTIFICATIONS", "FLAG_KEEP_SCREEN_ON"].forEach((t) => assert.ok(plugin.includes(t), "plugin: " + t));
assert.ok(tpl.includes("registerPlugin(PfAlertPlugin.class)") && tpl.includes("setShowWhenLocked(true)") && tpl.includes("setTurnScreenOn(true)") && tpl.includes("resumeTimers()"), "MainActivity registra o plugin, aparece sobre a tela bloqueada e não congela o site");

// 3) aplica a camada num projeto Android "de mentira" no formato do Capacitor (duas vezes: não pode duplicar)
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "andr-"));
const jdir = path.join(tmp, "app/src/main/java/br/com/pedefacil/loja");
fs.mkdirSync(jdir, { recursive: true });
fs.writeFileSync(path.join(jdir, "MainActivity.java"), "package br.com.pedefacil.loja;\nimport com.getcapacitor.BridgeActivity;\npublic class MainActivity extends BridgeActivity {}\n");
fs.writeFileSync(path.join(tmp, "app/src/main/AndroidManifest.xml"), '<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <application android:label="x">\n        <activity android:name=".MainActivity" android:launchMode="singleTask" android:exported="true" />\n    </application>\n    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>\n');
for (let i = 0; i < 2; i++) cp.execFileSync("node", [path.join(root, "nativo", "patch-android.js"), tmp], { stdio: "pipe" });
const mf = fs.readFileSync(path.join(tmp, "app/src/main/AndroidManifest.xml"), "utf8");
["POST_NOTIFICATIONS", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_SPECIAL_USE", "USE_FULL_SCREEN_INTENT", "WAKE_LOCK", "VIBRATE", "SYSTEM_ALERT_WINDOW", "SCHEDULE_EXACT_ALARM", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"].forEach((p) => assert.strictEqual(mf.split('android.permission.' + p + '"').length - 1, 1, "manifest: " + p + " uma vez só"));
assert.strictEqual(mf.split("br.com.pedefacil.alert.PfAlertService").length - 1, 1, "serviço declarado uma vez");
assert.ok(mf.includes('android:foregroundServiceType="specialUse"') && mf.includes("br.com.pedefacil.alert.PfAlarmReceiver"), "serviço com tipo e receptor do lembrete");
assert.ok(mf.indexOf("<uses-permission") < mf.indexOf("<application") || mf.includes("INTERNET"), "permissões no lugar certo");
["PfAlertPlugin.java", "PfAlertService.java", "PfAlarmReceiver.java"].forEach((f) => assert.ok(fs.existsSync(path.join(tmp, "app/src/main/java/br/com/pedefacil/alert", f)), "copiou " + f));
const ma = fs.readFileSync(path.join(jdir, "MainActivity.java"), "utf8");
assert.ok(ma.startsWith("package br.com.pedefacil.loja;") && ma.includes("registerPlugin(PfAlertPlugin.class)"), "MainActivity mantém o pacote do app e registra o plugin");
assert.ok(/node \.\.\/\.\.\/patch-android\.js android/.test(rd("nativo", "gerar-apks-nativos.sh")), "script dos APKs nativos aplica a camada");

// 4) site: alarme nativo no lugar do bip, serviço ao entrar, desliga ao sair, sem barra de instalar dentro do app
assert.ok(html.includes("if(PFA.ok())pfNatAlarm(fresh.length);else beep();"), "pedido novo: alarme nativo (bip só no navegador)");
assert.ok(html.includes("pfNatStop();if(DIRTY&&ACCT&&!SUPER)cloudSave();"), "sair desliga o serviço");
assert.ok(html.includes('!(typeof pfIsNative==="function"&&pfIsNative())'), "sem barra de instalar dentro do app");
const wf = rd(".github", "workflows", "apk-nativo.yml");
assert.ok(wf.includes("workflow_dispatch") && wf.includes("bash nativo/gerar-apks-nativos.sh") && wf.includes("apks-nativos"), "fluxo do GitHub para os APKs nativos");
console.log("nativo.test.js: camada de alertas do app Android e ligação com o site ok");
