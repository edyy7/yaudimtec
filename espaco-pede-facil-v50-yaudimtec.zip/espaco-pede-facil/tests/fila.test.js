// Executa o código REAL da fila do index.html (PFQ / pfSend / pfFlush) com IndexedDB e rede simulados.
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const h = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
const a = h.indexOf("var TRKQ={},TRKR={},PFB=false;");
const b = h.indexOf("function qNote()");
assert(a > 0 && b > a, "bloco da fila encontrado");
const code = h.slice(a, b);

// IndexedDB mínimo em memória
function fakeIDB() {
  const stores = {};
  return {
    open() {
      const req = {};
      setTimeout(() => {
        const db = {
          createObjectStore(n) { stores[n] = stores[n] || {}; return {}; },
          transaction(n) {
            const st = stores[n];
            const tx = {};
            const done = () => setTimeout(() => tx.oncomplete && tx.oncomplete(), 0);
            tx.objectStore = () => ({
              put(v) { st[v.tt] = JSON.parse(JSON.stringify(v)); done(); },
              delete(k) { delete st[k]; done(); },
              getAll() { const r = {}; setTimeout(() => { r.result = Object.keys(st).map((k) => JSON.parse(JSON.stringify(st[k]))); r.onsuccess && r.onsuccess(); }, 0); return r; },
            });
            return tx;
          },
        };
        req.result = db;
        req.onupgradeneeded && req.onupgradeneeded();
        req.onsuccess && req.onsuccess();
      }, 0);
      return req;
    },
    stores,
  };
}
const wait = (ms = 30) => new Promise((r) => setTimeout(r, ms));

function ambiente(resp) {
  const idb = fakeIDB();
  const log = { fetch: [], dbwrites: [], renders: 0 };
  const ctx = {
    indexedDB: idb, localStorage: { getItem() { return null; }, setItem() {} },
    navigator: { onLine: true }, location: { protocol: "https:" }, window: { fetch: true, addEventListener() {} },
    setTimeout, setInterval: () => 0, JSON, Object, Array, Date,
    TENANT: { uid: "u1", slug: "loja-teste" }, S: { aberta: true, services: [] }, C: { step: 4, oid: 1, tt: "t".repeat(32), cart: [] },
    DB: { get(p, cb) { cb({ data: JSON.stringify({ aberta: true, services: [{ id: 1, price: 12 }] }) }); }, set() { log.dbwrites.push("set"); }, merge() { log.dbwrites.push("merge"); } },
    norm() {}, render() { log.renders++; },
    fetch: async (url, opts) => { log.fetch.push({ url, body: JSON.parse(opts.body) }); const r = ctx.__resp(); if (r === "rede") throw new Error("sem rede"); return { status: r[0], json: async () => r[1] }; },
  };
  ctx.__resp = resp;
  ctx.window.fetch = ctx.fetch;
  vm.createContext(ctx);
  vm.runInContext(code + "\nthis.__api={PFQ,pfSend,pfFlush,TRKQ,TRKR,pfRetry,getPFB:()=>PFB,getSRV:()=>SRVCLOSED};", ctx);
  return { ctx, idb, log, api: ctx.__api };
}
const pedido = (tt) => ({ id: 1794268070711, tt, name: "Maria", total: 10, lin: [{ id: 1, q: 1, opt: "" }], st: "ok" });

(async () => {
  // 1) sem internet: vai para a fila (IndexedDB) e NADA é gravado direto no Firestore
  let resp = () => "rede";
  let E = ambiente(() => resp());
  const tt = "a".repeat(32);
  E.api.pfSend(pedido(tt));
  await wait();
  assert.strictEqual(E.log.fetch.length, 1);
  assert.strictEqual(E.log.dbwrites.length, 0, "nenhuma gravação direta no Firestore");
  assert.strictEqual(Object.keys(E.idb.stores.pedidos).length, 1, "pedido guardado no IndexedDB");
  assert(E.api.TRKQ[tt], "marcado como na fila");
  // 2) API com erro 503/500 também vai para a fila
  const tt2 = "b".repeat(32);
  resp = () => [503, { erro: "servidor_sem_credencial" }];
  E.api.pfSend(pedido(tt2)); await wait();
  assert.strictEqual(Object.keys(E.idb.stores.pedidos).length, 2);
  assert.strictEqual(E.log.dbwrites.length, 0);
  // 3) a internet volta: a fila é enviada em ordem e esvaziada
  resp = () => [200, { ok: true }];
  E.api.pfFlush(); await wait(120);
  assert.strictEqual(Object.keys(E.idb.stores.pedidos).length, 0, "fila esvaziada");
  assert(!E.api.TRKQ[tt] && !E.api.TRKQ[tt2]);
  assert.deepStrictEqual(E.log.fetch.slice(-2).map((x) => x.body.pedido.tt), [tt, tt2]);
  assert.strictEqual(E.log.dbwrites.length, 0);
  // 4) enquanto a API segue fora, o pedido permanece na fila
  E = ambiente(() => "rede");
  E.api.pfSend(pedido(tt)); await wait();
  E.api.pfFlush(); await wait(60);
  assert.strictEqual(Object.keys(E.idb.stores.pedidos).length, 1, "continua na fila");
  // 5) rejeição definitiva não entra na fila: preço mudou (422) → recarrega a loja e volta ao passo 3
  E = ambiente(() => [422, { erro: "preco_divergente", total: 12 }]);
  E.api.pfSend(pedido(tt)); await wait();
  assert.strictEqual(E.idb.stores.pedidos, undefined, "422 não vai para a fila");
  assert.strictEqual(E.ctx.C.step, 3); assert(/preços/.test(E.ctx.C.msg)); assert.strictEqual(E.ctx.S.services[0].price, 12);
  assert.strictEqual(E.log.dbwrites.length, 0);
  // 6) loja fechada (409): volta ao passo 3 sem fila
  E = ambiente(() => [409, { erro: "loja_fechada" }]);
  E.api.pfSend(pedido(tt)); await wait();
  assert.strictEqual(E.api.getSRV(), true); assert.strictEqual(E.ctx.C.step, 3); assert.strictEqual(E.idb.stores.pedidos, undefined);
  // 7) pedido recusado quando a fila é reenviada (loja fechou): sai da fila e fica registrado
  E = ambiente(() => "rede");
  E.api.pfSend(pedido(tt)); await wait();
  E.ctx.__resp = () => [409, { erro: "loja_fechada" }];
  E.api.pfFlush(); await wait(80);
  assert.strictEqual(Object.keys(E.idb.stores.pedidos).length, 0); assert.strictEqual(E.api.TRKR[tt], "loja_fechada");
  console.log("fila.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
