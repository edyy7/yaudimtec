// api/pedido.js: preço recalculado no servidor, conta de serviço, loja fechada; e checagem estática do app e das regras.
process.env.PF_LIMITE_OFF = "1"; // o limite de pedidos (M-01) tem teste próprio; aqui ele atrapalharia a contagem de gravações
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const root = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(root, f), "utf8");

const { privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
const SA = { client_email: "pf@delivery-67d14.iam.gserviceaccount.com", private_key: privateKey, project_id: "delivery-67d14", token_uri: "https://oauth2.googleapis.com/token" };

let LOJA;
const T0 = Date.now() - 3600e3; // ids de pedido = hora em ms; os testes de estoque usam horas recentes (janela de 7 dias)
const nova = () => ({
  nome: "Loja Teste", aberta: true, modo: "cardapio", mods: { kds: true, entrega: true }, pix: "11999999999", sinal: true, pct: 30,
  services: [
    { id: 1, name: "Pastel", price: 10, opts: ["Queijo extra:2,50", "Bacon:3"] },
    { id: 2, name: "Suco", price: 7.5, opts: [] },
  ],
});
const writes = [], reads = [], auths = [];
const contatos = [];
let tokenCalls = 0, existe = {};
const PEDIDOS = [], deletes = []; let CT = 0, consultaFalha = false;
const COUNTERS = {}, commits = []; let txFalha = false, txN = 0, rollbacks = 0, abortar = 0, aoAbortar = null; // contador reservado + transação simulados
const resp = (ok, status, body) => ({ ok, status, json: async () => body || {} });
const createTime = () => "2026-11-18T10:00:00." + String(++CT).padStart(6, "0") + "Z";
global.fetch = async (url, opts = {}) => {
  if (url === SA.token_uri) {
    tokenCalls++;
    assert.strictEqual(opts.method, "POST");
    assert(/assertion=[\w-]+\.[\w-]+\.[\w-]+/.test(opts.body), "JWT assinado");
    return { ok: true, json: async () => ({ access_token: "tk-servidor", expires_in: 3600 }) };
  }
  auths.push((opts.headers || {}).Authorization);
  assert(!/[?&]key=/.test(url), "sem chave de API: só credencial de servidor");
  if (/documents:beginTransaction$/.test(url)) { if (txFalha) return resp(false, 500); return resp(true, 200, { transaction: "tx" + (++txN) }); }
  if (/documents:rollback$/.test(url)) { rollbacks++; return resp(true, 200); }
  if (/documents:commit$/.test(url)) {
    const body = JSON.parse(opts.body); commits.push(body);
    assert(body.transaction, "o commit vai dentro da transação");
    if (abortar > 0) { abortar--; if (aoAbortar) { const f = aoAbortar; aoAbortar = null; f(); } return resp(false, 409, { error: { status: "ABORTED" } }); }
    const cam = (w) => String((w.update && w.update.name) || w.delete).replace(/^.*\/documents\//, "");
    for (const w of body.writes) { // precondições: criar exige que não exista
      const c = cam(w);
      if (w.currentDocument && w.currentDocument.exists === false) {
        const mp = /^pf_lojas\/u1\/pedidos\/(\d+)$/.exec(c), mc = /^pf_lojas\/u1\/reservado\/(\d+)$/.exec(c);
        if ((mp && (existe[c] || PEDIDOS.some((p) => String(p.id) === mp[1]))) || (mc && COUNTERS[mc[1]] !== undefined)) return resp(false, 409, { error: { status: "ALREADY_EXISTS" } });
      }
    }
    for (const w of body.writes) {
      const c = cam(w), mp = /^pf_lojas\/u1\/pedidos\/(\d+)$/.exec(c), mc = /^pf_lojas\/u1\/reservado\/(\d+)$/.exec(c);
      if (mp && w.update) {
        const fl = w.update.fields, d = {}; Object.keys(fl).forEach((k) => { d[k] = fsx.fromFs(fl[k]); });
        writes.push({ col: "pf_lojas/u1/pedidos", id: mp[1], fields: fl });
        PEDIDOS.push({ id: +mp[1], createTime: createTime(), d });
      } else if (mc && w.updateTransforms) COUNTERS[mc[1]] += +w.updateTransforms[0].increment.integerValue;
      else if (mc && w.update) COUNTERS[mc[1]] = +fsx.fromFs(w.update.fields.q);
    }
    return resp(true, 200);
  }
  const m = /documents\/(.+?)(\?|$)/.exec(url);
  const doc = decodeURIComponent(m[1]);
  if (opts.method === "POST" && /:runQuery$/.test(doc)) {
    if (consultaFalha) return { ok: false, status: 500, json: async () => ({}) };
    const q = JSON.parse(opts.body).structuredQuery, min = +q.where.fieldFilter.value.integerValue;
    const sentido = q.orderBy[0].direction === "DESCENDING" ? -1 : 1;
    const rows = PEDIDOS.filter((p) => p.id >= min).sort((a, b) => sentido * (a.id - b.id)).slice(0, q.limit)
      .map((p) => ({ document: { name: "x", fields: fsx.fields(p.d), createTime: p.createTime } }));
    return { ok: true, status: 200, json: async () => (rows.length ? rows : [{ readTime: "t" }]) };
  }
  if (opts.method === "DELETE") {
    const mm = /^pf_lojas\/u1\/pedidos\/(\d+)$/.exec(doc);
    if (mm) { const k = PEDIDOS.findIndex((p) => String(p.id) === mm[1]); if (k >= 0) PEDIDOS.splice(k, 1); deletes.push(doc); }
    return { ok: true, status: 200, json: async () => ({}) };
  }
  if (opts.method === "POST") {
    const id = /documentId=([^&]+)/.exec(url)[1];
    if (existe[doc + "/" + id]) return { ok: false, status: 409, json: async () => ({}) };
    const fl = JSON.parse(opts.body).fields;
    if (/\/contato$/.test(doc)) { contatos.push({ col: doc, id, fields: fl }); return { ok: true, status: 200, json: async () => ({}) }; } // M-06: contato do cliente, fora do documento do pedido
    writes.push({ col: doc, id, fields: fl });
    if (doc === "pf_lojas/u1/pedidos") {
      const d = {}; Object.keys(fl).forEach((k) => { d[k] = fsx.fromFs(fl[k]); });
      PEDIDOS.push({ id: +id, createTime: createTime(), d });
    }
    return { ok: true, status: 200, json: async () => ({}) };
  }
  reads.push(doc);
  const D = {
    "pf_slugs/loja-teste": { uid: { stringValue: "u1" } },
    "pf_lojas_publicas/u1": { data: { stringValue: JSON.stringify(LOJA) } },
  };
  if (doc.startsWith("pf_lojas/u1/pedidos/") && existe[doc]) return { ok: true, status: 200, json: async () => ({ fields: existe[doc] }) };
  const mcr = /^pf_lojas\/u1\/reservado\/(\d+)$/.exec(doc);
  if (mcr) return COUNTERS[mcr[1]] === undefined ? resp(false, 404) : resp(true, 200, { fields: { q: { integerValue: String(COUNTERS[mcr[1]]) } } });
  const d = D[doc];
  return { ok: !!d, status: d ? 200 : 404, json: async () => ({ fields: d }) };
};
const handler = require("../api/pedido");
const fsx = require("../api/_fs");
function call(method, body) {
  return new Promise((resolve) => {
    const res = { code: 200, h: {}, setHeader(k, v) { this.h[k] = v; }, status(c) { this.code = c; return this; }, json(b) { resolve({ code: this.code, body: b }); } };
    handler({ method, body, headers: { host: "espacopedefacil.vercel.app" } }, res);
  });
}
const ped = (o = {}) => Object.assign({ id: 1794268070711, tt: "a".repeat(32), name: "Maria Silva", phone: "27999999999", total: 25, pag: "pix", ent: "entrega", addr: "Rua A, 10", obs: "", lin: [{ id: 1, q: 2, opt: "Queijo extra" }, { id: 2, q: 1, opt: "" }], st: "ok" }, o);
const F = (w, k) => w.fields[k];

(async () => {
  LOJA = nova();
  assert.strictEqual((await call("GET")).code, 405);
  // sem credencial de servidor: falha fechada, nada é gravado
  delete process.env.PF_SA_JSON;
  let r = await call("POST", { slug: "loja-teste", pedido: ped() });
  assert.strictEqual(r.code, 503); assert.strictEqual(r.body.erro, "servidor_sem_credencial"); assert.strictEqual(writes.length, 0);
  process.env.PF_SA_JSON = JSON.stringify(SA); fsx._reset();

  // preço correto: (10+2,50)*2 + 7,50 = 32,50  → cliente mandou 25 (menor) → REJEITA
  r = await call("POST", { slug: "loja-teste", pedido: ped({ total: 25 }) });
  assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "preco_divergente"); assert.strictEqual(r.body.total, 32.5);
  assert.strictEqual(writes.length, 0, "nada gravado quando o preço é menor");
  r = await call("POST", { slug: "loja-teste", pedido: ped({ total: 32.48 }) }); assert.strictEqual(r.code, 422); // 2 centavos a menos: além da tolerância de 1 centavo
  // preço correto → grava com os valores do SERVIDOR
  r = await call("POST", { slug: "loja-teste", pedido: ped({ total: 32.5 }) });
  assert.strictEqual(r.code, 200, JSON.stringify(r.body)); assert.strictEqual(r.body.total, 32.5);
  assert.strictEqual(writes.length, 2);
  assert.strictEqual(writes[0].col, "pf_lojas/u1/pedidos");
  assert.strictEqual(F(writes[0], "total").doubleValue, 32.5);
  assert.strictEqual(F(writes[0], "items").stringValue, "2x Pastel (Queijo extra); 1x Suco");
  assert.strictEqual(F(writes[0], "sinal").doubleValue, 9.75); // 30% de 32,50
  assert.strictEqual(F(writes[0], "tipo").stringValue, "sinal"); assert.strictEqual(F(writes[0], "fase").stringValue, "novo");
  assert.strictEqual(writes[1].col, "pf_rastreio"); assert.strictEqual(writes[1].id, "a".repeat(32));
  assert(!("phone" in writes[1].fields) && !("addr" in writes[1].fields), "rastreio público sem telefone nem endereço");
  // M-06: o pedido (que a cozinha lê) não leva telefone nem endereço; eles vão para pedidos/{id}/contato/dados; entrega nasce sem entregador
  assert(!("phone" in writes[0].fields) && !("addr" in writes[0].fields), "pedido sem telefone nem endereço");
  assert.strictEqual(F(writes[0], "ent_uid").stringValue, "", "entrega nasce sem entregador (ent_uid vazio)");
  assert.strictEqual(contatos.length, 1); assert.strictEqual(contatos[0].col, "pf_lojas/u1/pedidos/" + writes[0].id + "/contato"); assert.strictEqual(contatos[0].id, "dados");
  assert.strictEqual(F(contatos[0], "phone").stringValue, "27999999999"); assert.strictEqual(F(contatos[0], "addr").stringValue, "Rua A, 10");
  assert(auths.length && auths.every((a) => a === "Bearer tk-servidor"), "toda chamada usa a credencial do servidor");
  assert.strictEqual(tokenCalls, 1, "token reaproveitado");

  // total maior que o real: aceito, mas grava o valor do servidor
  writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: 1794268070712, tt: "b".repeat(32), total: 99 }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(F(writes[0], "total").doubleValue, 32.5);
  // item/adicional que não existe → rejeita
  writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ lin: [{ id: 99, q: 1, opt: "" }], total: 1 }) }); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "produto_invalido");
  r = await call("POST", { slug: "loja-teste", pedido: ped({ lin: [{ id: 1, q: 1, opt: "Camarão grátis" }], total: 1 }) }); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "adicional_invalido");
  // quantidade/linhas inválidas, total negativo
  r = await call("POST", { slug: "loja-teste", pedido: ped({ lin: [{ id: 1, q: -3, opt: "" }] }) }); assert.strictEqual(r.code, 400);
  r = await call("POST", { slug: "loja-teste", pedido: ped({ lin: [] }) }); assert.strictEqual(r.code, 400);
  r = await call("POST", { slug: "loja-teste", pedido: ped({ total: -5 }) }); assert.strictEqual(r.code, 400);
  assert.strictEqual(writes.length, 0);
  // preço mudou na loja depois que o cliente montou o carrinho
  LOJA.services[1].price = 9;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ total: 32.5 }) }); assert.strictEqual(r.code, 422);
  LOJA = nova();
  // pagamento: sem Pix na loja → paga no local, sinal 0 (mesmo que o cliente peça Pix)
  LOJA.pix = ""; writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: 1794268070713, tt: "c".repeat(32), total: 32.5 }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(F(writes[0], "pag").stringValue, "local"); assert.strictEqual(F(writes[0], "sinal").integerValue, "0");
  LOJA = nova();
  // loja fechada: 409 para TODO pedido; "st":"pend" enviado pelo navegador não abre exceção (auditoria A-01)
  LOJA.horarioOk = true; LOJA.days = []; writes.length = 0; // sem nenhum dia de atendimento = fechada
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: 1794268070714, tt: "d".repeat(32), total: 32.5 }) });
  assert.strictEqual(r.code, 409); assert.strictEqual(r.body.erro, "loja_fechada"); assert.strictEqual(writes.length, 0);
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: 1794268070715, tt: "e".repeat(32), total: 32.5, st: "pend" }) }); assert.strictEqual(r.code, 409, "st:pend forjado não passa com a loja fechada"); assert.strictEqual(writes.length, 0);
  LOJA = nova();
  // horário de atendimento (Brasília = UTC-3): dias, início/fim e intervalo
  const L = require("../api/pedido.js").lojaAberta;
  const H = { horarioOk: true, days: [1, 2, 3, 4, 5], start: 9, end: 17, ibS: 12, ibE: 13 };
  assert.strictEqual(L({ days: [] }, new Date("2026-11-16T15:00:00Z")), true, "sem horário definido = sempre aberta");
  assert.strictEqual(L(H, new Date("2026-11-16T13:00:00Z")), true, "seg 10:00 aberta");
  assert.strictEqual(L(H, new Date("2026-11-16T15:30:00Z")), false, "seg 12:30 intervalo");
  assert.strictEqual(L(H, new Date("2026-11-16T16:00:00Z")), true, "seg 13:00 volta");
  assert.strictEqual(L(H, new Date("2026-11-16T11:59:00Z")), false, "seg 08:59 antes de abrir");
  assert.strictEqual(L(H, new Date("2026-11-16T20:00:00Z")), false, "seg 17:00 já fechou");
  assert.strictEqual(L(H, new Date("2026-11-15T15:00:00Z")), false, "domingo fechada");
  assert.strictEqual(L(Object.assign({}, H, { days: [0], start: 18, end: 24, ibS: 0, ibE: 0 }), new Date("2026-11-16T01:30:00Z")), true, "dom 22:30 (seg 01:30 UTC), fecha à meia-noite");
  // id repetido de OUTRO pedido: usa o próximo id livre, nunca descarta; reenvio do MESMO pedido é idempotente
  writes.length = 0;
  existe["pf_lojas/u1/pedidos/1794268070720"] = { tt: { stringValue: "f".repeat(32) } };
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: 1794268070720, tt: "1".repeat(32), total: 32.5 }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.id, 1794268070721);
  existe["pf_lojas/u1/pedidos/1794268070730"] = { tt: { stringValue: "2".repeat(32) } };
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: 1794268070730, tt: "2".repeat(32), total: 32.5 }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.id, 1794268070730);
  // ---- ESTOQUE RESERVADO: contador por produto, criado/atualizado na MESMA transação do pedido ----
  const lin2 = (q) => [{ id: 1, q, opt: "" }];
  const pedNovo = (n, q, extra) => ped(Object.assign({ id: (T0 + 800) + n, tt: String(n).padStart(2, "0").repeat(16), lin: lin2(q), total: 10 * q }, extra || {}));
  const zera = () => { PEDIDOS.length = 0; deletes.length = 0; writes.length = 0; commits.length = 0; rollbacks = 0; abortar = 0; aoAbortar = null; txFalha = false; consultaFalha = false; Object.keys(COUNTERS).forEach((k) => delete COUNTERS[k]); };
  // 1ª venda cria o contador; as seguintes somam; acabou = 409 e nada muda
  LOJA = nova(); LOJA.services[0].estoque_atual = 3; zera();
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(1, 2) }); assert.strictEqual(r.code, 200, "2 de 3");
  assert.strictEqual(COUNTERS[1], 2, "contador criado com a quantidade reservada");
  assert.strictEqual(commits.length, 1, "pedido + contador num commit só");
  assert(commits[0].writes[0].currentDocument.exists === false && commits[0].writes[1].currentDocument.exists === false, "ambos criados com precondição (sem sobrescrever)");
  assert.strictEqual(F(writes[0], "rv").booleanValue, true, "pedido marcado como reservado");
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(2, 2) }); assert.strictEqual(r.code, 409); assert.strictEqual(r.body.erro, "estoque_insuficiente"); assert.strictEqual(r.body.disponivel, 1);
  assert.strictEqual(COUNTERS[1], 2, "pedido recusado não mexe no contador"); assert.strictEqual(PEDIDOS.length, 1); assert(rollbacks >= 1, "transação solta no 409");
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(3, 1) }); assert.strictEqual(r.code, 200);
  const w3 = commits[commits.length - 1].writes[1];
  assert.strictEqual(w3.updateTransforms[0].increment.integerValue, "1", "contador existente: soma atômica (increment), sem sobrescrever"); assert.strictEqual(COUNTERS[1], 3);
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(4, 1) }); assert.strictEqual(r.code, 409); assert.strictEqual(r.body.disponivel, 0);
  // soma das linhas do mesmo produto; "st":"pend" forjado também é recusado por estoque (A-01)
  LOJA = nova(); LOJA.services[0].estoque_atual = 3; zera();
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 840), tt: "4".repeat(32), lin: [{ id: 1, q: 2, opt: "" }, { id: 1, q: 2, opt: "Bacon" }], total: 100 }) });
  assert.strictEqual(r.code, 409); assert.strictEqual(r.body.disponivel, 3, "2 + 2 pedidos de uma vez, 3 disponíveis");
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(5, 4, { st: "pend" }) }); assert.strictEqual(r.code, 409, "st:pend não fura o estoque"); assert(!COUNTERS[1], "recusado não reserva");
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(6, 1) }); assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 1);
  // esgotado no publicado: nada gravado
  LOJA = nova(); LOJA.services[0].estoque_atual = 0; zera();
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(7, 1) }); assert.strictEqual(r.code, 409); assert.strictEqual(writes.length, 0, "esgotado: nada gravado"); assert.strictEqual(commits.length, 0);
  // o /api/baixa devolveu reservado (contador menor): libera vendas até o estoque publicado
  LOJA = nova(); LOJA.services[0].estoque_atual = 5; zera(); COUNTERS[1] = 1;
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(8, 4) }); assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 5);
  // SEMENTE: contador novo parte dos pedidos sem baixa que já existiam (legado): com baixa e rv:false não contam
  LOJA = nova(); LOJA.services[0].estoque_atual = 5; zera();
  PEDIDOS.push({ id: T0 + 700, createTime: "2026-11-18T09:00:00.000001Z", d: { id: T0 + 700, lin: lin2(3) } });
  PEDIDOS.push({ id: T0 + 701, createTime: "2026-11-18T09:00:00.000002Z", d: { id: T0 + 701, lin: lin2(9), baixa: true } });
  PEDIDOS.push({ id: T0 + 702, createTime: "2026-11-18T09:00:00.000003Z", d: { id: T0 + 702, lin: lin2(9), rv: false } });
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(9, 3) }); assert.strictEqual(r.code, 409, "o legado sem baixa reserva 3 dos 5"); assert.strictEqual(r.body.disponivel, 2);
  assert.strictEqual(Object.keys(COUNTERS).length, 0, "recusado: contador não é criado");
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(10, 2) }); assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 5, "semente 3 + 2 do pedido");
  // CORRIDA: o commit é abortado porque um rival levou a última unidade; o servidor lê de novo e recusa quem perdeu
  LOJA = nova(); LOJA.services[0].estoque_atual = 1; zera(); COUNTERS[1] = 0;
  abortar = 1; aoAbortar = () => { COUNTERS[1] = 1; };
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(11, 1) });
  assert.strictEqual(r.code, 409, "perdeu a corrida"); assert.strictEqual(r.body.disponivel, 0); assert.strictEqual(COUNTERS[1], 1); assert.strictEqual(PEDIDOS.length, 0, "nada gravado");
  // e se sobrou estoque depois do rival, a nova tentativa passa
  LOJA = nova(); LOJA.services[0].estoque_atual = 3; zera(); COUNTERS[1] = 0;
  abortar = 1; aoAbortar = () => { COUNTERS[1] = 1; };
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(12, 1) }); assert.strictEqual(r.code, 200); assert.strictEqual(COUNTERS[1], 2); assert.strictEqual(commits.length, 2, "1 abortado + 1 ok");
  // conflito sem parar: desiste com 502 (o app guarda o pedido na fila do aparelho), sem gravar nem reservar
  LOJA = nova(); LOJA.services[0].estoque_atual = 3; zera(); COUNTERS[1] = 0; abortar = 99;
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(13, 1) }); assert.strictEqual(r.code, 502); assert.strictEqual(PEDIDOS.length, 0); assert.strictEqual(COUNTERS[1], 0); abortar = 0;
  // reenvio do MESMO pedido (a resposta se perdeu): não reserva duas vezes
  LOJA = nova(); LOJA.services[0].estoque_atual = 5; zera(); COUNTERS[1] = 2;
  existe["pf_lojas/u1/pedidos/" + (T0 + 850)] = { tt: { stringValue: "3".repeat(32) } };
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: T0 + 850, tt: "3".repeat(32), lin: lin2(1), total: 10 }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.id, T0 + 850); assert.strictEqual(COUNTERS[1], 2, "reenvio não soma de novo");
  // id ocupado por OUTRO pedido: usa o próximo e reserva uma vez só
  existe["pf_lojas/u1/pedidos/" + (T0 + 860)] = { tt: { stringValue: "9".repeat(32) } };
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: T0 + 860, tt: "5".repeat(32), lin: lin2(1), total: 10 }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(r.body.id, T0 + 861); assert.strictEqual(COUNTERS[1], 3);
  delete existe["pf_lojas/u1/pedidos/" + (T0 + 850)]; delete existe["pf_lojas/u1/pedidos/" + (T0 + 860)];
  // FALHA FECHADA (auditoria): sem como reservar, produto com estoque controlado NÃO tem venda confirmada: 503 e nada gravado
  LOJA = nova(); LOJA.services[0].estoque_atual = 3; zera(); txFalha = true;
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(14, 2) }); assert.strictEqual(r.code, 503, "sem reserva, sem venda"); assert.strictEqual(r.body.erro, "reserva_indisponivel"); assert.strictEqual(writes.length, 0, "nada gravado"); assert.strictEqual(PEDIDOS.length, 0); assert.strictEqual(Object.keys(COUNTERS).length, 0); txFalha = false;
  zera(); LOJA.services[0].estoque_atual = 3; consultaFalha = true; // contador novo e a consulta de semente caiu
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(16, 2) }); assert.strictEqual(r.code, 503); assert.strictEqual(writes.length, 0); consultaFalha = false;
  // sem controle de estoque: nenhuma transação
  LOJA = nova(); zera(); txN = 0;
  r = await call("POST", { slug: "loja-teste", pedido: pedNovo(17, 2) }); assert.strictEqual(r.code, 200); assert.strictEqual(PEDIDOS.length, 1); assert.strictEqual(txN, 0, "sem controle de estoque não abre transação"); assert.strictEqual(commits.length, 0);
  LOJA = nova();
  // entrega com módulo desligado: rejeita sempre; nunca vira retirada em silêncio (A-01)
  LOJA = nova(); LOJA.mods = { kds: true, entrega: false }; writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 744), tt: "7".repeat(32), total: 32.5 }) }); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "entrega_indisponivel"); assert.strictEqual(writes.length, 0);
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 745), tt: "8".repeat(32), total: 32.5, ent: "retirada" }) }); assert.strictEqual(r.code, 200);
  writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 746), tt: "9".repeat(32), total: 32.5, st: "pend" }) }); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "entrega_indisponivel"); assert.strictEqual(writes.length, 0);
  // ---- NEGATIVOS (auditoria A-01 / A-02): o navegador não decide o status de pagamento ----
  assert.strictEqual(require("../api/pedido.js").limpa(ped({ st: "ok" })).st, undefined, "limpa() não repassa o st do cliente");
  LOJA = nova(); writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 760), tt: "b".repeat(31) + "1", total: 32.5, pag: "pix", st: "ok" }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(F(writes[writes.length - 2], "pag").stringValue, "pix");
  assert.strictEqual(F(writes[writes.length - 2], "st").stringValue, "pend", "Pix com st:ok forjado nasce pendente");
  assert.strictEqual(F(writes[writes.length - 1], "st").stringValue, "pend", "o rastreio também fica pendente");
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 761), tt: "b".repeat(31) + "2", total: 32.5, pag: "pix", st: "qualquer" }) });
  assert.strictEqual(F(writes[writes.length - 2], "st").stringValue, "pend", "valor inesperado em st também é ignorado");
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 762), tt: "b".repeat(31) + "3", total: 32.5, pag: "local", st: "pend" }) });
  assert.strictEqual(r.code, 200); assert.strictEqual(F(writes[writes.length - 2], "st").stringValue, "ok", "pagamento no local nasce liberado; o servidor decide");
  LOJA = nova(); LOJA.pix = ""; writes.length = 0; // loja sem Pix: pag:pix do cliente é rebaixado para local, nunca fica "pago"
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 763), tt: "b".repeat(31) + "4", total: 32.5, pag: "pix", st: "ok" }) });
  assert.strictEqual(F(writes[writes.length - 2], "pag").stringValue, "local"); assert.strictEqual(F(writes[writes.length - 2], "st").stringValue, "ok");
  LOJA = nova();
  // sem Cozinha ligada o pedido nasce pronto (não fica preso em "novo")
  LOJA = nova(); LOJA.mods = { kds: false, entrega: true }; writes.length = 0;
  r = await call("POST", { slug: "loja-teste", pedido: ped({ id: (T0 + 747), tt: "a".repeat(31) + "1", total: 32.5 }) }); assert.strictEqual(r.code, 200);
  assert.strictEqual(F(writes[0], "fase").stringValue, "pronto"); assert.ok(F(writes[0], "prontoEm")); assert.strictEqual(F(writes[1], "fase").stringValue, "pronto");
  LOJA = nova();
  // outras validações
  r = await call("POST", { slug: "x/..", pedido: ped() }); assert.strictEqual(r.code, 400);
  r = await call("POST", { slug: "loja-teste", pedido: ped({ tt: "zz" }) }); assert.strictEqual(r.code, 400);
  r = await call("POST", { slug: "naoexiste", pedido: ped() }); assert.strictEqual(r.code, 404);
  global.fetch = async () => { throw new Error("sem rede"); };
  r = await call("POST", { slug: "loja-teste", pedido: ped() }); assert.strictEqual(r.code, 502);

  // ---- estático: app e regras ----
  assert(JSON.parse(read("vercel.json")).functions["api/pedido.js"]);
  const h = read("index.html");
  ["function pfTok()", "function trackView()", "DB.watch(\"rastreio/\"", "function lojaFechada()", "lojaFechada()?'<span class=\"chip\" style=\"margin:0\">🔒 Loja fechada</span>':'<button data-cont>", "STAB===\"mkt\"", "indexedDB.open(N,1)", "var N=\"pf-fila\"", "fetch(\"/api/pedido\"", "function pfLin()"].forEach((x) => assert(h.includes(x), "index.html sem: " + x));
  // o app NÃO escreve pedido nem rastreio direto no Firestore
  assert(!/DB\.(set|merge)\(\s*"lojas\/"\s*\+\s*(TENANT\.uid|uid)\s*\+\s*"\/pedidos/.test(h), "cliente não pode gravar pedido direto");
  assert(!h.includes("DB.set(\"rastreio/"), "cliente não pode gravar rastreio direto");
  assert(!h.includes("direct()"), "sem fallback direto");
  const rl = read("firestore.rules");
  assert(!rl.includes("customerOrder"), "regra de criação pelo cliente removida");
  const ped_ = rl.slice(rl.indexOf("match /pedidos/{pid}"), rl.indexOf("match /comissoes"));
  assert(/allow create: if isOwner\(uid\);/.test(ped_) && !/isGarcom\(uid\)\s*\n?\s*&&\s*request\.resource/.test(ped_), "create de pedido direto: só o dono (o garçom vai por /api/mesa)");
  const rast = rl.slice(rl.indexOf("match /pf_rastreio/{tk}"), rl.indexOf("match /{path=**}/equipe"));
  assert(rast.includes("allow create: if false;") && rast.includes("allow get: if true;") && rast.includes("allow list: if false;"));
  // o cliente tira do carrinho o item que acabou (senão repete o mesmo 409 em loop)
{
  const hh = read("index.html");
  assert.ok(hh.includes("function pfAjusteEstoque(id,disp)") && hh.includes("pfAjusteEstoque(j.id,j.disponivel)"), "409 de estoque ajusta o carrinho do cliente");
  assert.ok(hh.includes("acabou e saiu do seu carrinho") && hh.includes("Só restam "), "mensagens de estoque");
}
console.log("pedido.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
