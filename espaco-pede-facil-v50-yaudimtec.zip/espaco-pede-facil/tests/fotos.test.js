// Testa scripts/baixar-fotos.js com o Pexels simulado (sem rede)
const assert = require("assert"), fs = require("fs"), os = require("os"), path = require("path");
const sharp = require(process.env.SHARP_PATH || "../scripts/node_modules/sharp");
const { main, parseCsv, consulta } = require("../scripts/baixar-fotos");

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "pf-"));
fs.mkdirSync(path.join(tmp, "prompts"));
const csv = "\uFEFFsegmento,nicho_chave,nicho,numero,arquivo,item,prompt,negativo\n" +
  'A,pizza,Pizzarias,1,img/pizza/01.webp,Mussarela,"p1 ""x""",n\n' +
  'A,pizza,Pizzarias,2,img/pizza/02.webp,Calabresa,p2,n\n' +
  'A,calcados,Calçados,1,img/calcados/01.webp,Tênis Casual (34),p3,n\n' +
  'A,tattoo,Tatuagem,1,img/tattoo/01.webp,Retoque,p4,n\n';
fs.writeFileSync(path.join(tmp, "prompts", "prompts_imagens_nichos.csv"), csv);

assert.strictEqual(parseCsv(csv).length, 4); assert.strictEqual(parseCsv(csv)[0].prompt, 'p1 "x"');
assert.strictEqual(consulta({ nicho_chave: "pizza", item: "Mussarela" }), "pizza Mussarela");
assert.strictEqual(consulta({ nicho_chave: "calcados", item: "Tênis Casual (34)" }), "calçado Tênis Casual");

(async () => {
  const jpg = await sharp({ create: { width: 1600, height: 1200, channels: 3, background: { r: 180, g: 80, b: 40 } } }).jpeg().toBuffer();
  const seen = [];
  const mk = (status = 200) => async (url, opts) => {
    seen.push(url);
    if (url.startsWith("https://api.pexels.com/")) {
      if (!opts.headers.Authorization) throw new Error("sem chave");
      if (status !== 200) return { status, ok: false, json: async () => ({}) };
      const q = new URL(url).searchParams.get("query");
      const sq = new URL(url).searchParams.get("orientation") === "square";
      if (/Retoque/.test(q)) return { status: 200, ok: true, json: async () => ({ photos: [] }) };
      return { status: 200, ok: true, json: async () => ({ photos: [{ width: 1200, height: 1200, photographer: "Ana Foto", photographer_url: "https://p/ana", url: "https://pexels/1", src: { original: "https://images.pexels.com/photos/1/a.jpeg" } }] }) };
    }
    return { ok: true, status: 200, arrayBuffer: async () => jpg };
  };
  const args = [];
  let r = await main({ root: tmp, key: "K", args, fetchFn: mk(), sharp, pausa: 0, log: () => {} });
  assert.strictEqual(r.baixadas, 3); assert.strictEqual(r.semResultado, 1); assert.strictEqual(r.falta, 1);
  for (const f of ["img/pizza/01.webp", "img/pizza/02.webp", "img/calcados/01.webp"]) {
    const b = fs.readFileSync(path.join(tmp, f)); const m = await sharp(b).metadata();
    assert.strictEqual(m.format, "webp"); assert.strictEqual(m.width, 1024); assert.strictEqual(m.height, 1024); assert(b.length <= 150 * 1024);
  }
  const cred = JSON.parse(fs.readFileSync(path.join(tmp, "img", "creditos.json"), "utf8"));
  assert.strictEqual(cred["img/pizza/01.webp"].fotografo, "Ana Foto");
  assert(fs.readFileSync(path.join(tmp, "img", "revisao.html"), "utf8").includes("Ana Foto"));
  // retomada: não refaz o que já existe
  seen.length = 0; r = await main({ root: tmp, key: "K", args: ["--nicho", "pizza"], fetchFn: mk(), sharp, pausa: 0, log: () => {} });
  assert.strictEqual(r.baixadas, 0); assert.strictEqual(r.puladas, 2); assert.strictEqual(seen.length, 0);
  // limite do lote
  fs.rmSync(path.join(tmp, "img", "pizza"), { recursive: true });
  r = await main({ root: tmp, key: "K", args: ["--lote", "1", "--nicho", "pizza"], fetchFn: mk(), sharp, pausa: 0, log: () => {} });
  assert.strictEqual(r.baixadas, 1); assert.strictEqual(r.parou, "lote");
  // 429 para sem erro
  fs.rmSync(path.join(tmp, "img", "pizza"), { recursive: true });
  r = await main({ root: tmp, key: "K", args: ["--nicho", "pizza"], fetchFn: mk(429), sharp, pausa: 0, log: () => {} });
  assert.strictEqual(r.parou, "limite"); assert.strictEqual(r.baixadas, 0);
  // sem chave
  await assert.rejects(() => main({ root: tmp, key: "", args: [], fetchFn: mk(), sharp, log: () => {} }), /PEXELS_KEY/);
  console.log("fotos.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
