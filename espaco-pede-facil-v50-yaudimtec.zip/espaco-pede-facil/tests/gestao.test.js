// Garante: manifests por função, travas de função (RBAC), Pix com valor exato, afiliados e regras
const assert = require("assert"), fs = require("fs"), path = require("path"), vm = require("vm");
const R = (...p) => path.join(__dirname, "..", ...p);
const read = (...p) => fs.readFileSync(R(...p), "utf8");

// 1) Um manifest por função (na raiz), com id e start_url próprios dentro do scope
const roles = { cozinha: ["kds", "/cozinha", "Yaudimtec Cozinha"], motoboy: ["ent", "/motoboy", "Yaudimtec Entregas"], garcom: ["garcom", "/garcom", "Yaudimtec Garçom"], lojista: ["ped", "/loja", "Yaudimtec Loja"], adm: ["adm", "/adm", "Yaudimtec ADM"] };
const ids = new Set();
for (const [f, [op, id, name]] of Object.entries(roles)) {
  const m = JSON.parse(read("manifest-" + f + ".json"));
  assert.strictEqual(m.name, name, f + ": nome");
  assert.strictEqual(m.id, id, f + ": id");
  assert.ok(m.start_url.startsWith("/app/") && m.start_url.endsWith("/?op=" + op), f + ": start_url");
  assert.ok(m.start_url.startsWith(m.scope), f + ": start_url dentro do scope");
  assert.ok(!ids.has(m.id), f + ": id único"); ids.add(m.id);
  const h = read("gestao", f + ".html");
  assert.ok(h.includes('<link rel="manifest" href="/manifest-' + f + '.json">'), f + ": o <head> aponta para o seu manifest");
  assert.ok(/set\("op","(kds|ent|garcom|ped|adm)"\)/.test(h), f + ": abre a tela por ?op=");
}
assert.ok(read("gestao", "index.html").includes("garcom.html"), "índice /gestao lista o garçom");

// 2) index.html: scripts compilam, manifest troca por função, ref capturado
const html = read("index.html");
const scripts = [...html.matchAll(/<script(?![^>]*\bsrc\b)(?![^>]*json)[^>]*>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
scripts.forEach((s, i) => { if (s.trim().startsWith("{")) return; new vm.Script(s, { filename: "inline" + i }); });
assert.ok(html.includes('l.href=MAN[op]?"/manifest-"+MAN[op]+".json":"/manifest.webmanifest"') && !/<link rel="manifest"/.test(html.split("</head>")[0]), "index troca o manifest por ?op= (sem função: manifest genérico, nunca o da Loja)");
assert.ok(html.includes("Instala só este perfil") && html.includes("Baixar e instalar</button>"), "botão Baixar e instalar com aviso de perfil individual");
assert.ok(html.includes('localStorage.setItem("pf-ref"'), "index guarda ?ref=");
assert.ok(html.includes("if(rf_)c.ref=rf_"), "conta nova guarda o código do afiliado");

// 3) RBAC: garçom não tem "Pronto"; só serve. Cozinha não serve mesa.
const mesas = html.slice(html.indexOf("function mesasView"), html.indexOf("function ptotal"));
assert.ok(!/Marcar como Pronto|:pronto"/.test(mesas), "tela do garçom não tem botão de Pronto");
assert.ok(mesas.includes("Servir na Mesa"), "garçom tem Servir na Mesa");
const F = new Function("return " + /var PF_FASES=(\{[^}]*\})/.exec(html)[1])();
assert.deepStrictEqual(F.mesas, ["entregue"]);
assert.ok(!F.mesas.includes("pronto") && !F.mesas.includes("preparo"), "garçom não muda para pronto/preparo");
assert.ok(!F.kds.includes("entregue") && !F.ent.includes("pronto"), "cozinha não entrega; entregador não cozinha");
assert.ok(html.includes('var PP=pfPapel();if(PP){'), "trava global de clique por função");
assert.ok(/function staffPanel[\s\S]*STAFF\.papel\)subs=STAFF\.papel==="ped"\?\[\["ped","Pedidos"\],\["caixa","Caixa"\]\]:subs\.filter\(function\(x\)\{return x\[0\]===STAFF\.papel\}\)/.test(html), "equipe só vê a própria aba (a Loja vê Pedidos e Caixa)");
assert.ok(!/Acessar Modo Loja|data-adm/.test(html.slice(html.indexOf("function staffPanel"), html.indexOf("function staffView"))), "equipe não vê ADM");

// 4) Pix: valor exato e CRC16 válido no copia e cola
const fn = (n) => new RegExp("function " + n + "\\([\\s\\S]*?\\n").exec(html)[0];
const ctx = { S: { pix: "11144477735", pixNome: "Loja Teste", pixCid: "Vitoria" } };
vm.createContext(ctx);
vm.runInContext(["tlv", "ascii", "crc", "cpfOk", "pixKey", "pixCode"].map(fn).join("\n"), ctx);
const code = vm.runInContext("pixCode(149.9)", ctx);
assert.ok(code.includes("5406149.90"), "valor exato no payload (R$ 149,90)");
assert.ok(code.startsWith("000201") && code.includes("br.gov.bcb.pix"), "payload Pix válido");
assert.strictEqual(vm.runInContext("crc(" + JSON.stringify(code.slice(0, -4)) + ")", ctx), code.slice(-4), "CRC16 confere");
assert.ok(html.includes("data-cpix") && html.includes("Copiar Pix copia e cola") && html.includes("qrSvg(pixCode(val)"), "checkout mostra QR e copia e cola");

// 5) Criador: ações aguardam o Firestore e mostram erro
for (const k of ["data-pflok", "data-pflno", "data-pfafpay"]) {
  const i = html.indexOf('if(t.hasAttribute("' + k + '")'); assert.ok(i > 0, k);
  const seg = html.slice(i, i + 900);
  assert.ok(/function\(r\)\{if\(r(===|!==)true\)/.test(seg) && seg.includes("pfErr(r"), k + ": só confirma quando o Firestore grava");
}
assert.ok(html.includes("function pfCreditar") && html.includes('"/vendas/"'), "comissão creditada ao aprovar assinatura indicada");

// 6) Home e portal do afiliado
assert.ok(html.includes('href="/afiliado.html"') && html.includes("Programa de afiliados"), "home tem a seção de afiliados");
const af = read("afiliado.html");
new vm.Script([...af.matchAll(/<script(?![^>]*\bsrc\b)[^>]*>([\s\S]*?)<\/script>/g)].map((m) => m[1]).join("\n"));
for (const t of ["signInWithPopup", "?ref=", "pf_afiliados", "vendas", "Carteira de comissões"]) assert.ok(af.includes(t), "afiliado.html: " + t);
const cfg = JSON.parse(read("vercel.json")).rewrites.map((r) => r.source);
assert.ok(cfg.indexOf("/afiliado") > -1 && cfg.indexOf("/afiliado") < cfg.findIndex((s) => s.startsWith("/:slug")), "/afiliado antes da rota de loja");
assert.ok(require("../api/_lib").RESERVED.has("afiliado"), "afiliado é endereço reservado");

// 7) Regras
const rules = read("firestore.rules");
assert.strictEqual((rules.match(/\{/g) || []).length, (rules.match(/\}/g) || []).length, "chaves balanceadas");
assert.strictEqual((rules.match(/\(/g) || []).length, (rules.match(/\)/g) || []).length, "parênteses balanceados");
for (const c of ["pf_slugs", "pf_lojas_publicas", "pf_lojas", "pedidos", "equipe", "pf_convites", "pf_contas", "pf_afiliados", "vendas", "pf_tickets", "pf_config"]) assert.ok(rules.includes("match /" + (c.startsWith("pf_") ? c : c) ), "regra: " + c);
assert.ok(rules.includes("function isStaff") && rules.includes("function isCriador"), "funções de acesso");
assert.ok(/allow update: if isCriador\(\)\s*\|\|\s*\(isOwner\(uid\)/.test(rules), "dono não aprova a própria assinatura");
console.log("gestao.test.js: tudo certo");
// 8) RBAC nas regras: papel gravado pelo dono, cozinha/garçom/entregas separados
{
  const r = fs.readFileSync(R("firestore.rules"), "utf8");
  const h = fs.readFileSync(R("index.html"), "utf8");
  assert.ok(r.includes("function isCozinha") && r.includes("function isGarcom") && r.includes("function isEntrega"), "papéis nas regras");
  assert.ok(r.includes("!('papel' in request.resource.data)"), "funcionário não define o próprio papel");
  assert.ok(/isCozinha\(uid\)[\s\S]*hasOnly\(\['fase', 'iniEm', 'prontoEm', 'liberadoEm'\]\)/.test(r), "cozinha só altera fase/tempos");
  assert.ok(/isGarcom\(uid\)[\s\S]*garcom_uid[\s\S]*request\.resource\.data\.fase == 'entregue'/.test(r), "garçom só serve os próprios pedidos");
  assert.ok(h.includes("garcom_uid:opWho().uid"), "app grava garcom_uid na mesa");
  assert.ok(h.includes("up.papel=pa") && h.includes("STAFF.mp"), "app grava e lê o papel da equipe");
}
console.log("RBAC ok");

// 7) Leitura por função: a equipe só baixa o que a regra deixa ler
{
  const h = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  const rules = fs.readFileSync(path.join(__dirname, "..", "firestore.rules"), "utf8");
  assert.ok(h.includes('["garcom_uid","==",STAFF.uid||""]'), "garçom filtra por garcom_uid");
  assert.ok(h.includes('["fase","in",["novo","preparo","pronto"]]'), "cozinha filtra novo/preparo/pronto");
  assert.ok(h.includes('up.liberadoEm="__SRV_TS__"') && h.includes("FieldValue.serverTimestamp()"), "pronto grava liberadoEm com serverTimestamp");
  assert.ok(h.includes('data-pfktab="fila"') && h.includes('data-pfktab="hist"') && h.includes(">Liberado</span>"), "cozinha tem Fila Ativa e Histórico com tag Liberado");
  assert.ok(rules.includes("'liberadoEm'") && rules.includes("liberadoEm == request.time"), "regra aceita liberadoEm só como hora do servidor");
  assert.ok(h.includes('["ent","==","entrega"],["ent_uid","==",STAFF.uid||""],["fase","in",["saiu","pronto"]]'), "entrega filtra as DELE (ent_uid) em saiu/pronto (M-06)");
  assert.ok(h.includes('st:st,fase:MODS().kds?"novo":"pronto"'), "pedido do cliente nasce novo (com Cozinha) ou pronto (sem Cozinha)");
  assert.ok(!/allow read: if isOwner\(uid\) \|\| isStaff\(uid\);/.test(rules), "regra não libera leitura geral à equipe");
  assert.ok(rules.includes("resource.data.garcom_uid == request.auth.uid"), "regra de leitura do garçom");
  console.log("leitura por função ok");
}

// 8) Afiliado 50%, recibo PDF, impressora Bluetooth e comissão do garçom
{
  const h = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  const rules = fs.readFileSync(path.join(__dirname, "..", "firestore.rules"), "utf8");
  assert.ok(h.includes("PF_COM_PADRAO=50,PF_PLANO_BASE=49.9") && !/:30,val=/.test(h), "afiliado: padrão 50% (não 30%)");
  assert.strictEqual(Math.round(49.9 * 50 + 1e-6) / 100, 24.95, "R$ 49,90 × 50% = R$ 24,95");
  assert.ok(h.includes("async function makeRecibo") && h.includes("data-pfrec"), "recibo do cliente em PDF");
  assert.ok(h.includes("makePdf") && h.includes('"5. Comissões dos garçons"'), "relatório contábil inclui comissões");
  assert.ok(h.includes("navigator.bluetooth.requestDevice") && h.includes("data-btp=\"conn\"") && h.includes("function btTicket"), "impressora Bluetooth");
  assert.ok(h.includes("function comGravar") && h.includes('pfMesaApi("comissao"') && h.includes("comGravar(ords,f,now,who)"), "fechamento pede a comissão ao servidor");
  assert.ok(!h.includes('"/comissoes/"'), "o app não grava comissão direto no Firestore (A-04)");
  const cm = rules.slice(rules.indexOf("match /comissoes/{cid}"), rules.indexOf("match /equipe/{mid}"));
  assert.ok(cm.includes("allow create: if isOwner(uid);") && !/isGarcom\(uid\)\s*\n?\s*&&\s*request\.resource/.test(cm), "regra da comissão: só o dono cria; garçom só lê");
  console.log("itens 1-4 ok");
}

// 7) Separação por função: ninguém vê a tela do outro
{
  const fnSrc = (n) => new RegExp("function " + n + "\\(\\)\\{[^\\n]*?\\}(?=function |\\n)").exec(html)[0];
  const src = ["pfLock", "pfOwnerLock", "pfPapel", "pfAppBloq"].map(fnSrc).join("\n");
  const run = (ctx) => { vm.createContext(ctx); vm.runInContext(src, ctx); return ctx; };
  const base = { OWNER: true, ACCT: { uid: "x" }, STAFF: null, SUPER: false, ONB: false, VC: false, LOCK: "" };
  // dono sem ?op=: painel completo, sem trava
  let c = run({ ...base });
  assert.strictEqual(vm.runInContext("pfOwnerLock()", c), "");
  assert.strictEqual(vm.runInContext("pfPapel()", c), "");
  // dono no app ADM / Loja: travado na própria área, sem papel de operação
  c = run({ ...base, LOCK: "adm" }); assert.strictEqual(vm.runInContext("pfOwnerLock()", c), "adm"); assert.strictEqual(vm.runInContext("pfPapel()", c), "");
  c = run({ ...base, LOCK: "ped" }); assert.strictEqual(vm.runInContext("pfOwnerLock()", c), "ped");
  // dono num app de função (cozinha): só as ações da cozinha
  c = run({ ...base, LOCK: "kds" }); assert.strictEqual(vm.runInContext("pfPapel()", c), "kds");
  // equipe: a função vem do dono; app de outra função fica bloqueado, inclusive ADM e Loja
  for (const [papel, lock, bloq] of [["mesas", "mesas", false], ["mesas", "kds", true], ["ent", "mesas", true], ["kds", "adm", true], ["kds", "ped", true], ["ent", "", false]]) {
    c = run({ ...base, STAFF: { papel }, LOCK: lock });
    assert.strictEqual(vm.runInContext("pfAppBloq()", c), bloq, papel + " no app " + (lock || "(sem op)"));
    assert.strictEqual(vm.runInContext("pfPapel()", c), papel, "a função da equipe nunca vem da URL");
  }
  // equipe nunca escolhe a própria função pela URL
  const se = html.slice(html.indexOf("function staffEnter"), html.indexOf("function staffPoll"));
  assert.ok(!se.includes("OPQ") && se.includes('STAFF.papel=STAFF.mp||""'), "staffEnter: função só do dono");
  assert.ok(se.includes("pfAppBloq()"), "staffEnter: bloqueia app de outra função");
  const sp = html.slice(html.indexOf("function staffPanel"), html.indexOf("function staffView"));
  assert.ok(sp.includes("Aguardando a sua função") && sp.includes("Aplicativo de outra função"), "telas de bloqueio da equipe");
  assert.ok(html.includes("function opLimpa(){}"), "?op= permanece na URL (mantém a trava ao recarregar)");
  // dono travado: sem botão de trocar de modo nem sub-abas de outras funções
  assert.ok(html.includes('function modoBar(){return pfOwnerLock()?"":'), "app ADM não troca para Loja");
  assert.ok(html.includes('function subNav(){var M=MODS();if(pfOwnerLock())return"";'), "app Loja/função não mostra as outras telas");
  assert.ok(html.includes('(adm_||ag_||lk_)?""'), "app Loja não tem botão ADM");
  // regras do Firestore: rastreio por função, equipe nunca mexe no pagamento
  const rl = read("firestore.rules");
  const ras = rl.slice(rl.indexOf("match /pf_rastreio/{tk}"), rl.indexOf("match /{path=**}/equipe"));
  assert.ok(ras.includes("hasOnly(['fase', 'st', 'upd'])") && ras.includes("hasOnly(['fase', 'upd'])"), "rastreio: equipe sem o campo st");
  assert.ok(ras.includes("isCozinha(resource.data.oid)") && ras.includes("isGarcom(resource.data.oid)") && ras.includes("isEntrega(resource.data.oid)"), "rastreio: transição por função");
  assert.ok(!/isStaff\(resource\.data\.oid\)\)\s*&&\s*request\.resource\.data\.diff\(resource\.data\)\.affectedKeys\(\)\.hasOnly\(\['fase', 'st'/.test(ras), "equipe não grava st");
}
console.log("gestao.test.js: separação por função ok");

// 6) Um APK (TWA) por perfil: pacote único e start_url igual ao do manifest da função
{
  const tw = { cozinha: "cozinha", garcom: "garcom", loja: "lojista", adm: "adm", entregas: "motoboy" }, pk = new Set();
  for (const [p, mfk] of Object.entries(tw)) {
    const t = JSON.parse(read("twa", p, "twa-manifest.json")), m = JSON.parse(read("manifest-" + mfk + ".json"));
    assert.strictEqual(t.startUrl, m.start_url, p + ": startUrl do APK = start_url do manifest");
    assert.ok(!pk.has(t.packageId), p + ": pacote único"); pk.add(t.packageId);
  }
  assert.strictEqual(pk.size, 5, "5 APKs, um por perfil");
  console.log("gestao.test.js: APK por perfil ok");
}

// 7) Balcão (Loja): só acompanha em Pedidos (sem abas Mesas/Entregas); garçom sem botão Balcão
{
  const hh = read("index.html");
  assert.ok(hh.includes("function faseTxt") && hh.includes("Pronto para servir") && hh.includes("Saiu para entrega") && hh.includes("faseTxt(o)"), "Pedidos mostra o andamento");
  assert.ok(!hh.includes('b("mesas","Mesas")') && !hh.includes('b("ent","Entregas"'), "Loja sem abas Mesas e Entregas");
  assert.ok(hh.includes('var names=pfPapel()==="mesas"||pfLock()==="mesas"?[]:["Balcão"]'), "garçom sem botão Balcão");
  console.log("gestao.test.js: balcão ok");
}

// 8) Login Google mostra a escolha das contas do aparelho (select_account) e não trava no app instalado
{
  const hh = read("index.html");
  assert.ok(hh.includes('prompt:"select_account"') && hh.includes("signInWithRedirect"), "Google: escolha de conta + redirect de reserva");
  assert.ok(!hh.includes("signInWithPopup(new firebase.auth.GoogleAuthProvider())"), "todo login Google usa pfGoogle");
  console.log("gestao.test.js: login Google ok");
}

// 9) Login nativo (contas do Android) quando o app é o APK nativo; web como reserva
{
  const hh = read("index.html");
  assert.ok(hh.includes("pfGoogleNativo") && hh.includes("signInWithCredential") && hh.includes("PF_GOOGLE_WEB_CLIENT_ID"), "login Google nativo com reserva web");
  for (const p of ["cozinha", "garcom", "loja", "adm", "entregas"]) {
    const c = JSON.parse(read("nativo", p, "capacitor.config.json"));
    assert.ok(/\?op=(kds|garcom|ped|adm|ent)$/.test(c.server.url), p + ": abre na sua função");
  }
  console.log("gestao.test.js: APK nativo ok");
}

// 10) Cada app tem a sua própria área (scope) e não se sobrepõe aos outros: um não "vira" o outro ao instalar
{
  const sc = [];
  for (const f of ["adm", "cozinha", "garcom", "lojista", "motoboy"]) {
    const m = JSON.parse(read("manifest-" + f + ".json"));
    assert.ok(/^\/app\/[a-z]+\/$/.test(m.scope) && m.start_url.startsWith(m.scope), f + ": scope próprio");
    sc.push(m.scope);
  }
  assert.strictEqual(new Set(sc).size, 5, "5 áreas diferentes");
  assert.ok(!sc.some((a) => sc.some((b) => a !== b && b.startsWith(a))), "nenhuma área contém a outra");
  const vj = JSON.parse(read("vercel.json"));
  assert.ok(vj.rewrites.some((r) => r.source.startsWith("/app/:role") && r.destination === "/app/:role/index.html"), "vercel serve /app/<função> (página fixa de cada perfil)");
  assert.ok(read("index.html").includes('location.replace("/app/"+RT[op]+"/"+location.search)'), "?op= na raiz vai para a área do app");
  console.log("gestao.test.js: apps separados ok");
}

// 11) O aviso "Instalar App" é lembrado por função: fechar num app não esconde o botão dos outros
{
  const hh = read("index.html");
  assert.ok(hh.includes('"pf-inst-x:"+') && !hh.includes('localStorage.getItem("pf-inst-x")'), "dispensar o aviso vale só para aquela função");
  console.log("gestao.test.js: instalar por função ok");
}

// 12) "Baixar e instalar" só dentro de cada perfil: o índice /gestao só abre os perfis
{
  const idx = read("gestao", "index.html");
  const hh = read("index.html");
  for (const f of ["lojista", "adm", "cozinha", "garcom", "motoboy"]) assert.ok(read("gestao", f + ".html").includes("q.forEach"), f + ": repassa ?install=1 ao abrir o app");
  assert.strictEqual((idx.match(/Baixar e instalar<\/a>/g) || []).length, 0, "índice sem botões de instalar");
  assert.ok(hh.includes('function instKey(){if(CRIROTA)return "";try{return {adm:"adm",ped:"loja",loja:"loja",kds:"cozinha",ent:"entregas",garcom:"garcom",mesas:"garcom"}[opv()]||""}catch(e){return ""}}'), "botão de instalar em cada um dos 5 perfis (nunca no Criador nem no Index), fixo no topo, também antes do login");
  assert.ok(hh.includes('get("install")==="1"'), "?install=1 ignora o aviso dispensado");
  assert.ok(hh.includes("Instalar app"), "sem prompt do navegador, mostra como instalar pelo menu");
  console.log("gestao.test.js: botão Baixar e instalar por perfil ok");
}

// 13) Depois de instalado, o botão some (no app e no índice); "Instalar de novo" devolve
{
  const hh = read("index.html");
  assert.ok(hh.includes('instFlag(true);EV=null;'), "appinstalled grava que o perfil foi instalado");
  assert.ok(hh.includes("!standalone()&&!instFlag()&&"), "o botão não aparece em perfil já instalado");
  assert.ok(hh.includes("EV=e;if(!standalone())instFlag(false);"), "desinstalou: o navegador oferece instalar de novo e o botão volta sozinho");
  assert.ok(hh.includes("if(forced()&&!standalone())instFlag(false)"), "?install=1 (Instalar de novo) volta a mostrar o botão");
  console.log("gestao.test.js: botão some depois de instalado ok");
}

// 14) Equipe (Cozinha, Garçom, Entregas, Loja): usuário + senha + aprovação do ADM; ADM não passa por aprovação
{
  const hh = read("index.html"), rules = read("firestore.rules");
  assert.ok(hh.includes("Criar usuário e pedir acesso") && hh.includes('id="su"') && hh.includes('id="sp"'), "formulário com usuário e senha");
  assert.ok(hh.includes("linkWithCredential") && hh.includes("signInWithEmailAndPassword"), "cria e entra com usuário/senha (Firebase)");
  assert.ok(hh.includes('status:"pendente"') && hh.includes("usuario:us"), "pedido nasce pendente e guarda o usuário");
  assert.ok(/ok_\(kds\|mesas\|ent\|ped\)/.test(hh) && hh.includes('["ped","Loja"]'), "dono aprova também a função Loja");
  assert.ok(!hh.includes('["adm","ADM"],["kds"') && !/ok_\((?:[a-z|]*)adm/.test(hh), "ADM não é função aprovável (é o dono)");
  assert.ok(rules.includes("function isLoja") && /allow read: if isOwner\(uid\)\s*\|\| isLoja\(uid\)/.test(rules), "regras: Loja da equipe lê os pedidos");
  assert.ok(!/function isStaff\([^\n]*isLoja/.test(rules), "regras: Loja não entra em isStaff (cozinha/garçom/entregas)");
  // Loja (gerente/balcão) OPERA: confirma Pix, muda status e forma de pagamento, mexe no caixa; nada além disso
  const ped = rules.slice(rules.indexOf("match /pedidos/{pid}"), rules.indexOf("match /comissoes/{cid}"));
  const lojaUpd = ped.slice(ped.indexOf("|| (isLoja(uid)\n              && request.resource.data.diff"), ped.indexOf("allow delete"));
  assert.ok(lojaUpd.includes("hasOnly(['fase', 'st', 'fm', 'pg', 'fechada', 'fechadaEm', 'fechadaPor', 'contaModo', 'iniEm', 'prontoEm', 'liberadoEm'])"), "regras: Loja altera só os campos de operação");
  assert.ok(lojaUpd.includes("resource.data.get('st', '') == 'pend' && request.resource.data.st == 'ok'"), "regras: Loja só confirma Pix (pend → ok)");
  assert.ok(!/'(total|items|lin|sinal|tipo|pag|name|phone|addr|tt)'/.test(lojaUpd), "regras: Loja não altera valor, itens nem dados do cliente");
  assert.ok(!/isLoja\(uid\)[^;]*allow delete/.test(ped) && /allow delete: if isOwner\(uid\);\n\n        \/\/ M-06/.test(ped), "regras: só o dono exclui pedido");
  const cxr = rules.slice(rules.indexOf("match /caixa/{cid}"), rules.indexOf("match /comissoes/{cid}"));
  assert.ok(/allow read: if isOwner\(uid\) \|\| isLoja\(uid\)/.test(cxr) && /allow create: if isOwner\(uid\) && cid == 'estado';/.test(cxr) && /allow update, delete: if false;/.test(cxr) && !cxr.split("\n").some((l) => /allow (create|update|write)/.test(l) && l.includes("isLoja")), "regras: caixa — dono e Loja leem; gravação só pelo servidor (M-05)");
  assert.ok(rules.includes("(isLoja(resource.data.oid)") && /request\.resource\.data\.st == 'ok'/.test(rules), "regras: rastreio — Loja muda fase e confirma Pix");
  // app: Loja da equipe tem Pedidos + Caixa, Pix, status e caixa compartilhado
  assert.ok(hh.includes('STAFF.papel==="ped"?[["ped","Pedidos"],["caixa","Caixa"]]'), "app: Loja da equipe tem as abas Pedidos e Caixa");
  assert.ok(hh.includes('ped:["novo","preparo","pronto","saiu","entregue"]'), "app: Loja pode mudar o status do pedido");
  assert.ok(hh.includes("function pfLojaFase") && hh.includes('(STAFF?pfLojaFase(o):'), "app: botão de status para a Loja, sem Excluir");
  assert.ok(['abrir', 'mov', 'fechar'].every((x) => hh.includes('cxApi("' + x + '"')) && !/cxPersist\(\);render\(\);return\}/.test(hh), "app: abrir, movimentar e fechar caixa passam pelo servidor (/api/caixa)");
  assert.ok(hh.includes('"lojas/"+o+"/caixa/estado"') && hh.includes("function cxPull") && hh.includes("function applyOrders(a){ORDT=Date.now();cxPull();"), "app: caixa sincroniza entre dono e Loja");
  assert.ok(rules.includes("&& request.resource.data.status == 'pendente'") && rules.includes("!('papel' in request.resource.data)"), "regras: o funcionário só cria pedido pendente e sem função");
  // lógica pura do usuário/senha
  const fn = (n) => new RegExp("function " + n + "\\([^)]*\\)\\{[^\\n]*\\}").exec(hh)[0];
  const ctx = {}; vm.createContext(ctx);
  vm.runInContext(["sUser", "sUserOk", "sMail", "sHash"].map(fn).join("\n"), ctx);
  assert.strictEqual(ctx.sUser("  Maria.Cozinha "), "maria.cozinha");
  assert.ok(ctx.sUserOk("maria.cozinha") && !ctx.sUserOk("ab") && !ctx.sUserOk("a b c") && !ctx.sUserOk("x".repeat(21)), "regra do usuário");
  assert.notStrictEqual(ctx.sMail("joao", "LOJA1abcdefghij"), ctx.sMail("joao", "OUTRAxyz123456"), "mesmo usuário em lojas diferentes não colide");
  assert.notStrictEqual(ctx.sHash("123456"), ctx.sHash("123457"));
  console.log("gestao.test.js: equipe com usuário, senha e aprovação ok");
}

// 15) Um único botão por perfil (a barra do topo): sem cartões duplicados nas abas
{
  const hh = read("index.html");
  assert.ok(!hh.includes("pfInstCard") && !hh.includes("PFINST"), "sem cartões de instalar duplicados nas abas");
  assert.ok(hh.includes('id="pfinst-go"') && hh.includes("Instala só este perfil"), "barra de instalar do perfil");
  console.log("gestao.test.js: botão de instalar dentro de cada perfil ok");
}
