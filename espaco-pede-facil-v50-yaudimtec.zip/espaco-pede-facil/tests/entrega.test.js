// M-06: o entregador só vê as entregas atribuídas a ele; telefone e endereço saem do pedido que a cozinha lê.
// Checa as regras, o app e o servidor pelo texto (o comportamento real das regras está em regras.emulador.test.js).
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const read = (f) => fs.readFileSync(path.join(__dirname, "..", f), "utf8");
const rules = read("firestore.rules"), h = read("index.html"), srv = read("api/pedido.js");
const bloco = (ini, fim) => { const a = rules.indexOf(ini), b = rules.indexOf(fim, a + 1); assert(a > -1 && b > a, "bloco " + ini); return rules.slice(a, b); };

// ---- regras: leitura do pedido pelo entregador ----
{
  const ped = bloco("match /pedidos/{pid}", "allow update");
  assert.ok(/isEntrega\(uid\) && resource\.data\.get\('st', ''\) == 'ok' && resource\.data\.ent == 'entrega'/.test(ped), "entrega: só pedido de entrega liberado");
  assert.ok(ped.includes("resource.data.fase == 'pronto' && resource.data.get('ent_uid', '') == ''"), "entrega: lê as prontas SEM entregador (para pegar)");
  assert.ok(ped.includes("resource.data.get('ent_uid', '') == request.auth.uid && resource.data.fase in ['saiu', 'pronto']"), "entrega: lê as que são DELE");
  assert.ok(!/isEntrega\(uid\) && resource\.data\.get\('st', ''\) == 'ok' && resource\.data\.ent == 'entrega' && resource\.data\.fase in \['saiu', 'pronto'\]\);/.test(ped), "entrega: não lê mais todas as entregas");
}
// ---- regras: pegar e entregar ----
{
  const upd = bloco("// ENTREGAS (M-06)", "// LOJA (gerente/balcão)");
  assert.ok(upd.includes("resource.data.get('ent_uid', '') == ''") && upd.includes("hasOnly(['fase', 'ent_uid'])") && upd.includes("request.resource.data.ent_uid == request.auth.uid") && upd.includes("request.resource.data.fase == 'saiu'"), "pegar: pronto sem dono → saiu, gravando o próprio uid");
  assert.ok(upd.includes("resource.data.get('ent_uid', '') == request.auth.uid") && upd.includes("resource.data.fase == 'saiu' && request.resource.data.fase == 'entregue'"), "entregar: só a dele, saiu → entregue");
  assert.ok(!upd.includes("'entregue'])"), "entrega não pula de pronto direto para entregue");
}
// ---- regras: contato do cliente ----
{
  const c = bloco("match /contato/{d}", "// caixa (abertura");
  assert.ok(/allow read: if isOwner\(uid\)\s*\|\| isLoja\(uid\)\s*\|\| \(isEntrega\(uid\)/.test(c), "contato: lê dono, Loja e entregador");
  assert.ok(c.includes("get('ent_uid', '') == request.auth.uid"), "contato: o entregador só lê o da entrega DELE");
  assert.ok(!/isCozinha|isGarcom|isStaff/.test(c), "contato: cozinha e garçom não leem");
  assert.ok(/allow create, update, delete: if isOwner\(uid\);/.test(c), "contato: só o dono grava (o servidor ignora as regras)");
}
// ---- regras: rastreio só pelo entregador dono ----
{
  const r = bloco("match /pf_rastreio/{tk}", "match /{path=**}/equipe/{mid}");
  assert.ok(r.includes("get('ent_uid', '') == request.auth.uid") && !r.includes("request.resource.data.fase in ['saiu', 'entregue'])"), "rastreio: só o entregador dono da entrega move");
}
// ---- servidor: o pedido não leva telefone nem endereço ----
{
  const b = srv.slice(srv.indexOf("const base = {"), srv.indexOf("if (fase === \"pronto\") base.prontoEm"));
  assert.ok(!/\bphone\b|\baddr\b/.test(b.replace(/\/\/[^\n]*/g, "")), "servidor: base do pedido sem phone/addr");
  assert.ok(b.includes('base.ent_uid = ""'), "servidor: entrega nasce sem entregador");
  assert.ok(srv.includes('"/contato"') && srv.includes('"dados"') && srv.includes("fsx.delDoc"), "servidor: grava o contato e desfaz o pedido se não gravar");
}
// ---- app: consultas, tela e ação do entregador ----
{
  assert.ok(h.includes('function ordFiltro2(){') && h.includes('["ent_uid","==",""]'), "app: segunda consulta das disponíveis");
  assert.ok(h.includes('["ent_uid","==",STAFF.uid||""]'), "app: primeira consulta só das dele");
  assert.ok(h.includes('pp_==="ent"&&typeof STAFF!=="undefined"&&STAFF&&STAFF.uid){o.ent_uid=STAFF.uid;up.ent_uid=STAFF.uid}'), "app: só o entregador grava ent_uid ao pegar (Loja e dono não)");
  assert.ok(h.includes("Pegar entrega") && h.includes("Disponíveis para pegar"), "app: tela com disponíveis e botão Pegar entrega");
  assert.ok(h.includes("Outro entregador pegou esta entrega antes"), "app: aviso quando outro pegou primeiro");
  assert.ok(h.includes('"lojas/"+ACCT.uid+"/pedidos/"+o.id+"/contato/dados"') && h.includes("function ctMerge()"), "app: telefone e endereço vêm do subdocumento");
  assert.ok(h.includes('if(pp==="ent"&&o.ent_uid!==me.uid)return;'), "app: entregador só busca o contato das entregas dele");
  // a tela da cozinha nunca usa telefone nem endereço
  const a = h.indexOf("function ordCard("), z = h.indexOf("\nfunction ", a + 10);
  assert.ok(a > -1 && z > a && !/\.(phone|addr)\b/.test(h.slice(a, z)), "app: o card da cozinha não usa telefone nem endereço");
  // a lista das disponíveis não mostra endereço nem telefone
  const d = h.slice(h.indexOf("Disponíveis para pegar"), h.indexOf("Disponíveis para pegar") + 700);
  assert.ok(!/\.(phone|addr)\b/.test(d), "app: disponíveis sem telefone nem endereço");
}
{
  const c = bloco("match /pf_contas/{uid}", "// ---------- afiliados");
  assert.ok(c.includes("hasOnly(['nome', 'phone', 'slug', 'plano'])"), "contas: dono só altera contato e plano");
}
console.log("entrega.test.js: entregador só vê as dele, contato fora do pedido ok");
