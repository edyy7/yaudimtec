// Fase 4 da auditoria: permissões e privacidade (B-01, B-04, B-05, B-06, M-04, M-07). Verificação ESTÁTICA das regras e do app;
// o comportamento real das regras só se confirma no Firebase Emulator (npm run emulador).
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.join(__dirname, "..");
const read = (f) => fs.readFileSync(path.join(root, f), "utf8");
const rules = read("firestore.rules");
const h = read("index.html");
const bloco = (ini, fim) => { const a = rules.indexOf(ini), b = rules.indexOf(fim, a + 1); assert(a > -1 && b > a, "bloco " + ini); return rules.slice(a, b); };

// ---- B-05: cozinha e entrega só leem pedido liberado, nas regras E na consulta do app ----
{
  const ped = bloco("match /pedidos/{pid}", "allow update");
  assert.ok(/isCozinha\(uid\) && resource\.data\.get\('st', ''\) == 'ok'/.test(ped), "regra: cozinha só lê st=ok");
  assert.ok(/isEntrega\(uid\) && resource\.data\.get\('st', ''\) == 'ok'/.test(ped), "regra: entrega só lê st=ok");
  assert.ok(h.includes('["fase","in",["novo","preparo","pronto"]],["st","==","ok"]'), "app: consulta da cozinha com st==ok");
  assert.ok(h.includes('["fase","in",["saiu","pronto"]],["st","==","ok"]'), "app: consulta da entrega com st==ok");
}
// ---- B-01: conta fechada não muda forma de pagamento pelo garçom ----
{
  const ped = bloco("match /pedidos/{pid}", "allow delete");
  const g = ped.slice(ped.indexOf("(isGarcom(uid)\n              && resource.data.get('garcom_uid'"), ped.indexOf("// ENTREGAS"));
  assert.ok(g.includes("resource.data.get('fechada', false) != true") && g.includes("hasOnly(['fase'])"), "garçom: fechada trava fm/pg/fechada; só a fase");
}
// ---- M-04: rastreio da equipe acompanha o pedido real; garçom só no próprio ----
{
  const r = bloco("match /pf_rastreio/{tk}", "match /{path=**}/equipe");
  assert.ok(/get\(\/databases\/\$\(database\)\/documents\/pf_lojas\/\$\(resource\.data\.oid\)\/pedidos\/\$\(string\(resource\.data\.id\)\)\)\.data\.get\('fase', ''\) == request\.resource\.data\.fase/.test(r), "rastreio = fase do pedido");
  assert.ok(/isGarcom\(resource\.data\.oid\)\s*\n\s*&& get\([^\n]*\.data\.get\('garcom_uid', ''\) == request\.auth\.uid/.test(r), "garçom: só rastreio de pedido dele");
  assert.ok(r.includes("allow create: if false;"), "rastreio continua só criado pelo servidor");
}
// ---- M-07: pf_config ----
{
  const c = bloco("match /pf_config/{cid}", "\n  }\n}");
  assert.ok(!/allow read: if signedIn\(\);/.test(c), "pf_config não é mais legível por qualquer logado");
  assert.ok(c.includes("isCriador()") && c.includes("pf_contas/$(request.auth.uid)"), "só Criador e empresário com conta");
  assert.ok(/allow write: if isCriador\(\);/.test(c));
}
// ---- B-06: pedido de acesso precisa de convite válido da loja ----
{
  const e = bloco("match /equipe/{mid}", "allow update");
  assert.ok(e.includes("pf_convites/$(request.resource.data.token)") && e.includes(".data.uid == uid") && e.includes("toMillis()"), "equipe: convite válido, da loja e não vencido");
  assert.ok(e.includes("!('papel' in request.resource.data)") && e.includes("== 'pendente'"), "continua nascendo pendente e sem papel");
}
// ---- B-04: cópia pública = lista explícita ----
{
  const ctx = { S: null };
  vm.createContext(ctx);
  const pega = (re) => { const m = re.exec(h); assert.ok(m, "trecho não encontrado: " + re); return m[0]; };
  vm.runInContext([pega(/var PUBK=[^\n]*;/), pega(/function sensKey\(k\)\{[^\n]*\}(?=\n)/), pega(/function pubCopy\(\)\{[^\n]*\}(?=\n)/)].join("\n"), ctx);
  ctx.S = {
    nome: "Loja", slug: "loja", pix: "k", services: [{ id: 1, price: 5 }], bookings: [{ id: 1, sid: 1, date: "d", time: "t", nome: "Cliente", tel: "999" }],
    caixa: { atual: 1 }, funcs: [{ nome: "x" }], cnpj: "1", contadorWpp: "2", equipeToken: "tk", equipeSlug: "s", orders: [{ id: 1, phone: "9" }],
    campoNovoPrivado: "segredo", dadosCobranca: { chave: "x" }, minhaSenha: "x", extra: { aninhado: { token: "t" } },
  };
  const pub = vm.runInContext("pubCopy()", ctx);
  for (const k of ["caixa", "funcs", "cnpj", "contadorWpp", "equipeToken", "equipeSlug", "campoNovoPrivado", "dadosCobranca", "minhaSenha", "extra"]) assert.ok(!(k in pub), k + " não vai para a cópia pública");
  assert.strictEqual(JSON.stringify(pub.orders), "[]", "pedidos nunca vão");
  assert.deepStrictEqual(Object.keys(pub.bookings[0]).sort(), ["date", "id", "sid", "time"], "reserva pública sem nome nem telefone");
  assert.strictEqual(pub.nome, "Loja"); assert.strictEqual(pub.pix, "k");
  // todo campo S.xxx que o app usa está classificado: público (PUBK) ou privado de propósito; campo novo faz o teste falhar até alguém decidir
  const PUBK = Array.from(vm.runInContext("PUBK", ctx)), PRIV = ["caixa", "funcs", "cnpj", "contadorWpp", "equipeToken", "equipeSlug", "orders", "total"];
  const usados = [...new Set((h.match(/\bS\.([A-Za-z_][A-Za-z0-9_]*)/g) || []).map((x) => x.slice(2)))];
  const sem = usados.filter((k) => !PUBK.includes(k) && !PRIV.includes(k));
  assert.strictEqual(sem.length, 0, "campos de S sem classificação (público ou privado): " + sem.join(", "));
  assert.ok(!PUBK.some((k) => /token|secret|senha|password|apikey|api_key/i.test(k) || PRIV.includes(k)), "nenhum campo privado na lista pública");
}
console.log("permissoes.test.js: todos os testes passaram");
