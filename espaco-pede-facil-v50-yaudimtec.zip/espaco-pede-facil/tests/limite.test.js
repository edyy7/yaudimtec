// Fase 5 (auditoria): M-01 limite de pedidos · M-02 reenvio não duplica · M-03 id do futuro · B-02 texto livre em "opt" · B-03 token do app.
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
delete process.env.PF_LIMITE_OFF;
process.env.PF_LIMITE_MAX = "3";
const { privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048, privateKeyEncoding: { type: "pkcs8", format: "pem" }, publicKeyEncoding: { type: "spki", format: "pem" } });
const SA = { client_email: "pf@delivery-67d14.iam.gserviceaccount.com", private_key: privateKey, project_id: "delivery-67d14", token_uri: "https://oauth2.googleapis.com/token" };
process.env.PF_SA_JSON = JSON.stringify(SA);
const fsx = require("../api/_fs");
fsx._reset();
const handler = require("../api/pedido");

const OWNER = "owner1";
let LOJA;
const nova = () => ({
  nome: "Loja", aberta: true, modo: "cardapio", mods: { kds: true, entrega: true }, pix: "11999999999", sinal: true, pct: 30,
  services: [{ id: 1, name: "Pastel", price: 10, opts: ["Queijo extra:2,50"] }, { id: 2, name: "Suco", price: 7.5, opts: [] }],
});
const DB = {};
const put = (p, o) => { DB[p] = fsx.fields(o); };
const get = (p) => { if (!DB[p]) return null; const d = {}; Object.keys(DB[p]).forEach((k) => { d[k] = fsx.fromFs(DB[p][k]); }); return d; };
const cols = (prefix) => Object.keys(DB).filter((k) => k.startsWith(prefix) && !k.includes("/contato/")); // o contato (M-06) mora num subdocumento do pedido
const resp = (ok, status, body) => ({ ok, status, json: async () => body || {} });
global.fetch = async (url, opts = {}) => {
  if (url === SA.token_uri) return resp(true, 200, { access_token: "tk", expires_in: 3600 });
  if (/documents:beginTransaction$/.test(url)) return resp(true, 200, { transaction: "tx" });
  if (/documents:rollback$/.test(url)) return resp(true, 200);
  if (/documents:commit$/.test(url)) {
    const body = JSON.parse(opts.body), cam = (w) => String(w.update.name).replace(/^.*\/documents\//, "");
    for (const w of body.writes) if (w.currentDocument && w.currentDocument.exists === false && DB[cam(w)]) return resp(false, 409, { error: { status: "ALREADY_EXISTS" } });
    for (const w of body.writes) DB[cam(w)] = w.update.fields;
    return resp(true, 200);
  }
  const m = /documents\/(.+?)(\?|$)/.exec(url), doc = decodeURIComponent(m[1]);
  if (opts.method === "POST") {
    const id = /documentId=([^&]+)/.exec(url)[1], c = doc + "/" + id;
    if (DB[c]) return resp(false, 409);
    DB[c] = JSON.parse(opts.body).fields; return resp(true, 200);
  }
  if (doc === "pf_lojas_publicas/" + OWNER) return resp(true, 200, { fields: { data: { stringValue: JSON.stringify(LOJA) } } });
  return DB[doc] ? resp(true, 200, { fields: DB[doc] }) : resp(false, 404);
};
function call(pedido, ip = "1.1.1.1", slug = "loja-teste") {
  return new Promise((resolve) => {
    const hd = {};
    const res = { code: 200, setHeader(k, v) { hd[k] = v; }, status(c) { this.code = c; return this; }, json(b) { resolve({ code: this.code, body: b, hd }); } };
    handler({ method: "POST", body: { slug, pedido }, headers: { "x-forwarded-for": ip } }, res);
  });
}
const T = (n) => String(n).padStart(32, "c");
const ped = (o = {}) => Object.assign({ id: Date.now(), tt: T(1), name: "Maria Silva", phone: "27999999999", total: 32.5, pag: "local", ent: "retirada", addr: "", obs: "", lin: [{ id: 1, q: 2, opt: "Queijo extra" }, { id: 2, q: 1, opt: "" }] }, o);
const reset = () => { Object.keys(DB).forEach((k) => delete DB[k]); put("pf_slugs/loja-teste", { uid: OWNER }); LOJA = nova(); };

(async () => {
  // ---- M-02: o mesmo pedido (mesmo token) com OUTRO id não duplica ----
  reset();
  const a = await call(ped({ tt: T(1), id: Date.now() - 5 })); assert.strictEqual(a.code, 200, JSON.stringify(a.body));
  const b = await call(ped({ tt: T(1), id: Date.now() + 7 }));
  assert.strictEqual(b.code, 200); assert.strictEqual(b.body.repetido, true); assert.strictEqual(b.body.id, a.body.id, "devolve o pedido que já existe");
  assert.strictEqual(b.body.total, a.body.total, "e o mesmo total gravado");
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/pedidos/").length, 1, "um pedido só");
  assert.strictEqual(cols("pf_rastreio/").length, 1, "um rastreio só");
  // token que já pertence a OUTRA loja: recusado
  put("pf_rastreio/" + T(9), { oid: "outraLoja", id: 1795000000000, fase: "novo" });
  const c = await call(ped({ tt: T(9) })); assert.strictEqual(c.code, 409); assert.strictEqual(c.body.erro, "token_em_uso");
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/pedidos/").length, 1);

  // ---- M-03: id do futuro não vale ----
  reset(); let t0 = Date.now();
  const f = await call(ped({ tt: T(2), id: 9e15 })); assert.strictEqual(f.code, 200);
  assert.ok(f.body.id >= t0 && f.body.id <= Date.now() + 20, "id forjado 9e15 virou o horário do servidor");
  const passado = Date.now() - 3600e3; // pedido que ficou na fila do aparelho: id antigo é legítimo
  const p = await call(ped({ tt: T(3), id: passado })); assert.strictEqual(p.body.id, passado, "id do passado é mantido");

  // ---- B-02: texto livre em "opt" ----
  reset(); LOJA.modo = "loja";
  let r = await call(ped({ tt: T(4), lin: [{ id: 1, q: 1, opt: '<img src=x onerror=alert(1)>' }] })); assert.strictEqual(r.code, 200, JSON.stringify(r.body));
  let d = get("pf_lojas/" + OWNER + "/pedidos/" + r.body.id);
  assert.ok(!/<|onerror/.test(d.items), "items sem HTML: " + d.items); assert.strictEqual(d.lin[0].opt, "", "fora do modo cardápio, opt é descartado");
  LOJA = nova();
  r = await call(ped({ tt: T(5), lin: [{ id: 1, q: 1, opt: "<img onerror=x>" }] })); assert.strictEqual(r.code, 422); assert.strictEqual(r.body.erro, "adicional_invalido", "no cardápio só vale adicional do catálogo");

  // ---- M-01: no máximo 3 pedidos por IP e loja na janela ----
  reset();
  for (let i = 0; i < 3; i++) { const x = await call(ped({ tt: T(20 + i), id: Date.now() + i })); assert.strictEqual(x.code, 200, "pedido " + (i + 1)); }
  const n = cols("pf_lojas/" + OWNER + "/pedidos/").length;
  const e = await call(ped({ tt: T(30) })); assert.strictEqual(e.code, 429); assert.strictEqual(e.body.erro, "muitos_pedidos"); assert.ok(e.hd["Retry-After"]);
  assert.strictEqual(cols("pf_lojas/" + OWNER + "/pedidos/").length, n, "o 4º não grava nada");
  const rep = await call(ped({ tt: T(20) })); assert.strictEqual(rep.code, 200); assert.strictEqual(rep.body.repetido, true, "reenvio de pedido já aceito não conta nem é barrado");
  const outro = await call(ped({ tt: T(31) }), "2.2.2.2"); assert.strictEqual(outro.code, 200, "outro IP não é afetado");
  assert.ok(cols("pf_limites/").length >= 2, "contador gravado pelo servidor");
  // contador com falha: a venda NÃO trava (falha aberta)
  const antes = global.fetch;
  global.fetch = async (url, opts) => (/beginTransaction/.test(url) ? resp(false, 500) : antes(url, opts));
  const ok = await call(ped({ tt: T(32) }), "3.3.3.3"); assert.strictEqual(ok.code, 200, "limitador fora do ar não derruba a venda");
  global.fetch = antes;

  // ---- B-03: o app não usa Math.random para o token ----
  const h = fs.readFileSync(path.join(__dirname, "..", "index.html"), "utf8");
  const tok = /function pfTok\(\)\{[^\n]*\}(?=\n)/.exec(h)[0];
  assert.ok(!/Math\.random/.test(tok) && /getRandomValues/.test(tok), "pfTok só usa crypto");
  assert.ok(/recOrder\(st\)\{if\(C\.oid\)return;var s=svc\("cart"\);C\.tt=pfTok\(\);if\(!C\.tt\)/.test(h), "sem crypto o pedido não é enviado");
  assert.ok(h.includes('s===429&&j.erro==="muitos_pedidos"'), "app avisa o cliente quando bate no limite");
  console.log("limite.test.js: todos os testes passaram");
})().catch((e) => { console.error(e); process.exit(1); });
