// REGRAS DO FIRESTORE NO EMULADOR (não roda no `npm test`: precisa do Firebase Emulator).
//   npm install            (uma vez: baixa @firebase/rules-unit-testing e firebase)
//   npm run test:regras    (sobe o emulador, roda este arquivo e desliga; precisa de Java e do firebase-tools)
// Cobre o que as fases 3 e 4 da auditoria mudaram nas regras (A-03, A-04, B-01, B-05, B-06, M-04, M-07), nos dois sentidos:
// o que DEVE funcionar para cada função e o que um app adulterado NÃO pode fazer.
const fs = require("fs");
const path = require("path");
const { initializeTestEnvironment, assertSucceeds, assertFails } = require("@firebase/rules-unit-testing");
const { doc, getDoc, getDocs, setDoc, updateDoc, collection, query, where } = require("firebase/firestore");

const O = "owner1", O2 = "owner2";
const L = "pf_lojas/" + O;
let env;
const resultados = [];
async function t(nome, fn) {
  try { await fn(); resultados.push([true, nome]); console.log("  ok   " + nome); }
  catch (e) { resultados.push([false, nome]); console.log("  FALHA " + nome + "\n        " + String(e.message || e).split("\n")[0]); }
}
const db = (uid, claims) => env.authenticatedContext(uid, claims || {}).firestore();
const D = (uid, caminho, claims) => doc(db(uid, claims), caminho);
const ok = (p) => assertSucceeds(p), no = (p) => assertFails(p);

async function semear() {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const s = ctx.firestore(), put = (p, o) => setDoc(doc(s, p), o);
    const eq = (uid, papel, status) => put(L + "/equipe/" + uid, { uid, nome: uid, papel, status: status || "aprovado" });
    await Promise.all([
      eq("garcom1", "mesas"), eq("garcom2", "mesas"), eq("kds1", "kds"), eq("ent1", "ent"), eq("ent2", "ent"), eq("loja1", "ped"), eq("pend1", "mesas", "pendente"),
      put("pf_convites/tkOK", { uid: O, criadoEm: 1, exp: Date.now() + 1e9 }),
      put("pf_convites/tkOutro", { uid: O2, criadoEm: 1, exp: Date.now() + 1e9 }),
      put("pf_convites/tkVencido", { uid: O, criadoEm: 1, exp: 1 }),
      put("pf_contas/" + O, { uid: O, nome: "Dono" }),
      put("pf_config/criador", { chave: "x" }),
      put(L + "/pedidos/1", { id: 1, fase: "novo", st: "ok", ent: "retirada", total: 50 }),
      put(L + "/pedidos/2", { id: 2, fase: "novo", st: "pend", ent: "entrega", total: 50 }),
      put(L + "/pedidos/3", { id: 3, fase: "pronto", st: "ok", origem: "mesa", garcom_uid: "garcom1", fechada: true, fm: "dinheiro", total: 40 }),
      put(L + "/pedidos/4", { id: 4, fase: "pronto", st: "ok", origem: "mesa", garcom_uid: "garcom1", fechada: false, total: 40 }),
      put(L + "/pedidos/5", { id: 5, fase: "pronto", st: "ok", ent: "entrega", ent_uid: "", total: 40 }),
      // M-06: 8 = em rota com o ent1; 9 = em rota com o ent2; 10 = pronta e livre; cada uma com o contato do cliente em subdocumento
      put(L + "/pedidos/8", { id: 8, fase: "saiu", st: "ok", ent: "entrega", ent_uid: "ent1", total: 40 }),
      put(L + "/pedidos/9", { id: 9, fase: "saiu", st: "ok", ent: "entrega", ent_uid: "ent2", total: 40 }),
      put(L + "/pedidos/10", { id: 10, fase: "pronto", st: "ok", ent: "entrega", ent_uid: "", total: 40 }),
      put(L + "/pedidos/8/contato/dados", { phone: "27999990008", addr: "Rua 8" }),
      put(L + "/pedidos/9/contato/dados", { phone: "27999990009", addr: "Rua 9" }),
      put(L + "/pedidos/10/contato/dados", { phone: "27999990010", addr: "Rua 10" }),
      put("pf_rastreio/tkr8", { oid: O, id: 8, fase: "saiu", ent: "entrega", st: "ok" }),
      put(L + "/pedidos/6", { id: 6, fase: "pronto", st: "ok", ent: "retirada", total: 40 }),
      put(L + "/pedidos/7", { id: 7, fase: "pronto", st: "ok", origem: "mesa", garcom_uid: "garcom1", total: 40 }),
      put("pf_rastreio/tkr1", { oid: O, id: 1, fase: "novo", ent: "retirada", st: "ok" }),
      put("pf_rastreio/tkr5", { oid: O, id: 5, fase: "pronto", ent: "entrega", st: "ok" }),
      put("pf_rastreio/tkr6", { oid: O, id: 6, fase: "pronto", ent: "retirada", st: "ok" }),
      put("pf_rastreio/tkr7", { oid: O, id: 7, fase: "pronto", ent: "retirada", st: "ok" }),
      put(L + "/comissoes/c1", { id: "c1", garcom_uid: "garcom1", valor: 10, base: 100, pct: 10 }),
    ]);
  });
}

(async () => {
  env = await initializeTestEnvironment({ projectId: "demo-pedefacil", firestore: { rules: fs.readFileSync(path.join(__dirname, "..", "firestore.rules"), "utf8") } });
  await semear();

  console.log("A-03 · garçom não grava pedido direto");
  const pedMesa = { id: 100, fase: "novo", st: "ok", origem: "mesa", garcom_uid: "garcom1", total: 0.01 };
  await t("garçom NÃO cria pedido (total forjado)", () => no(setDoc(D("garcom1", L + "/pedidos/100"), pedMesa)));
  await t("dono cria pedido", () => ok(setDoc(D(O, L + "/pedidos/100"), pedMesa)));

  console.log("A-04 · comissão só do servidor/dono");
  await t("garçom NÃO cria comissão", () => no(setDoc(D("garcom1", L + "/comissoes/c9"), { id: "c9", garcom_uid: "garcom1", garcom: "A", mesa: "1", base: 100000, pct: 100, valor: 100000, em: 1, fechadaPor: "", pedidos: [] })));
  await t("dono cria comissão", () => ok(setDoc(D(O, L + "/comissoes/c9"), { id: "c9", garcom_uid: "garcom1", valor: 1 })));
  await t("garçom lê a própria comissão", () => ok(getDoc(D("garcom1", L + "/comissoes/c1"))));
  await t("garçom NÃO lê comissão de outro", () => no(getDoc(D("garcom2", L + "/comissoes/c1"))));
  await t("garçom NÃO acessa comissoes_pedidos (marca do servidor)", () => no(getDoc(D("garcom1", L + "/comissoes_pedidos/1"))));

  console.log("B-05 · cozinha e entrega só leem pedido liberado (st=ok)");
  await t("cozinha lê pedido st=ok", () => ok(getDoc(D("kds1", L + "/pedidos/1"))));
  await t("cozinha NÃO lê pedido Pix pendente", () => no(getDoc(D("kds1", L + "/pedidos/2"))));
  const col = (u) => collection(db(u), L + "/pedidos");
  await t("cozinha: consulta do app (fase in + st==ok) funciona", () => ok(getDocs(query(col("kds1"), where("fase", "in", ["novo", "preparo", "pronto"]), where("st", "==", "ok")))));
  await t("cozinha: consulta SEM st==ok é negada", () => no(getDocs(query(col("kds1"), where("fase", "in", ["novo", "preparo", "pronto"])))));
  await t("entrega lê pedido de entrega st=ok", () => ok(getDoc(D("ent1", L + "/pedidos/5"))));
  await t("entrega: consulta das DELE funciona", () => ok(getDocs(query(col("ent1"), where("ent", "==", "entrega"), where("ent_uid", "==", "ent1"), where("fase", "in", ["saiu", "pronto"]), where("st", "==", "ok")))));
  await t("entrega: consulta das disponíveis funciona", () => ok(getDocs(query(col("ent1"), where("ent", "==", "entrega"), where("fase", "==", "pronto"), where("st", "==", "ok"), where("ent_uid", "==", "")))));
  await t("entrega: consulta SEM st==ok é negada", () => no(getDocs(query(col("ent1"), where("ent", "==", "entrega"), where("ent_uid", "==", "ent1"), where("fase", "in", ["saiu", "pronto"])))));
  await t("entrega: consulta de TODAS as entregas (sem ent_uid) é negada", () => no(getDocs(query(col("ent1"), where("ent", "==", "entrega"), where("fase", "in", ["saiu", "pronto"]), where("st", "==", "ok")))));
  await t("garçom lê só os pedidos dele", async () => {
    await ok(getDocs(query(col("garcom1"), where("garcom_uid", "==", "garcom1"))));
    await no(getDocs(query(col("garcom1"))));
  });

  console.log("B-01 · conta fechada trava forma de pagamento do garçom");
  await t("garçom NÃO muda forma de pagamento de conta fechada", () => no(updateDoc(D("garcom1", L + "/pedidos/3"), { fm: "pix" })));
  await t("garçom NÃO reabre conta fechada", () => no(updateDoc(D("garcom1", L + "/pedidos/3"), { fechada: false })));
  await t("garçom ainda SERVE pedido de conta fechada (fase)", () => ok(updateDoc(D("garcom1", L + "/pedidos/3"), { fase: "entregue" })));
  await t("garçom fecha conta aberta (fm + fechada + fase)", () => ok(updateDoc(D("garcom1", L + "/pedidos/4"), { fm: "pix", fechada: true, fase: "entregue" })));
  await t("garçom NÃO altera total", () => no(updateDoc(D("garcom1", L + "/pedidos/7"), { total: 1 })));
  await t("garçom NÃO mexe em pedido de outro garçom", () => no(updateDoc(D("garcom2", L + "/pedidos/7"), { fase: "entregue" })));

  console.log("M-04 · rastreio acompanha o pedido real");
  await t("cozinha NÃO move o rastreio antes do pedido", () => no(updateDoc(D("kds1", "pf_rastreio/tkr1"), { fase: "preparo" })));
  await t("cozinha move o pedido (novo→preparo)", () => ok(updateDoc(D("kds1", L + "/pedidos/1"), { fase: "preparo" })));
  await t("…e então o rastreio acompanha", () => ok(updateDoc(D("kds1", "pf_rastreio/tkr1"), { fase: "preparo" })));
  await t("cozinha NÃO pula etapa no rastreio (preparo→entregue)", () => no(updateDoc(D("kds1", "pf_rastreio/tkr1"), { fase: "entregue" })));
  await env.withSecurityRulesDisabled(async (ctx) => {
    await updateDoc(doc(ctx.firestore(), L + "/pedidos/6"), { fase: "entregue" });
    await updateDoc(doc(ctx.firestore(), L + "/pedidos/7"), { fase: "entregue" });
  });
  await t("garçom NÃO marca entregue o rastreio de pedido que não é dele", () => no(updateDoc(D("garcom1", "pf_rastreio/tkr6"), { fase: "entregue" })));
  await t("garçom marca entregue o rastreio do pedido DELE", () => ok(updateDoc(D("garcom1", "pf_rastreio/tkr7"), { fase: "entregue" })));
  await t("funcionário NÃO altera o pagamento (st) do rastreio", () => no(updateDoc(D("kds1", "pf_rastreio/tkr1"), { st: "ok" })));
  await t("rastreio continua sem create pelo cliente", () => no(setDoc(D("garcom1", "pf_rastreio/novo"), { oid: O, id: 1, fase: "novo" })));

  console.log("M-07 · pf_config");
  await t("dono com conta lê pf_config", () => ok(getDoc(D(O, "pf_config/criador"))));
  await t("Criador (claim) lê pf_config", () => ok(getDoc(D("crit1", "pf_config/criador", { pfCriador: true }))));
  await t("funcionário NÃO lê pf_config", () => no(getDoc(D("kds1", "pf_config/criador"))));
  await t("logado sem conta NÃO lê pf_config", () => no(getDoc(D("visitante1", "pf_config/criador"))));
  await t("sem login NÃO lê pf_config", () => no(getDoc(doc(env.unauthenticatedContext().firestore(), "pf_config/criador"))));
  await t("empresário NÃO escreve pf_config", () => no(setDoc(D(O, "pf_config/criador"), { chave: "y" })));

  console.log("B-06 · pedido de acesso da equipe exige convite válido da loja");
  const eqDoc = (extra) => Object.assign({ uid: "novo1", nome: "Novo", status: "pendente" }, extra);
  await t("convite válido da loja: pedido aceito", () => ok(setDoc(D("novo1", L + "/equipe/novo1"), eqDoc({ token: "tkOK" }))));
  await t("sem token: negado", () => no(setDoc(D("novo2", L + "/equipe/novo2"), eqDoc({ uid: "novo2" }))));
  await t("convite de OUTRA loja: negado", () => no(setDoc(D("novo3", L + "/equipe/novo3"), eqDoc({ uid: "novo3", token: "tkOutro" }))));
  await t("convite vencido: negado", () => no(setDoc(D("novo4", L + "/equipe/novo4"), eqDoc({ uid: "novo4", token: "tkVencido" }))));
  await t("convite inexistente: negado", () => no(setDoc(D("novo5", L + "/equipe/novo5"), eqDoc({ uid: "novo5", token: "naoExiste" }))));
  await t("convite da loja 1 usado na loja 2: negado", () => no(setDoc(D("novo6", "pf_lojas/" + O2 + "/equipe/novo6"), eqDoc({ uid: "novo6", token: "tkOK" }))));
  await t("já nascer com papel: negado", () => no(setDoc(D("novo7", L + "/equipe/novo7"), eqDoc({ uid: "novo7", token: "tkOK", papel: "ped" }))));
  await t("já nascer aprovado: negado", () => no(setDoc(D("novo8", L + "/equipe/novo8"), eqDoc({ uid: "novo8", token: "tkOK", status: "aprovado" }))));
  await t("funcionário NÃO se auto-aprova", () => no(updateDoc(D("pend1", L + "/equipe/pend1"), { status: "aprovado" })));

  console.log("M-05 · caixa só é gravado pelo servidor");
  const est = L + "/caixa/estado";
  await t("Loja NÃO cria o estado do caixa", () => no(setDoc(D("loja1", est), { data: "{}", updated: 1, por: { uid: "loja1" } })));
  await t("dono cria o estado inicial (migração)", () => ok(setDoc(D(O, est), { data: JSON.stringify({ atual: null, hist: [] }), updated: 1, por: { uid: O } })));
  await t("dono NÃO regrava o estado direto (só o servidor)", () => no(setDoc(D(O, est), { data: "{}", updated: 2, por: { uid: O } })));
  await t("Loja NÃO regrava o estado (sangria/histórico)", () => no(updateDoc(D("loja1", est), { data: "{}", updated: 3 })));
  await t("Loja NÃO apaga o estado", () => no(require("firebase/firestore").deleteDoc(D("loja1", est))));
  await t("Loja NÃO cria fechamento arquivado (h-)", () => no(setDoc(D("loja1", L + "/caixa/h-1"), { id: 1 })));
  await t("Loja e dono LEEM o caixa", async () => { await ok(getDoc(D("loja1", est))); await ok(getDoc(D(O, est))); });
  await t("cozinha NÃO lê o caixa", () => no(getDoc(D("kds1", est))));

  console.log("M-06 · entregador só vê as dele; telefone e endereço fora do pedido que a cozinha lê");
  await semear();
  const PED = (n) => L + "/pedidos/" + n, CT = (n) => L + "/pedidos/" + n + "/contato/dados";
  await t("entregador lê a entrega que é dele", () => ok(getDoc(D("ent1", PED(8)))));
  await t("entregador NÃO lê a entrega de outro entregador", () => no(getDoc(D("ent1", PED(9)))));
  await t("entregador lê entrega pronta e livre (sem contato)", () => ok(getDoc(D("ent1", PED(10)))));
  await t("entregador lê o contato da entrega DELE", () => ok(getDoc(D("ent1", CT(8)))));
  await t("entregador NÃO lê o contato de entrega de outro", () => no(getDoc(D("ent1", CT(9)))));
  await t("entregador NÃO lê o contato de entrega ainda livre", () => no(getDoc(D("ent1", CT(10)))));
  await t("cozinha NÃO lê o contato de nenhum pedido", () => no(getDoc(D("kds1", CT(8)))));
  await t("garçom NÃO lê o contato", () => no(getDoc(D("garcom1", CT(8)))));
  await t("Loja e dono LEEM o contato", async () => { await ok(getDoc(D("loja1", CT(9)))); await ok(getDoc(D(O, CT(9)))); });
  await t("ninguém da equipe grava contato", async () => { await no(setDoc(D("ent1", CT(10)), { phone: "1", addr: "x" })); await no(setDoc(D("loja1", CT(10)), { phone: "1", addr: "x" })); await no(setDoc(D("kds1", CT(10)), { phone: "1", addr: "x" })); });
  await t("dono grava contato", () => ok(setDoc(D(O, CT(10)), { phone: "27999990010", addr: "Rua 10 B" })));
  await t("entregador PEGA entrega livre (pronto → saiu + ent_uid dele)", () => ok(updateDoc(D("ent1", PED(10)), { fase: "saiu", ent_uid: "ent1" })));
  await t("agora o contato dela abre para ele", () => ok(getDoc(D("ent1", CT(10)))));
  await t("outro entregador NÃO pega entrega que já tem dono", () => no(updateDoc(D("ent2", PED(10)), { fase: "saiu", ent_uid: "ent2" })));
  await t("entregador NÃO pega gravando o uid de outro", () => no(updateDoc(D("ent2", PED(5)), { fase: "saiu", ent_uid: "ent1" })));
  await t("entregador NÃO pega sem sair (fase pronto fica, só ent_uid)", () => no(updateDoc(D("ent2", PED(5)), { ent_uid: "ent2" })));
  await t("entregador NÃO entrega a entrega de outro", () => no(updateDoc(D("ent2", PED(8)), { fase: "entregue" })));
  await t("entregador entrega a DELE (saiu → entregue)", () => ok(updateDoc(D("ent1", PED(8)), { fase: "entregue" })));
  await t("entregador NÃO troca o dono da entrega depois de pegar", () => no(updateDoc(D("ent2", PED(9)), { ent_uid: "ent1" })));
  await t("rastreio: só o entregador dono move (saiu → entregue)", async () => { await no(updateDoc(D("ent2", "pf_rastreio/tkr8"), { fase: "entregue", upd: 1 })); });
  await t("rastreio: o dono da entrega acompanha o pedido (pedido já entregue, rastreio entregue)", () => ok(updateDoc(D("ent1", "pf_rastreio/tkr8"), { fase: "entregue", upd: 1 })));

  console.log("auditoria 7.2 · dono só altera contato e plano na própria conta");
  await semear();
  await t("dono atualiza nome/telefone da conta", () => ok(updateDoc(D(O, "pf_contas/" + O), { nome: "Loja", phone: "27999990000" })));
  await t("dono NÃO cria campo de controle novo na conta", () => no(updateDoc(D(O, "pf_contas/" + O), { bloqueada: false, saldo: 999 })));
  await t("dono NÃO troca o uid da conta", () => no(updateDoc(D(O, "pf_contas/" + O), { uid: "outro" })));

  await env.cleanup();
  const falhas = resultados.filter((r) => !r[0]);
  console.log("\n" + (resultados.length - falhas.length) + "/" + resultados.length + " ok" + (falhas.length ? " · " + falhas.length + " FALHA(S)" : ""));
  process.exit(falhas.length ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
