// O modo emulador do _fs.js: liga só com FIRESTORE_EMULATOR_HOST, nunca em produção, e não muda nada no modo normal.
const A = require("assert"), path = require("path");
const fsx = require(path.join(__dirname, "..", "api", "_fs.js"));
const guarda = { h: process.env.FIRESTORE_EMULATOR_HOST, v: process.env.VERCEL_ENV, p: process.env.PF_PROJECT_ID, s: process.env.PF_SA_JSON };
(async () => {
  delete process.env.FIRESTORE_EMULATOR_HOST; delete process.env.VERCEL_ENV; delete process.env.PF_PROJECT_ID; delete process.env.PF_SA_JSON;
  A.strictEqual(fsx.base(), "https://firestore.googleapis.com/v1/projects/delivery-67d14/databases/(default)/documents/", "normal: nuvem");
  A.strictEqual(await fsx.token(), null, "normal sem credencial: sem token (503 no pedido)");
  A.strictEqual(fsx.nome("a/b"), "projects/delivery-67d14/databases/(default)/documents/a/b", "nome completo igual ao de antes");
  process.env.FIRESTORE_EMULATOR_HOST = "127.0.0.1:8080"; process.env.PF_PROJECT_ID = "demo-x";
  A.strictEqual(fsx.base(), "http://127.0.0.1:8080/v1/projects/demo-x/databases/(default)/documents/", "emulador: URL local");
  A.strictEqual(await fsx.token(), "owner", "emulador: Bearer owner");
  A.strictEqual(fsx.nome("a/b"), "projects/demo-x/databases/(default)/documents/a/b", "emulador: nome completo do documento");
  process.env.VERCEL_ENV = "production";
  A.ok(/^https:\/\/firestore\.googleapis\.com\//.test(fsx.base()), "produção na Vercel ignora a variável do emulador");
  A.strictEqual(await fsx.token(), null, "produção: nunca devolve o token do emulador");
  console.log("emulador.test.js: modo emulador só local, produção intacta ok");
})().catch((e) => { console.error(e); process.exit(1); }).finally(() => {
  for (const [k, n] of [["h", "FIRESTORE_EMULATOR_HOST"], ["v", "VERCEL_ENV"], ["p", "PF_PROJECT_ID"], ["s", "PF_SA_JSON"]]) { if (guarda[k] === undefined) delete process.env[n]; else process.env[n] = guarda[k]; }
});
